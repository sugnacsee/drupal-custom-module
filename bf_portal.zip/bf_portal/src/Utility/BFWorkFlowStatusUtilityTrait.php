<?php
namespace Drupal\bf_portal\Utility;

use Drupal\Component\Utility\UrlHelper;
use Drupal\file\Entity\File;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Drupal\paragraphs\Entity\Paragraph;
use Aws\S3\S3Client;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Database\Database;
use Drupal\Core\Cache\Cache;
use Drupal\workflow\Entity\WorkflowConfigTransition;
use Drupal\workflow\Entity\WorkflowState;
use Drupal\workflow\Entity\Workflow;
use Drupal\workflow\Entity\WorkflowManager;
use Drupal\workflow\Entity\WorkflowTransition;
use Drupal\Core\Datetime\Entity\DateFormat;

trait BFWorkFlowStatusUtilityTrait
{

  /**
  * Function :: Updating the catalogue page (clipping) working status.
  */
  public function UpdatingBFCatProductionWorkingStatus($jsondata) {
    /*\Drupal::logger('API-28')->notice('@status || %input],', [
      '@status' => 'Input',
      '%input' => json_encode($jsondata),
    ]);*/
    $catalogueId    = $jsondata['field_bf_catalogue_id'];
    $pageStatus     = $jsondata['field_bf_page_status'];
    $pageDates      = $jsondata['field_bf_page_date'];
    $pageNo         = $jsondata['field_bf_pageno'];
    $briefingFormID = $jsondata['field_briefingform_id'];
    $userId         = $jsondata['field_bf_user_id'];
    $userType       = $jsondata['field_user_type']; // eg. client/team_leader/designer
    // Get Node id for updating catalogue assign page.
    $GetCatAUPageDetails        = $this->GetNodeIdOfCatalogueAssignPage($catalogueId, $pageNo, $userType);
    $catAssigneeUserPageNodeId  = !empty($GetCatAUPageDetails['cataupage_node_id'])?$GetCatAUPageDetails['cataupage_node_id']:null;
    $catauNodeId                = !empty($GetCatAUPageDetails['catau_node_id'])?$GetCatAUPageDetails['catau_node_id']:null;
    // Load catalogue node by catalogue id.
    $catalogueNode = Node::load($catalogueId);
    if($catalogueNode) {
      $jsondata['title'] = $catalogueNode->getTitle();
    } else {
      $jsondata['title'] = '';
    }
    $jsondata['catauNodeId']  = $catauNodeId;
    $pageDate  = date('Y-m-d\TH:i:s', strtotime($pageDates));
    if($catAssigneeUserPageNodeId) {
      // Check the logged in user type is designer.
      if(!empty($userType) && $userType == 'operator') { // Designer Login.
        // Check the post status is completed.

        if(!empty($pageStatus) && $pageStatus == 'catalogue_completed') {
          // Update BF Catalogue Assigning User Page Assignees records in designer record.
          $udpateStatus = $this->UpdateCataloguePageStatusByParam($jsondata, $catAssigneeUserPageNodeId);
          /**
          *  Here, Have to check the status for current designer login id in all assigned catalogue page by using catalogue id and user id.
          */
          $GetCatPageStatus = $this->CheckBFCatalogueAllAssignedPageStatusWithUserId($catalogueId, $userId, $userType);
          if($GetCatPageStatus) { // All pages completed in current updated designer user id.
            // Send email notification to Team leader and QC(if assigned).
            $SendMail = $this->SendMailCurrentUserAllPageClippingCompletedTOTeamLeaderAndQC($briefingFormID, $catalogueId, $pageNo, $userId);
            /**
            * Here, we check the over all page status is completed in current catalogue id.
            * return is true => Insert new record as BF Catalogue Assigning User Page Assignees in leader login.
            */
           $GetAllCatPageStatus = $this->CheckBFCatalogueAllAssignedPageStatusWithOutUserId($catalogueId, $userType, $newPageStatus = 'catalogue_completed', $NextUserType = 'operator');
            if($GetAllCatPageStatus) {
              // All BF Catalogue Assignees pages to next level data insert.
              //$GetAssigningData = $this->GetAndInsertCatalogueAllPagesByCatalogueIdAndUserType($catalogueId, $userType, $pageStatus, $newPageStatus = 'catalogue_created', $NextUserType = 'leader');
              // Have to update catalogue workflow status as "To QA Review".
              $wftdata = $briefingFormID.' | '.$catalogueId.' | catalogue_to_qa_review | '.$userId.' | '.$userType.' | false';
              \Drupal::logger('workflow-status-before-update')->notice('@wftdata ||  %GetAllCatPageStatus],', [
                '@wftdata' => $wftdata,
                '%GetAllCatPageStatus' => $GetAllCatPageStatus,
              ]);
              $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_to_qa_review', $userId, $userType, $check = false);
              \Drupal::logger('workflow-status-after-update')->notice('@wftdata ||  %updateCatalogueWorkflow],', [
                '@wftdata' => $wftdata,
                '%updateCatalogueWorkflow' => $updateCatalogueWorkflow,
              ]);
              /** 
              * Here we check and update catalogue status to check all the catalogues workflow status are in "To QA Review".
              * Have to update catalogue status is clippied until client approved.
              */
              $checkCatalogueWorkflowStatus = $this->checkCatalogueWorkflowStatusByParam($briefingFormID, $catalogueId, $pageStatus = 'catalogue_to_qa_review');
              if($checkCatalogueWorkflowStatus) {
                // If the response is true, we have to update catalogue status as clipped. Bcoz all catalogue pages are completed clipping and ready for QA review.
                $catalogueNode->set('field_catalogue_status', 'clipped');
                $updateCatStatus = $catalogueNode->save();
                \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updateCatStatus],', [
                  '@jsondata' => json_encode($jsondata),
                  '%updateCatStatus' => $updateCatStatus,
                ]);
                if($updateCatStatus) {
                  // Send email notification to Team leader and QC(if assigned).
                  $SendMail = $this->SendMailCurrentUserAllPageClippingCompletedTOTeamLeaderAndQC($briefingFormID, $catalogueId, $pageNo, $userId);
                  // Have to check the all catalogues related to specific briefing form id.
                  //$GetAllCatalogue = $this->GetAllCatalogueByBFId($briefingFormID);
                  $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
                } else {
                  $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                }
              } else {
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              }                  
            } else {
              // Return Response - All pages are not completed.
              $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
            }
          } else {
            // Return Response - Specific designer allocated all pages are not completed.
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          }
        } else if(!empty($pageStatus) && ($pageStatus == 'catalogue_start_job' || $pageStatus == 'catalogue_pause_job' || $pageStatus == 'catalogue_hold' || $pageStatus == 'catalogue_stop_job')) {

          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus, $userId, $userType, $jsondata);
          if($updatePageStatus) {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }
          \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updatePageStatus],', [
            '@jsondata' => json_encode($jsondata),
            '%updatePageStatus' => $updatePageStatus,
          ]);
        } else {
          $catExistStatus = $catalogueNode->field_catalogue_status->value;
          if($catExistStatus == 'created') {

            //$updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus, $userId, $userType, $check = false);
            // Update catalogue status.
            $catalogueNode->set('field_catalogue_status', 'clipping');
            $updateCatStatus = $catalogueNode->save();
            \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updateCatStatus],', [
              '@jsondata' => json_encode($jsondata),
              '%updateCatStatus' => $updateCatStatus,
            ]);
          }
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        }

      } else if(!empty($userType) && ($userType == 'leader' || $userType == 'manager')) { // Team Leader, Manager Login. 

        // Check the logged in user type is team leader.
        // Check the post status is completed.
        if(!empty($pageStatus) && $pageStatus == 'catalogue_completed') {

          // Update BF Catalogue Assigning User Page Assignees records in designer record.
          $udpateStatus = $this->UpdateCataloguePageStatusByParam($jsondata, $catAssigneeUserPageNodeId);
          /**
          * Here, we check the over all page status is completed in current catalogue id.
          * return is true => Insert new record as BF Catalogue Assigning User Page Assignees in supervisor(Q,A) login.
          */
          $GetAllCatPageStatus = $this->CheckBFCatalogueAllAssignedPageStatusWithOutUserId($catalogueId, $userType, $newPageStatus = 'catalogue_final_check', $NextUserType = $userType);
          if($GetAllCatPageStatus) {
            // All BF Catalogue Assignees pages to next level data insert.
            //$GetAssigningData = $this->GetAndInsertCatalogueAllPagesByCatalogueIdAndUserType($catalogueId, $userType, $pageStatus, $newPageStatus = 'catalogue_final_check', $NextUserType = 'leader');
            // Have to update asset status and catalogues status and work flow status is completed.
            $catalogueNode->set('field_catalogue_status', 'clipped');
            $updateCatStatus = $catalogueNode->save();
            \Drupal::logger('catalogue-status-update-leader')->notice('@jsondata ||  %updateCatStatus],', [
              '@jsondata' => json_encode($jsondata),
              '%updateCatStatus' => $updateCatStatus,
            ]);
            if($updateCatStatus) {
              // Have to update catalogues work flow status.
              $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_final_check', $userId, $userType, $check = false);
              $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          } else {
            // Return Response - All pages are not completed.
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.'];
          }

        } else if(!empty($pageStatus) && $pageStatus == 'catalogue_re_work') { // Re-Work - Team Leader.

          // Have to update specific pages as re-work and back to catalogue_clipping status.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_work', $userId, $userType, $jsondata);
          if($updatePageStatus) {
            // Change the specific given page in designer record from completed to re-work.
            $changepagestatus = $this->ChangeCatalogueSpecificPageStatusByparam($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_work', $userType = 'operator');
            // Have to update catalogues work flow status.
            $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_re_work', $userId, $userType, $check = false);
            // Update Catalogue status as clipping from clipped.
            $catalogueNode->set('field_catalogue_status', 'clipping');
            $updateCatStatus = $catalogueNode->save();
            \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updateCatStatus],', [
              '@jsondata' => json_encode($jsondata),
              '%updateCatStatus' => $updateCatStatus,
            ]);
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        } else if(!empty($pageStatus) && $pageStatus == 'catalogue_re_process') { // Re-Work - Team Leader.

          // Have to update specific pages as re-work and back to catalogue_clipping status.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_process', $userId, $userType, $jsondata);
          if($updatePageStatus) {
            // Change the specific given page in designer record from completed to re-process.
            $changepagestatus = $this->ChangeCatalogueSpecificPageStatusByparam($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_created', $userType = 'operator');
             // Have to update catalogues work flow status.
             $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_re_process', $userId, $userType, $check = false);
             // Update Catalogue status as clipping from clipped.
            $catalogueNode->set('field_catalogue_status', 'clipping');
            $updateCatStatus = $catalogueNode->save();
            \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updateCatStatus],', [
              '@jsondata' => json_encode($jsondata),
              '%updateCatStatus' => $updateCatStatus,
            ]);
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        } else if(!empty($pageStatus) && $pageStatus == 'catalogue_hold') { // Hold - Team Leader.

          // Have to update specific pages as re-work and back to catalogue_clipping status.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_hold', $userId, $userType, $jsondata);
          if($updatePageStatus) {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        /*} else if(!empty($pageStatus) && $pageStatus == 'catalogue_withdrawn') { // Withdraw - Team Leader.

          // Have to update Briefingform Assets status as catalogue_hold.
          $GetBFAssetStatus = $this->GetBFAssetStatusByParams($briefingFormID, $catalogueId);
          if(!empty($GetBFAssetStatus)) {
            $assetNodeId = $GetBFAssetStatus;
            $assetNode = Node::load($assetNodeId);
            $existassetstatus = $assetNode->field_bf_asset_status->value;
            $assetNode->set('field_bf_asset_status', 'withdraw');
            $updateAssets = $assetNode->save();
            if($updateAssets) { 
              // Update BF all page status as catalogue_withdrawn.
              $updateAllPageStatus = $this->updateBFAllPageStatus($briefingFormID, $catalogueId, $pageStatus = 'catalogue_withdrawn', $userId, $userType);
              // Update catalogue workflow status as catalogue_hold.
              $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_withdrawn', $userId, $userType, $check = false);
              if($updateAllPageStatus) {
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                // If process is failure means have to role back the status.
                $assetNode->set('field_bf_asset_status', $existassetstatus);
                $updateAssets = $assetNode->save();
              }
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }*/

        /*} else if(!empty($pageStatus) && $pageStatus == 'catalogue_ready_to_client_review') { // Ready to Client Review - Team Leader.

          // Have to update catalogues work flow status is catalogue_ready_to_client_review.
          $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_ready_to_client_review', $userId, $userType, $check = false);
          // All BF Catalogue Assignees pages to next level data insert.
          $GetAssigningData = $this->GetAndInsertCatalogueAllPagesByCatalogueIdAndUserType($catalogueId, $userType, $pageStatus, $newPageStatus = 'catalogue_ready_to_client_review', $NextUserType = 'poc_user');
          if(isset($updateCatalogueWorkflow) && $updateCatalogueWorkflow['status']=='success') {
            // Update Briefing form status.
            // send mail to client for ready for client review.

            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }*/

        /*} else if(!empty($pageStatus) && $pageStatus == 'catalogue_client_review') { // Client Review - Team Leader.

          // Have to update catalogues work flow status is catalogue_client_review.
          $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_client_review', $userId, $check = false);
          if(isset($updateCatalogueWorkflow) && $updateCatalogueWorkflow['status']=='success') {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }*/

        } else if(!empty($pageStatus) && ($pageStatus == 'catalogue_start_job' || $pageStatus == 'catalogue_pause_job' || $pageStatus == 'catalogue_hold' || $pageStatus == 'catalogue_stop_job')) { // Start, Pause, hold, Stop Job - Team Leader.

          // Have to update specific pages as re-work and back to catalogue_clipping status.
          $dt = $briefingFormID.' | '.$catalogueId.' | '.$pageNo.' | '.$pageStatus.' | '.$userId.' | '.$userType;

          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus, $userId, $userType, $jsondata);
          if($updatePageStatus) {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }
          \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updatePageStatus],', [
            '@jsondata' => json_encode($jsondata),
            '%updatePageStatus' => $updatePageStatus,
          ]);

        } else {
          $result = ['status' => 'error', 'status_message' => 'Something went wrong. Please try again later.']; // sending error response.
        }

      } else if(!empty($userType) && $userType == 'manager') { // Manager.

        if(!empty($pageStatus) && $pageStatus == 'catalogue_re_process') { // Re-process - Manager.

          // Have to update specific pages as re-process and back to catalogue_clipping status.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_process', $userId, $userType, $jsondata);
          if($updatePageStatus) {
            // Change the specific given page in designer record from completed to re-process.
            $changepagestatus = $this->ChangeCatalogueSpecificPageStatusByparam($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_process', $userType = 'operator');
             // Have to update catalogues work flow status.
             $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_re_process', $userId, $userType, $check = false);
             // Update Catalogue status as clipping from clipped.
            $catalogueNode->set('field_catalogue_status', 'clipped');
            $updateCatStatus = $catalogueNode->save();
            \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updateCatStatus],', [
              '@jsondata' => json_encode($jsondata),
              '%updateCatStatus' => $updateCatStatus,
            ]);
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        }

      } else if(!empty($userType) && $userType == 'supervisor') { // Quality Assurance.

        // Check the logged in user type is team auality assurance.
        // Check the post status is completed
        if(!empty($pageStatus) && $pageStatus == 'catalogue_completed') {

          // Update BF Catalogue Assigning User Page Assignees records in designer record.
          $udpateStatus = $this->UpdateCataloguePageStatusByParam($jsondata, $catAssigneeUserPageNodeId);
          // Send email notification to Team leader and QC(if assigned).
          $SendMail = $this->SendMailCurrentUserAllPageClippingCompletedTOTeamLeaderAndQC($briefingFormID, $catalogueId, $pageNo, $userId);
          /**
          * Here, we check the over all page status is completed in current catalogue id.
          * return is true => Insert new record as BF Catalogue Assigning User Page Assignees in supervisor(Q,A) login.
          */
          $GetAllCatPageStatus = $this->CheckBFCatalogueAllAssignedPageStatusWithOutUserId($catalogueId, $userType, $newPageStatus = 'catalogue_final_check', $NextUserType = $userType);
          if($GetAllCatPageStatus) {
            // All BF Catalogue Assignees pages to next level data insert.
            //$GetAssigningData = $this->GetAndInsertCatalogueAllPagesByCatalogueIdAndUserType($catalogueId, $userType, $pageStatus, $newPageStatus = 'catalogue_final_check', $NextUserType = $userType);
            // Have to update asset status and catalogues status and work flow status is completed.
            $catalogueNode->set('field_catalogue_status', 'clipped');
            $updateCatStatus = $catalogueNode->save();
            \Drupal::logger('catalogue-status-update-leader')->notice('@jsondata ||  %updateCatStatus],', [
              '@jsondata' => json_encode($jsondata),
              '%updateCatStatus' => $updateCatStatus,
            ]);
            if($updateCatStatus) {
              // Send email notification to Team leader and QC(if assigned).
              $SendMail = $this->SendMailCurrentUserAllPageClippingCompletedTOTeamLeaderAndQC($briefingFormID, $catalogueId, $pageNo, $userId);
              // Have to update catalogues work flow status.
              $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_final_check', $userId, $userType, $check = false);
              $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          } else {
            // Return Response - All pages are not completed.
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.'];
          }

        } else if(!empty($pageStatus) && $pageStatus == 'catalogue_re_work') { // Re-Work - Quality Assurance.

          // Have to update specific pages as re-work and back to catalogue_clipping status.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_work', $userId, $userType, $jsondata);
          if($updatePageStatus) {
            // Change the specific given page in designer record from completed to re-work.
            $changepagestatus = $this->ChangeCatalogueSpecificPageStatusByparam($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_work', $userType = 'operator');
             // Have to update catalogues work flow status.
             $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_re_work', $userId, $userType, $check = false);
             // Update Catalogue status as clipping from clipped.
            $catalogueNode->set('field_catalogue_status', 'clipped');
            $updateCatStatus = $catalogueNode->save();
            \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updateCatStatus],', [
              '@jsondata' => json_encode($jsondata),
              '%updateCatStatus' => $updateCatStatus,
            ]);
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        } else if(!empty($pageStatus) && $pageStatus == 'catalogue_re_process') { // Re-process - Quality Assurance.

          // Have to update specific pages as re-process and back to catalogue_clipping status.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_process', $userId, $userType, $jsondata);
          if($updatePageStatus) {
            // Change the specific given page in designer record from completed to re-process.
            $changepagestatus = $this->ChangeCatalogueSpecificPageStatusByparam($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_re_process', $userType = 'operator');
             // Have to update catalogues work flow status.
             $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_re_process', $userId, $userType, $check = false);
             // Update Catalogue status as clipping from clipped.
            $catalogueNode->set('field_catalogue_status', 'clipped');
            $updateCatStatus = $catalogueNode->save();
            \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updateCatStatus],', [
              '@jsondata' => json_encode($jsondata),
              '%updateCatStatus' => $updateCatStatus,
            ]);
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        } else if(!empty($pageStatus) && $pageStatus == 'catalogue_hold') { // Hold - Quality Assurance.

          // Have to update Briefingform Assets status as catalogue_hold.
          $GetBFAssetStatus = $this->GetBFAssetStatusByParams($briefingFormID, $catalogueId);
          if(!empty($GetBFAssetStatus)) {
            $assetNodeId = $GetBFAssetStatus;
            $assetNode = Node::load($assetNodeId);
            $existassetstatus = $assetNode->field_bf_asset_status->value;
            $assetNode->set('field_bf_asset_status', 'hold');
            $updateAssets = $assetNode->save();
            if($updateAssets) {
              // Change the specific given page in designer record from completed to catalogue hold.
              $changepagestatus = $this->ChangeCatalogueSpecificPageStatusByparam($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_hold', $userType = 'operator');
              // Update catalogue workflow status as catalogue_hold.
              $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_hold', $userId, $userType, $check = false);
              if(isset($updateCatalogueWorkflow) && $updateCatalogueWorkflow['status']=='success'){
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                // If process is failure means have to role back the status.
                $assetNode->set('field_bf_asset_status', $existassetstatus);
                $updateAssets = $assetNode->save();
              }
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        /*} else if(!empty($pageStatus) && $pageStatus == 'catalogue_withdrawn') { // Withdraw - Quality Assurance.

          // Have to update Briefingform Assets status as catalogue_hold.
          $GetBFAssetStatus = $this->GetBFAssetStatusByParams($briefingFormID, $catalogueId);
          if(!empty($GetBFAssetStatus)) {
            $assetNodeId = $GetBFAssetStatus;
            $assetNode = Node::load($assetNodeId);
            $existassetstatus = $assetNode->field_bf_asset_status->value;
            $assetNode->set('field_bf_asset_status', 'withdraw');
            $updateAssets = $assetNode->save();
            if($updateAssets) {
              // Update BF all page status as catalogue_withdrawn.
              $updateAllPageStatus = $this->updateBFAllPageStatus($briefingFormID, $catalogueId, $pageStatus = 'catalogue_withdrawn', $userId, $userType);
              // Update catalogue workflow status as catalogue_hold.
              $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_withdrawn', $userId, $userType, $check = false);
              if($updateAllPageStatus) {
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                // If process is failure means have to role back the status.
                $assetNode->set('field_bf_asset_status', $existassetstatus);
                $updateAssets = $assetNode->save();
              }
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }*/

        /*} else if(!empty($pageStatus) && $pageStatus == 'catalogue_ready_to_client_review') { // Ready to Client Review - Quality Assurance.

          // Have to update catalogues work flow status is catalogue_ready_to_client_review.
          $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_ready_to_client_review', $userId, $userType, $check = false);
            // All BF Catalogue Assignees pages to next level data insert.
            $GetAssigningData = $this->GetAndInsertCatalogueAllPagesByCatalogueIdAndUserType($catalogueId, $userType, $pageStatus, $newPageStatus = 'catalogue_ready_to_client_review', $NextUserType = 'poc_user');
          if(isset($updateCatalogueWorkflow) && $updateCatalogueWorkflow['status']=='success') {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }*/

        /*} else if(!empty($pageStatus) && $pageStatus == 'catalogue_client_review') { // Client Review - Quality Assurance.

          // Have to update catalogues work flow status is catalogue_client_review.
          $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_client_review', $userId, $userType, $check = false);
          if(isset($updateCatalogueWorkflow) && $updateCatalogueWorkflow['status']=='success') {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }*/

        } else if(!empty($pageStatus) && ($pageStatus == 'catalogue_start_job' || $pageStatus == 'catalogue_pause_job' || $pageStatus == 'catalogue_hold' || $pageStatus == 'catalogue_stop_job')) { // Start, Pause, hold, Stop Job - Quality Assurance.

          // Have to update specific pages as re-work and back to catalogue_clipping status.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus, $userId, $userType, $jsondata);
          if($updatePageStatus) {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }
          \Drupal::logger('catalogue-status-update')->notice('@jsondata ||  %updatePageStatus],', [
            '@jsondata' => json_encode($jsondata),
            '%updatePageStatus' => $updatePageStatus,
          ]);

        } else {
          $result = ['status' => 'error', 'status_message' => 'Something went wrong. Please try again later.']; // sending error response.
        }

      } else if(!empty($userType) && $userType == 'poc_user') { // POC Clients.

        if(!empty($pageStatus) && $pageStatus == 'catalogue_approved') { // Approved - POC Clients.

          // Update status to specific page.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus, $userId, $userType, $jsondata);
          if($updatePageStatus) {
            // Check all pages are approved. if approved means have to update update catalogue status and workflow status as approved.
            $CheckAllPages = $this->CheckBFCatalogueAllAssignedPageApprovedStatus($briefingFormID, $catalogueId, $userType);
            if(!isset($CheckAllPages['status']) && $CheckAllPages) {
              // Update workflow status to catalogue.
              $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_approved', $userId, $userType, $check = false);
              // Update catalogue status to catalogue cpontent type.
              $existCatStatus = $catalogueNode->field_catalogue_status->value;
              $catalogueNode->set('field_catalogue_status', 'approved');
              $updateCatStatus = $catalogueNode->save();
              \Drupal::logger('BF-Catalogue-status-Update')->notice('@existCatStatus ||  %updateCatStatus],', [
                '@existCatStatus' => $existCatStatus,
                '%updateCatStatus' => $updateCatStatus,
              ]);
              if($updateCatStatus) {
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
              }
            } else {
              $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
            }
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        } else if(!empty($pageStatus) && $pageStatus == 'catalogue_revision_required') { // Revision Request - POC Clients.

          // Update BF all page status as To QA Review.
          $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus, $userId, $userType, $jsondata);
          if($updatePageStatus) {
            // Update catalogue workflow status as To QA Review.
            $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_revision_required', $userId, $userType, $check = false);
            // Update operator page status.
            $updatePageStatus = $this->updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus = 'catalogue_revision_required', $userId, $userType='operator', $jsondata);
            // Update catalogue status.
            $existCatStatus = $catalogueNode->field_catalogue_status->value;
            $catalogueNode->set('field_catalogue_status', 'clipping');
            $updateCatStatus = $catalogueNode->save();
            if($updateCatStatus) {
              $BFNode = Node::load($briefingFormID);
              $BFNode->set('field_briefing_form_status', 'revision');
              $updateBFNodeStatus = $BFNode->save();
              $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        } else if(!empty($pageStatus) && $pageStatus == 'catalogue_revision_in_progress') { // Revision in Progress - POC Clients.

          // Update catalogue workflow status as To QA Review.
          $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_revision_in_progress', $userId, $userType, $check = false);
          if($updateCatalogueWorkflow) {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }

        /*} else if(!empty($pageStatus) && $pageStatus == 'catalogue_withdrawn') { // Withdrawn - POC Clients.

          // Have to update Briefingform Assets status as catalogue_hold.
          $GetBFAssetStatus = $this->GetBFAssetStatusByParams($briefingFormID, $catalogueId);
          if(!empty($GetBFAssetStatus)) {
            $assetNodeId = $GetBFAssetStatus;
            $assetNode = Node::load($assetNodeId);
            $existassetstatus = $assetNode->field_bf_asset_status->value;
            $assetNode->set('field_bf_asset_status', 'withdraw');
            $updateAssets = $assetNode->save();
            if($updateAssets) {
              // Update BF all page status as catalogue_withdrawn.
              $updateAllPageStatus = $this->updateBFAllPageStatus($briefingFormID, $catalogueId, $pageStatus = 'catalogue_withdrawn', $userId, $userType);
              // Update catalogue workflow status as catalogue_hold.
              $updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $pageStatus = 'catalogue_withdrawn', $userId, $userType, $check = false);
              if($updateAllPageStatus) {
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                // If process is failure means have to role back the status.
                $assetNode->set('field_bf_asset_status', $existassetstatus);
                $updateAssets = $assetNode->save();
              }
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }*/
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else {
        $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
      }      
    } else {
      $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
    }
    \Drupal::logger('BF-Catalogue-status')->notice('@result ||  %jsondata],', [
      '@result' => json_encode($result),
      '%jsondata' => json_encode($jsondata),
    ]);
    $responseData = $jsondata;
    $node_Type    = 'bf_catalogue_assigning_user';
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'PATCH', $node_Type, $responseData, $userId, $result);
    return $result;
  }

  /**
   * Function :: Update catalogue status by catalogue id and status.
   */
  public function updateCataloguestatusByparam($catalogueId, $status) {

    $fieldArray  = array('field_catalogue_status_value' => $status);
    # Database Connection.
    $db = \Drupal::database();
    # Update Query.
    $UpdateQry = $db->update('node__field_catalogue_status')->fields($fieldArray)->condition('entity_id', $catalogueId)->execute();
    if($UpdateQry) {
      return true;
    } else {
      return false;
    }
  }

  /**
  * Function :: Update page status.
  */
  public function UpdateCataloguePageStatusByParam($jsondata, $nodeId) {
    $pageDate    = $jsondata['field_bf_page_date'];
    $pageStatus  = $jsondata['field_bf_page_status'];
    $userId      = $jsondata['field_bf_user_id'];
    $userType    = $jsondata['field_user_type'];
    $catalogueId = $jsondata['field_bf_catalogue_id'];
    $pageNo      = $jsondata['field_bf_pageno'];
    //return true;
    // Change the date format from d-m-Y to Y-m-d.
    $page_date = date('Y-m-d\TH:i:s', strtotime($pageDate));
    // Updating catalogue assign page working production status.
    try {
      $node = Node::load($nodeId);
      $node->set('field_bf_catau_page_date', $page_date);
      $node->set('field_bf_catau_page_status', $pageStatus);
      $node->set('field_bf_catau_page_userid', $userId);
      $node->set('field_bf_catau_assigng_user_role', $userType);
      $update = $node->save();
      if($update) {
        // Update data's to history.field_bf_pageno
        $arrData = array(
          "type"                              => "bf_cat_assigning_user_assignees",
          "title"                             => $jsondata['title'],
          "field_bf_catau_page_catalogue"     => $catalogueId,
          "field_bfcatalogue_assigning_user"  => $nodeId,
          "field_bf_catau_page_userid"        => $userId,
          "field_bf_catau_page_number"        => $pageNo,
          "field_bf_catau_page_date"          => $page_date,
          "field_bf_catau_page_status"        => $pageStatus,
          "field_bf_catau_assigng_user_role"  => $userType
        );
        $encodedata = json_encode($arrData);
        $node_data = array(
          "type"                              => "bf_cat_assuser_assignees_history",
          "title"                             => $jsondata['title'],
          'field_bf_cataupageassignee_date'   => REQUEST_TIME,
          'field_bf_cataupageassignee_json'   => $encodedata,
          'field_bf_cataupageassignee_nid'    => $jsondata['catauNodeId'],
          'field_bf_cataupageassigne_status'  => $pageStatus,
          'uid'                               => $userId
        );
        $node1 = Node::create($node_data);
        $node1->save();
        return true;
      }
    } catch (Exception $e) {
      $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      return $result;
    }
  }

  /**
  * Function :: Get node id of catalogue assign page.
  */
  public function GetNodeIdOfCatalogueAssignPage($catalogueId, $pageno, $userType) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpuid', 'nfbfcpuid.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_clipping_count', 'nfbfccc', 'nfbfccc.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'cataupage_node_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catau_page_number');
    $query->addField('nfbfcau', 'field_bfcatalogue_assigning_user_target_id', 'catau_node_id');
    $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'catau_date');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catau_page_status');
    $query->addField('nfbfcpuid', 'field_bf_catau_page_userid_target_id', 'catau_userid');
    $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'acatau_user_role');
    $query->addField('nfbfccc', 'field_bf_catau_clipping_count_value', 'catau_clipping_count');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcpn.field_bf_catau_page_number_value', $pageno);
    $query->condition('nfbfcpur.field_bf_catau_assigng_user_role_value', $userType);
    //$query->allowRowCount = TRUE;
    $result = $query->execute()->fetchAssoc();
    if(!empty($result)) {
      \Drupal::logger('API-28')->notice('@status || %result],', [
        '@status' => 'success',
        '%result' => json_encode($result),
      ]);
      return $result;
    } else {
      \Drupal::logger('API-28')->notice('@status ],', [
        '@status' => 'failure',
      ]);
      return false;
    }
  }

  /**
   * Function :: Update catalogue specific page status by given params.
   */
  public function ChangeCatalogueSpecificPageStatusByparam($briefingFormID, $catalogueId, $pageNo, $pageStatus, $userType) {
    $dt = $briefingFormID.' | '.$catalogueId.' | '.$pageNo.' | '.$pageStatus.' | '.$userType;
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'cataupage_node_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catau_page_number');
    $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'acatau_user_role');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcpn.field_bf_catau_page_number_value', $pageNo);
    $query->condition('nfbfcpur.field_bf_catau_assigng_user_role_value', $userType);
    $result = $query->execute()->fetchAssoc();
    if(!empty($result)) {
      $cataupage_node_id = $result['cataupage_node_id'];
      // update page status.
      $CatPageNode = Node::load($cataupage_node_id);
      $CatPageNode->set('field_bf_catau_page_status', $pageStatus);
      $updateCatPageNode = $CatPageNode->save();
      \Drupal::logger('specificpage-status')->notice('@pageStatus ||  %dt || % $updateCatPageNode],', [
        '@pageStatus' => $pageStatus,
        '%dt' => $dt,
        '%updateCatPageNode' => $updateCatPageNode,
      ]);
      if($updateCatPageNode) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  /**
   * Function :: Check briefing form catalogue all assigned page status by using catalogue id and current user id(optional).
   */
  public function CheckBFCatalogueAllAssignedPageApprovedStatus($briefingFormID, $catalogueId, $userType) {
    try {
      // Select query.
      $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
      $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
      $query->addField('nfbfcpc', 'entity_id', 'node_id');
      $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'field_bf_catau_page_catalogue');
      $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'field_bf_catau_page_status');
      $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'field_bf_catau_page_userid');
      $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'acatau_user_role');
      $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
      $query->condition('nfbfcpur.field_bf_catau_assigng_user_role_value', $userType);
      $query->condition('nfbfcps.field_bf_catau_page_status_value', 'catalogue_approved', '!=');
      $result = $query->execute()->fetchAll();
      if($result) {
        return false; // it will return all page not completed as => NO
      } else {
        return true;  // it will return all page completes => YES
      }
    } catch(\Exception $e){
      $result = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $result;
    }
  }

  /**
   * Function :: Check briefing form catalogue all assigned page status by using catalogue id and current user id(optional).
   */
  public function CheckBFCatalogueAllAssignedPageStatus($catalogueId, $userId) {
    try {
      // Select query.
      $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
      if(!empty($userId)) {
        $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
      }
      $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
      $query->addField('nfbfcpc', 'entity_id', 'node_id');
      $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'field_bf_catau_page_catalogue');
      $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'field_bf_catau_page_status');
      if(!empty($userId)) {
        $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'field_bf_catau_page_userid');
        $query->condition('nfbfcpu.field_bf_catau_page_userid_target_id', $userId);
      }
      $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
      $query->condition('nfbfcps.field_bf_catau_page_status_value', 'catalogue_completed', '!=');
      $query->allowRowCount = TRUE;
      $result = $query->execute()->fetchAll();
      if($result) {
        return false; // it will return all page not completed as => NO
      } else {
        return true;  // it will return all page completes => YES
      }
    } catch(\Exception $e){
      $result = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $result;
    }
  }

  /**
   * Function :: Check briefing form catalogue all assigned page status is completed or not by using catalogue id with current user id.
   */
  public function CheckBFCatalogueAllAssignedPageStatusWithUserId($catalogueId, $userId, $userType) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
    $query->addExpression('COUNT(nfbfcpc.entity_id)', 'query_count');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcpu.field_bf_catau_page_userid_target_id', $userId, '=');
    $query->condition('nfbfcps.field_bf_catau_page_status_value', 'catalogue_completed', '=');
    $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $userType, '=');
    $query->groupBy('nfbfcpc.entity_id');
    $completedRowCount = $query->countQuery()->execute()->fetchField();
    // Get Over all assigned pages count by using catalogue id and user id.
    $GetAllRowCount = $this->GetCountOfcataloguesTotalPagesAssignedToGivenUserId($catalogueId, $userId, $userType);
    // Check the both count is matched or not.
    if($GetAllRowCount == $completedRowCount) {
      return true;
    } else {
      return false;
    }
  }

  /** 
   * Function :: Check briefing form catalogue all assigned page status is completed or not by using catalogue id with current user id.
   */
  public function CheckBFCatalogueAllAssignedPageStatusWithOutUserId($catalogueId, $userType, $newPageStatus, $NextUserType) {
     $dt = json_encode(array($catalogueId,$userType,$newPageStatus,$NextUserType));
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
    $query->addExpression('COUNT(nfbfcpc.entity_id)', 'query_count');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcps.field_bf_catau_page_status_value', 'catalogue_completed', '=');
    $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $userType, '=');
    $query->groupBy('nfbfcpc.entity_id');
    $completedRowCount = $query->countQuery()->execute()->fetchField();
    // Get Over all assigned pages count by using catalogue id and user id.
    $GetAllRowCount = $this->GetCountOfcataloguesTotalPagesAssignedToGivenCatalogueId($catalogueId);
    $GetCatpagesCount = $this->GetCataloguePageCount($catalogueId);
    \Drupal::logger('leader-completed-allpages-1')->notice('@dt ||  %completedRowCount ||  %GetAllRowCount ||  %GetCatpagesCount],', [
      '@dt' => $dt,
      '%completedRowCount' => 'completed Row Count : '.$completedRowCount,
      '%GetAllRowCount' => 'All Row Count : '.$GetAllRowCount,
      '%GetCatpagesCount' => 'Total Page count : '.$GetCatpagesCount,
    ]);
    // Check the both count is matched or not.
    if(($GetAllRowCount == $completedRowCount) && ($GetCatpagesCount == $completedRowCount)) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * Function :: Get count of catalogues total pages assigned to given user( designer/leader/QA).
   */
  public function GetCountOfcataloguesTotalPagesAssignedToGivenUserId($catalogueId, $userId, $userType) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
    $query->addExpression('COUNT(nfbfcpc.entity_id)', 'query_count');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcpu.field_bf_catau_page_userid_target_id', $userId, '=');
    $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $userType, '=');
    $query->groupBy('nfbfcpc.entity_id');
    $num_rows = $query->countQuery()->execute()->fetchField();
    return $num_rows;
  }

  /**
   * Function :: Get count of catalogues total pages assigned to given catalogue id.
   */
  public function GetCountOfcataloguesTotalPagesAssignedToGivenCatalogueId($catalogueId) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'A');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'B', 'B.entity_id = A.entity_id');
    $query->addExpression('COUNT(A.entity_id)', 'query_count');
    $query->condition('A.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('B.field_bf_catau_assigng_user_role_value', 'operator', '=');
    $query->groupBy('A.entity_id');
    $completedRowCount = $query->countQuery()->execute()->fetchField();
    $query->allowRowCount = TRUE;
    return $completedRowCount;
  }

  /**
   * Function :: Get catalogue workflow status by catalogue id.
   */
  public function GetCatalogueWorkflowStatusByCatID($catalogueId, $userId) {
    $data = $this->GetCatalogueWorkflowStatusInternalCall($catalogueId);
    return $data;
  }

  /**
   * Function :: Get catalogue asset user id by using catalogue id.
   */
  public function GetCatalogueAssetUserIdBycatId($catalogueId){
    $query = \Drupal::database()->select('node__field_bf_asset_catalogue_id', 'nfbfacid');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfacid.entity_id');
    $query->addField('nfbfacid', 'entity_id', 'asset_catalogue_id');
    $query->addField('nfd', 'nid', 'asset_nid');
    $query->addField('nfd', 'uid', 'asset_userid');
    $query->condition('nfbfacid.field_bf_asset_catalogue_id_target_id', $catalogueId);
    $results = $query->execute()->fetchAssoc();
    if(!empty($results)){
      $userId  = $results['asset_userid'];
    } else {
      $userId  = '';
    }
    return $userId;
  }

  /**
   * Function :: Get catalogue total pae count By catalogue id.
   */
  public function GetCataloguePageCount($catalogueId) {
    // Select query.
    $query = db_select('node__field_catalogue_pagecount', 'A');
    $query->addField('A', 'field_catalogue_pagecount_value', 'page_count');
    $query->condition('A.entity_id', $catalogueId, '=');
    $results = $query->execute()->fetchAssoc();
    $pageCount = (isset($results['page_count']) && !empty($results['page_count']))?$results['page_count']:null;
    return $pageCount;
  }

  /**
   * Function :: Get count of catalogues total pages assigned to given catalogue id, page status and user role.
   */
  public function GetCataloguesCountTotalPagesAssignedByParams($catalogueId, $pageStatus, $userType) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'A');
    $query->leftjoin('node__field_bf_catau_page_status', 'B', 'B.entity_id = A.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'C', 'C.entity_id = A.entity_id');
    $query->addExpression('COUNT(A.entity_id)', 'query_count');
    $query->condition('A.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('B.field_bf_catau_page_status_value', $pageStatus, '=');
    $query->condition('C.field_bf_catau_assigng_user_role_value', $userType, '=');
    $query->groupBy('A.entity_id');
    $completedRowCount = $query->countQuery()->execute()->fetchField();
    $query->allowRowCount = TRUE;
    return $completedRowCount;
  }

  public function CheckGivenCataloguePagesOrExistsByParams($catalogueId, $pageStatus, $newPageStatus, $NextUserType) {
    // Get Catalogue page count.
    $cataloguePageCount = GetCataloguePageCount($catalogueId);
    // Check and get total page count in catalogue assigned page by params.
    $catAssignedPageCount = $this->GetCataloguesCountTotalPagesAssignedByParams($catalogueId, $newPageStatus, $NextUserType);
    // check both page count in catalogue page count and assigned page count.
    if($cataloguePageCount == $catAssignedPageCount) {
      return false;
    } else {
      return true;
    }
  }

  public function GetCatAssUserByCatId($catalogueId) {
    $query = \Drupal::database()->select('node__field_bf_catasur_catalogue_id', 'nfbf_catid');
    $query->leftjoin('node__field_bf_catasur_due_date', 'nfbf_dd', 'nfbf_dd.entity_id = nfbf_catid.entity_id');
    $query->leftjoin('node__field_bf_catasur_loggedin_userid', 'nfbf_luid', 'nfbf_luid.entity_id = nfbf_catid.entity_id');
    $query->leftjoin('node__field_bf_catasur_pageno_range', 'nfbf_pr', 'nfbf_pr.entity_id = nfbf_catid.entity_id');
    $query->leftjoin('node__field_bf_catasur_client_id', 'nfbf_cid', 'nfbf_cid.entity_id = nfbf_catid.entity_id');
    $query->leftjoin('node__field_bf_catasur_briefingform_id', 'nfbf_bid', 'nfbf_bid.entity_id = nfbf_catid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assigning_notes', 'nfbf_an', 'nfbf_an.entity_id = nfbf_catid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assigninguserid', 'nfbf_aid', 'nfbf_aid.entity_id = nfbf_catid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assign_userrole', 'nfbf_aur', 'nfbf_aur.entity_id = nfbf_catid.entity_id');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbf_catid.entity_id');
    $query->addField('nfbf_catid', 'field_bf_catasur_catalogue_id_target_id', 'catalogue_id');
    $query->addField('nfbf_catid', 'entity_id', 'entity_id');
    $query->addField('nfbf_dd', 'field_bf_catasur_due_date_value', 'due_date');
    $query->addField('nfbf_luid', 'field_bf_catasur_loggedin_userid_target_id', 'loggedin_userid');
    $query->addField('nfbf_pr', 'field_bf_catasur_pageno_range_value', 'pageno_range');
    $query->addField('nfbf_cid', 'field_bf_catasur_client_id_value', 'client_id');
    $query->addField('nfbf_bid', 'field_bf_catasur_briefingform_id_target_id', 'briefingform_id');
    $query->addField('nfbf_an', 'field_bf_catasur_assigning_notes_value', 'assigning_notes');
    $query->addField('nfbf_aid', 'field_bf_catasur_assigninguserid_target_id', 'assigninguserid');
    $query->addField('nfbf_aur', 'field_bf_catasur_assign_userrole_value', 'assigninguserrole');
    $query->addField('nfd', 'type', 'node_type');
    $query->addField('nfd', 'title', 'node_title');
    $query->condition('nfbf_catid.field_bf_catasur_catalogue_id_target_id', $catalogueId);
    $query->orderBy('nfbf_catid.entity_id', 'DESC');
    $query->range(0, 1);
    $results = $query->execute()->fetchAssoc();
    if(!empty( $results )){
      return $results; 
    } else { 
      return false;
    }
  }

  public function GetAndInsertCatalogueAssigneeUserByParams($catalogueId) {
    // Select query for assignee level catalogue page count..
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'A');
    $query->leftjoin('node__field_bf_catau_page_status', 'B', 'B.entity_id = A.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'C', 'C.entity_id = A.entity_id');
    $query->addExpression('COUNT(A.entity_id)', 'query_count');
    $query->condition('A.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('C.field_bf_catau_assigng_user_role_value', 'operator', '=');
    $query->groupBy('A.entity_id');
    $TotalAssignedRowCount = $query->countQuery()->execute()->fetchField();
    // Select query for catalogue total page count.
    $node1 = Node::load($catalogueId);
    $pageCount = $node1->field_catalogue_pagecount->value;
    if($pageCount = $TotalAssignedRowCount) {
      $cataloguePageCount  = $TotalAssignedRowCount;
    } else {
      $cataloguePageCount  = $pageCount;
    }
    if($cataloguePageCount>0) {
      $page_range = '1-'.$cataloguePageCount;
      $GetCatAssUser = $this->GetCatAssUserByCatId($catalogueId);
      if($GetCatAssUser) {
        $BFCatAuCreatedData = array(
          'type'                              => $GetCatAssUser['node_type'],
          'title'                             => $GetCatAssUser['node_title'],
          'field_bf_catasur_assigning_notes'  => $GetCatAssUser['assigning_notes'],
          'field_bf_catasur_assigninguserid'  => $GetCatAssUser['assigninguserid'],
          'field_bf_catasur_briefingform_id'  => $GetCatAssUser['briefingform_id'],
          'field_bf_catasur_catalogue_id'     => $GetCatAssUser['catalogue_id'],
          'field_bf_catasur_client_id'        => $GetCatAssUser['client_id'],
          'field_bf_catasur_due_date'         => $GetCatAssUser['due_date'],
          'field_bf_catasur_loggedin_userid'  => $GetCatAssUser['loggedin_userid'],
          'field_bf_catasur_pageno_range'     => $page_range,
          'field_bf_catasur_assign_userrole'  => 'poc_user'
        );
        // Inserting new node.
        $node2 = Node::create($BFCatAuCreatedData);
        $Save2 = $node2->save();
        $saved_nid2 = $node2->id();
        if($Save2) {
          $BFCatAuCreatedData['bf_catasur_nid'] = $saved_nid2;
          // Save the POST request in BF Catalogue Assigning User History content type.
          $jsondata = json_encode($BFCatAuCreatedData, TRUE);
          // Inserting new node in BF Catalogue Assigning User History.
          $BFCatAuHCreatedData = array(
            'type'                          => 'bf_cat_assigning_user_history',
            'title'                         => $GetCatAssUser['node_title'],
            'field_bf_catasurhis_json'      => $jsondata,
            'field_bf_catasurhis_nid'       => $saved_nid2,
            'field_bf_catasurhis_date_time' => REQUEST_TIME
          );
          $node3 = Node::create($BFCatAuHCreatedData);
          $Save3 = $node3->save();
          // Get last insert node id.
          $savednid3 = $node3->id();
          $BFCatAuHCreatedData['bf_catasurhis_nid'] = $savednid3;
        }
        return $saved_nid2;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  /**
   * Function :: Get all assignees pages by catalogue id and user type.
   */
  public function GetAndInsertCatalogueAllPagesByCatalogueIdAndUserType($catalogueId, $userType, $pageStatus, $newPageStatus, $NextUserType) {

    // Check insert given pages are already inserted or not using catalogue id, user type and page status.
    // $CheckPages = $this->CheckGivenCataloguePagesOrExistsByParams($catalogueId, $pageStatus, $newPageStatus, $NextUserType);
    // Get catalogue assets user id.
    $GetCatAssetUserId = $this->GetCatalogueAssetUserIdBycatId($catalogueId);
    $AsetUserId = !empty($GetCatAssetUserId)?$GetCatAssetUserId:null;
    // Get Total Number of pagesare from ctalogue and assignee designers.
    $GetAssineeUserNid = $this->GetAndInsertCatalogueAssigneeUserByParams($catalogueId);
    // Check if the 
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpno', 'nfbfcpno.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpuid', 'nfbfcpuid.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_clipping_count', 'nfbfcacc', 'nfbfcacc.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'assigning_node_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcau', 'field_bfcatalogue_assigning_user_target_id', 'assigning_user_id');
    $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'assigning_page_date');
    $query->addField('nfbfcpno', 'field_bf_catau_page_number_value', 'assigning_page_number');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'assigning_page_status');
    $query->addField('nfbfcpuid', 'field_bf_catau_page_userid_target_id', 'assigning_page_userid');
    $query->addField('nfbfcaur', 'field_bf_catau_assigng_user_role_value', 'assigning_user_role');
    $query->addField('nfbfcacc', 'field_bf_catau_clipping_count_value', 'assigning_clipping_count');
    $query->addField('nfd', 'type', 'assigning_node_type');
    $query->addField('nfd', 'title', 'assigning_node_title');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcps.field_bf_catau_page_status_value', 'catalogue_completed', '=');
    //$query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $userType, '=');
    $orGroup = $query->orConditionGroup()
                ->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', 'leader', '=')
                ->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', 'manager', '=')
                ->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', 'supervisor', '=');
    $query->condition($orGroup);
    $query->orderBy('nfbfcpno.field_bf_catau_page_number_value', 'ASC');
    $result = $query->execute()->fetchAll();
    if($result) {
      foreach($result as $res) {
        $BFCatAPageData = array(
          'type'                              => $res->assigning_node_type,
          'title'                             => $res->assigning_node_title,
          'field_bf_catau_page_catalogue'     => $res->catalogue_id,
          'field_bfcatalogue_assigning_user'  => !empty($GetAssineeUserNid)?$GetAssineeUserNid:null,
          'field_bf_catau_page_userid'        => $AsetUserId,
          'field_bf_catau_page_number'        => $res->assigning_page_number,
          'field_bf_catau_page_date'          => date('Y-m-d\TH:i:s', REQUEST_TIME),
          'field_bf_catau_assigng_user_role'  => $NextUserType,
          'field_bf_catau_page_status'        => $newPageStatus
        );
        $create_Assign_node = Node::create($BFCatAPageData);
        $create_Assign_node->save();
        $create_Assign_node_nid = $create_Assign_node->id();
        \Drupal::logger('InsertARRAYPage-supervisor')->notice('@create_Assign_node_nid ||  %BFCatAPageData],', [
          '%create_Assign_node_nid' => $create_Assign_node_nid,
          '@BFCatAPageData' => json_encode($BFCatAPageData, true),
        ]);
        if($create_Assign_node) {
          // Save the POST request in BF Catalogue Assigning User Page Assignee's History content type.
          $jsonAssigneesHistoryData = json_encode($BFCatAPageData, TRUE);
          // Inserting new node in BF Catalogue Assigning User Page Assignee's History.
          $create_Assign_node_history_create = Node::create(array(
            'type'                             => 'bf_cat_assuser_assignees_history',
            'title'                            => $res->assigning_node_title,
            'field_bf_cataupageassignee_json'  => $jsonAssigneesHistoryData,
            'field_bf_cataupageassignee_nid'   => $create_Assign_node_nid,
            'field_bf_cataupageassignee_date'  => REQUEST_TIME,
            'field_bf_cataupageassigne_status' => $newPageStatus
          ));
          $create_Assign_node_history_create->save();
          $create_Assign_node_history_nid = $create_Assign_node_history_create->id();

        \Drupal::logger('InsertARRAYPage-supervisor')->notice('@create_Assign_node_history_nid ||  %jsonAssigneesHistoryData],', [
          '%create_Assign_node_history_nid' => $create_Assign_node_history_nid,
          '@jsonAssigneesHistoryData' => json_encode($jsonAssigneesHistoryData, true),
        ]);
        }
      }
      return true;
    } else {
      return false;
    }
  }

  public function GetCatalogueWorkflowStatusByCatID_old($catalogueId, $userId) {
    $user = User::load($userId);
    $UUID = $user->uuid();
    header("Content-Type: text/json;");
    $host = \Drupal::request()->getSchemeAndHttpHost();
    // Curl function.
    $url = $host.'/briefingform/getcatalogue/workflowstatus/'.$UUID.'/'.$catalogueId;
    $header = array("Content-Type: application/json");
    $curl   = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_RETURNTRANSFER => true,
        //CURLOPT_POST => true,
        //CURLOPT_POSTFIELDS => $data_string
    ));
    $response = curl_exec($curl);
    if(curl_error($curl)) {
      $result = false;
    } else {
      $result = $response;
    }
    curl_close($curl);
    return $result;
  }

  /**
   * Function :: Udpate catalogue workflow status api call.
   */
  public function updateCatalogueWorkflowStatusByparams1($briefingFormID, $catalogueId, $status, $userId, $check) {
    header("Content-Type: text/json;");
    $host = \Drupal::request()->getSchemeAndHttpHost();
    // Curl function.
    $url = $host.'/briefingform/savecatalogueworkflowstatus';
    $data = array(
      'field_user_id'         => $userId,
      'field_briefingform_id' => $briefingFormID,
      'field_catalogue_id'    => $catalogueId,
      'field_workflow_status' => $status,
      'check'                 => $check
    );
    $data_string = json_encode($data);
    $header = array("Content-Type: application/json");
    $curl   = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data_string
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
  }

  /**
   * Function :: Udpate catalogue workflow status api call.
   */
  public function updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $status, $userId, $userType, $check) {
    $data = array(
      'field_user_id'         => $userId,
      'field_briefingform_id' => $briefingFormID,
      'field_catalogue_id'    => $catalogueId,
      'field_workflow_status' => $status,
      'field_user_type'       => $userType,
      'check'                 => $check
    );
    $update = $this->UpdateWorkflowStatusInternalCall($data);
    \Drupal::logger('catalogue-workflow')->notice('@data ||  %update],', [
      '@data' => json_encode($data),
      '%update' => $update,
    ]);
    return $update;
  }

  /**
   * Function :: Check all catalogue workflow status are in To QA Review in given briefing form id.
   */
  public function checkCatalogueWorkflowStatusByParam($briefingFormID, $catalogueId, $workflowStatus) {

    $query = db_select('node__field_catalogue_workflow', 'n')
              ->fields('n', ['entity_id'])
              ->condition('n.entity_id', $workflowStatus)
              ->condition('n.field_catalogue_workflow_value', $catalogueId);
    $result = $query->execute()->fetchAll();
    if($result) {
      return true;
    } else {
      return false;
    }
    /*$query = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfrefid');
    $query->leftjoin('node__field_catalogue_workflow', 'nfcws', 'nfcws.entity_id = nfbfrefid.entity_id');
    $query->addField('nfbfrefid', 'entity_id', 'catalogue_id');
    $query->addField('nfcws', 'field_catalogue_workflow_value', 'catalogue_workflow_status');
    $query->condition('nfbfrefid.field_briefing_form_reference_id_target_id', $briefingFormID);
    $query->condition('nfcws.field_catalogue_workflow_value', $workflowStatus, '=');
    $query->orderBy('nfbfrefid.entity_id', 'DESC');
    $query->range(0, 1);
    $result = $query->execute()->fetchAll();
    if($result) {
      return true;
    } else {
      return false;
    }*/
  }

  /**
   * Function :: Check all catalogue workflow status are in To QA Review in given briefing form id.
   */
  public function checkAllCatalogueWorkflowStatusByParam($briefingFormID, $workflowStatus) {
    
    // Get count of catalogue's are mapped to given briefing form id with workflow status.
    $GetcountCatalogueWorkflow = $this->GetCountOfcataloguesMappedToGivenBFIdWorkflowStatus($briefingFormID, $workflowStatus);
    // Get count of catalogue's are mapped to given briefing form id.
    $GetcountCatalogue         = $this->GetCountOfcataloguesMappedToGivenBFId($briefingFormID);
    // Check the both count is matched or not.
    if($GetcountCatalogue == $GetcountCatalogueWorkflow) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * Function :: Get count of catalogue's are mapped to given briefing form id with workflow status.
   */
  public function GetCountOfcataloguesMappedToGivenBFIdWorkflowStatus($briefingFormID, $workflowStatus) {
    // Select query.
    $query = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfrefid');
    $query->leftjoin('node__field_catalogue_workflow', 'nfcws', 'nfcws.entity_id = nfbfrefid.entity_id');
    $query->addExpression('COUNT(nfbfrefid.entity_id)', 'query_count');
    //$query->addField('nfbfrefid', 'entity_id', 'catalogue_id');
    //$query->addField('nfcws', 'field_catalogue_workflow_value', 'catalogue_workflow_status');
    $query->condition('nfbfrefid.field_briefing_form_reference_id_target_id', $briefingFormID);
    $query->condition('nfcws.field_catalogue_workflow_value', $workflowStatus, '=');
    $query->groupBy('nfbfrefid.entity_id');
    $num_rows = $query->countQuery()->execute()->fetchField();
    //$result = $query->execute()->fetchAll();
    return $num_rows;
  }

  /**
   * Function :: Get count of catalogue's are mapped to given briefing form id.
   */
  public function GetCountOfcataloguesMappedToGivenBFId($briefingFormID) {
    $query = db_select('node__field_briefing_form_reference_id', 'n')
              ->fields('n', ['entity_id'])
              ->condition('n.field_briefing_form_reference_id_target_id', $briefingFormID)
              ->execute();
    $query->allowRowCount = TRUE;
    $Rowcount = $query->rowCount();
    return $Rowcount;
  }

  /**
   * Function :: Get briefing form assets status by params.
   */
  public function GetBFAssetStatusByParams($briefingFormID, $catalogueId) {
    // Select query.
    $query = \Drupal::database()->select('node__field_asset_briefingform_id', 'nfabfid');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_asset_catalogue_id', 'nfbfacid', 'nfbfacid.entity_id = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_asset_status', 'nfbfacs', 'nfbfacs.entity_id = nfabfid.entity_id');
    $query->addField('nfabfid', 'entity_id', 'asset_node_id');
    $query->addField('nfbfacs', 'field_bf_asset_status_value', 'asset_status');
    $query->condition('nfabfid.field_asset_briefingform_id_target_id', $briefingFormID, '=');
    $query->condition('nfbfacid.field_bf_asset_catalogue_id_target_id', $catalogueId, '=');
    $results = $query->execute()->fetchAssoc();
    if($results) {
      // update bf asset status as hold.
      $assetNodeId = $results['asset_node_id'];
      return $assetNodeId;
    } else {
      return false;
    }
  }

  /**
   * Function :: Update workflow status to specific pages by params.
   */
  public function updatecatalogueWFSToAssignSpecificpage($briefingFormID, $catalogueId, $pageNo, $pageStatus, $userId, $userType, $jsondata) {
    $inputData = json_encode(array($briefingFormID, $catalogueId, $pageNo, $pageStatus, $userId, $userType));
    /*\Drupal::logger('API-28-before-update-loop')->notice('@status || %inputData],', [
      '@status' => 'params',
      '%inputData' => $inputData, date('Y-m-d\TH:i:s', strtotime($jsondata['field_bf_page_date']));
    ]);*/
    $field_bf_page_date = date('Y-m-d\TH:i:s', strtotime($jsondata['field_bf_page_date']));
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpuid', 'nfbfcpuid.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_clipping_count', 'nfbfccc', 'nfbfccc.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'cataupage_node_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catau_page_number');
    $query->addField('nfbfcau', 'field_bfcatalogue_assigning_user_target_id', 'catau_node_id');
    $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'catau_date');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catau_page_status');
    $query->addField('nfbfcpuid', 'field_bf_catau_page_userid_target_id', 'catau_userid');
    $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'acatau_user_role');
    $query->addField('nfbfccc', 'field_bf_catau_clipping_count_value', 'catau_clipping_count');
    $query->addField('nfd', 'type', 'node_type');
    $query->addField('nfd', 'title', 'node_title');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    //$query->condition('nfbfcpuid.field_bf_catau_page_userid_target_id', $userId);
    $query->condition('nfbfcpn.field_bf_catau_page_number_value', $pageNo);
    $query->condition('nfbfcpur.field_bf_catau_assigng_user_role_value', $userType);
    $result = $query->execute()->fetchAll();
    if($result) {
      /*\Drupal::logger('API-28')->notice('@status || %result],', [
        '@status' => 'success',
        '%result' => json_encode($result),
      ]);*/
      foreach($result as $res) {
        $cataupage_node_id = $res->cataupage_node_id;
        $cataupageNode = Node::load($cataupage_node_id);
        $cataupageNode->set('field_bf_catau_page_date', $field_bf_page_date);
        $cataupageNode->set('field_bf_catau_page_status', $pageStatus);
        $updatecataupageNode = $cataupageNode->save();
        if($updatecataupageNode) {
          $arrData = array(
            "type"                              => $res->node_type,
            "title"                             => $res->node_title,
            "field_bf_catau_page_catalogue"     => $res->catalogue_id,
            "field_bfcatalogue_assigning_user"  => $res->catau_node_id,
            "field_bf_catau_page_userid"        => $res->catau_userid,
            "field_bf_catau_page_number"        => $res->catau_page_number,
            "field_bf_catau_page_date"          => $field_bf_page_date,
            "field_bf_catau_page_status"        => $pageStatus
          );
          $encodedata = json_encode($arrData);
          $node_data  = array(
            "type"                              => "bf_cat_assuser_assignees_history",
            "title"                             => $res->node_title,
            'field_bf_cataupageassignee_date'   => REQUEST_TIME,
            'field_bf_cataupageassignee_json'   => $encodedata,
            'field_bf_cataupageassignee_nid'    => $cataupage_node_id,
            'field_bf_cataupageassigne_status'  => $pageStatus,
            'uid'                               => $userId
          );
          $node1 = Node::create($node_data);
          $node1->save();
          $nodeHistory = $node1->id();
        }
      }
      \Drupal::logger('catalogue-workflow-page-update')->notice('@status || %inputData ||  %updatecataupageNode ||  %encodedata ||  %nodeHistory],', [
        '@status' => 'catalogue workflow page level status updated successfully',
        '%inputData' => $inputData,
        '%updatecataupageNode' => $updatecataupageNode,
        '%encodedata' => $encodedata,
        '%nodeHistory' => $nodeHistory,
      ]);
      return true;
    } else {
      \Drupal::logger('catalogue-workflow-page-update')->notice('@status || %inputData],', [
        '@status' => 'catalogue workflow page level status not updated successfully',
        '%inputData' => $inputData,
      ]);
      return false;
    }
  }
  
  /**
   * Function :: Update briefing form catalogue all page status.
   */
  public function updateBFAllPageStatus($briefingFormID, $catalogueId, $pageStatus, $userId, $userType) {
    $inputData = json_encode(array($briefingFormID, $catalogueId, $pageStatus, $userId, $userType));
    try {
      // Select query.
      $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
      $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpuid', 'nfbfcpuid.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_clipping_count', 'nfbfccc', 'nfbfccc.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcpc.entity_id');
      $query->addField('nfbfcpc', 'entity_id', 'cataupage_node_id');
      $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
      $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catau_page_number');
      $query->addField('nfbfcau', 'field_bfcatalogue_assigning_user_target_id', 'catau_node_id');
      $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'catau_date');
      $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catau_page_status');
      $query->addField('nfbfcpuid', 'field_bf_catau_page_userid_target_id', 'catau_userid');
      $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'acatau_user_role');
      $query->addField('nfbfccc', 'field_bf_catau_clipping_count_value', 'catau_clipping_count');
      $query->addField('nfd', 'type', 'node_type');
      $query->addField('nfd', 'title', 'node_title');
      $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
      //$query->condition('nfbfcpuid.field_bf_catau_page_userid_target_id', $userId);
      $result = $query->execute()->fetchAll();
      if($result) {
        foreach($result as $res) {
          $cataupage_node_id = $res->cataupage_node_id;
          $cataupageNode = Node::load($cataupage_node_id);
          $cataupageNode->set('field_bf_catau_page_status', $pageStatus);
          $updatecataupageNode = $cataupageNode->save();
          if($updatecataupageNode) {
            $arrData = array(
              "type"                              => $res->node_type,
              "title"                             => $res->node_title,
              "field_bf_catau_page_catalogue"     => $res->catalogue_id,
              "field_bfcatalogue_assigning_user"  => $res->catau_node_id,
              "field_bf_catau_page_userid"        => $res->catau_userid,
              "field_bf_catau_page_number"        => $res->catau_page_number,
              "field_bf_catau_page_date"          => date('Y-m-d\TH:i:s', REQUEST_TIME),
              "field_bf_catau_page_status"        => $pageStatus
            );
            $encodedata = json_encode($arrData);
            $node_data = array(
              "type"                              => "bf_cat_assuser_assignees_history",
              "title"                             => $cataupageNode->getTitle(),
              'field_bf_cataupageassignee_date'   => REQUEST_TIME,
              'field_bf_cataupageassignee_json'   => $encodedata,
              'field_bf_cataupageassignee_nid'    => $cataupage_node_id,
              'field_bf_cataupageassigne_status'  => $pageStatus,
              'uid'                               => $userId
            );
            $node1 = Node::create($node_data);
            $node1->save();
            $nodeHistory = $node1->id();
          }
        }
        \Drupal::logger('catalogue-workflow-allpage-update')->notice('@status || %inputData ||  %updatecataupageNode ||  %encodedata ||  %nodeHistory],', [
          '@status' => 'catalogue workflow page level status updated successfully',
          '%inputData' => $inputData,
          '%updatecataupageNode' => $updatecataupageNode,
          '%encodedata' => $encodedata,
          '%nodeHistory' => $nodeHistory,
        ]);
        return true;
      } else {
        \Drupal::logger('catalogue-workflow-allpage-update')->notice('@status || %inputData],', [
          '@status' => 'catalogue workflow page level status not updated successfully. There is no record in catalogue assign pages.',
          '%inputData' => $inputData,
        ]);
        return true;
      }
    } catch(\Exception $e){
      $results = json_decode(['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')]);
      \Drupal::logger('catalogue-workflow-allpage-update')->notice('@status || %inputData],', [
        '@status' => 'catalogue workflow page level status not updated successfully. There is no record in catalogue assign pages.'.$results,
        '%inputData' => $inputData,
      ]);
      return false;
    }
  }
    
  /**
   * Function :: Get all catalogue by briefing form id.
   */
  public function GetAllCatalogueByBFId($briefingFormID) {
    // Select query.
    $query = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfrefid');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.entity_id = nfbfrefid.entity_id');
    $query->leftjoin('node__field_catalogue_status', 'nfcs', 'nfcs.entity_id = nfbfrefid.entity_id');
    $query->addField('nfbfrefid', 'entity_id', 'catalogue_id');
    $query->addField('nfbfrefid', 'field_briefing_form_reference_id_target_id', 'field_briefing_form_reference_id');
    $query->addField('nfcs', 'field_catalogue_status_value', 'field_catalogue_status');
    $query->condition('nfbfrefid.field_briefing_form_reference_id_target_id', $briefingFormID, '=');
    $query->condition('nfcs.field_catalogue_status_value', $briefingFormID, '=');
    $result = $query->execute()->fetchAll();
    return $result;
  }

  /**
   * Function :: Check and Update the briefing form catalogue all page status.
   */
  public function CheckAndUpdateBFPageStatus($jsondata) {

    $briefingFormID  = $jsondata['field_briefingform_id'];
    $catalogueId     = $jsondata['field_catalogue_id'];
    $workflowStatus  = $jsondata['field_workflow_status'];
    $userId          = $jsondata['field_user_id'];
    $userType        = $jsondata['field_user_type'];
    // Load briefing form node by briefing form id.
    $BFNode          = Node::load($briefingFormID);
    $existBFStatus   = $BFNode->field_briefing_form_status->value;
    // Load catalogue node by catalogue id.
    $catalogueNode   = Node::load($catalogueId);
    $existCatStatus  = $catalogueNode->field_catalogue_status->value;
    if(!empty($userType) && ($userType == 'leader' || $userType == 'manager')) { // Team Leader / Manager.

      if(!empty($workflowStatus) && $workflowStatus == 'catalogue_completed') { // Catalogue Completed - Team Leader / Manager.

        $GetAllCatPageStatus = $this->CheckBFCatalogueAllAssignedPageStatusWithOutUserId($catalogueId);
        if($GetAllCatPageStatus) {
          // Have to update asset status and catalogues status and work flow status is completed.
          $catalogueNode->set('field_catalogue_status', 'clipped');
          $updateCatalogueNode = $catalogueNode->save();
          if($updateCatalogueNode) {
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }
        } else {
          // Return Response - All pages are not completed.
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.'];
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_hold') { // Catalogue Hold - Team Leader / Manager.
 
        // Have to update Briefingform Assets status as catalogue_hold.
        $GetBFAllAssetStatus = $this->GetBFAllAssetStatusByParams($briefingFormID, $catalogueId);
        if(!empty($GetBFAllAssetStatus)) {
          foreach($GetBFAllAssetStatus as $assets) {
            $assetNodeId = $assets['asset_node_id'];
            $assetNode   = Node::load($assetNodeId);
            $existassetstatus = $assetNode->field_bf_asset_status->value;
            $assetNode->set('field_bf_asset_status', 'hold');
            $updateAssets = $assetNode->save();
            if($updateAssets) {
              // Update hold status to all catalogue pages by catalogue id.
              $updateAllPageStatus = $this->updateBFAllPageStatus($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_re_process', $userId, $userType);
              if($updateAllPageStatus) {
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                // If process is failure means have to role back the status.
                $assetNode->set('field_bf_asset_status', $existassetstatus);
                $updateAssets = $assetNode->save();
              }
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }
  
      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_withdrawn') { // Catalogue Withdraw - Team Leader / Manager.
 
        // Have to update Briefingform Assets status as catalogue_hold.
        $GetBFAllAssetStatus = $this->GetBFAllAssetStatusByParams($briefingFormID, $catalogueId);
        if(!empty($GetBFAllAssetStatus)) {
          foreach($GetBFAllAssetStatus as $assets) {
            $assetNodeId = $assets['asset_node_id'];
            $assetNode = Node::load($assetNodeId);
            $existassetstatus = $assetNode->field_bf_asset_status->value;
            $assetNode->set('field_bf_asset_status', 'withdraw');
            $updateAssets = $assetNode->save();
            if($updateAssets) {
              // update catalogue status.
              $catalogueNode->set('field_catalogue_status', 'withdrawn');
              $updateCatalogueNode = $catalogueNode->save();
              if($updateCatalogueNode) {
                // Update BF all page status as catalogue_withdrawn.
                $updateAllPageStatus = $this->updateBFAllPageStatus($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_withdrawn', $userId, $userType);
                if($updateAllPageStatus) {
                  $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
                } else {
                  $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                  // If process is failure means have to role back the status.
                  $assetNode->set('field_bf_asset_status', $existassetstatus);
                  $updateAssets = $assetNode->save();
                }
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
              }
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_assign') { // To Assign - Team Leader / Manager.

        // update briefing form status.
        $BFNode->set('field_briefing_form_status', 'in_process');
        $updateBFNode = $BFNode->save();
        // Load catalogue by node id.
        $catalogueNode1   = Node::load($catalogueId);
        // Existing catalogue status.
        $existCatStatus1 = $catalogueNode1->field_catalogue_status->value;
        // Update catalogue status.
        $catalogueNode1->set('field_catalogue_status', 'assign');
        $updateCatalogueNode1 = $catalogueNode1->save();
        // Check catalogue status is updated or not.  
        if($updateCatalogueNode1) {
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        } else {
          // If process is failure means have to role back the status.
          $BFNode->set('field_briefing_form_status', $existBFStatus);
          $updateAssets = $assetNode->save();
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_clipping') { // To Clipping - Team Leader / Manager.

        // update briefing form status.
        $BFNode->set('field_briefing_form_status', 'in_process');
        $updateBFNode = $BFNode->save();
        $catalogueNode1   = Node::load($catalogueId);
        $existCatStatus1 = $catalogueNode1->field_catalogue_status->value;
        // update catalogue status.
        $catalogueNode1->set('field_catalogue_status', 'clipping');
        $updateCatalogueNode1 = $catalogueNode1->save();
        if($updateCatalogueNode1) {
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        } else {
          // If process is failure means have to role back the status.
          $BFNode->set('field_briefing_form_status', $existBFStatus);
          $updateAssets = $assetNode->save();
          // If process is failure means have to role back the status.
          $catalogueNode1->set('field_catalogue_status', $existCatStatus1);
          $updateCatalogueNode1 = $catalogueNode1->save();
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_ready_to_client_review') { // Ready to Client Review - Team Leader / Manager.

        // All BF Catalogue Assignees pages to next level data insert.
        $GetAssigningData = $this->GetAndInsertCatalogueAllPagesByCatalogueIdAndUserType($catalogueId, $userType = 'leader', $pageStatus = '', $workflowStatus = 'catalogue_ready_to_client_review', $NextUserType = 'poc_user');
        if($GetAssigningData) {
          // Check all catalogue pages are updated as ready to client review status.
          $checkAllpageStatus = $this->checkAllCataloguePageStatusByParams($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_client_review', $userType = 'poc_user', $userId);
          if($GetAssigningData) {
            $bf_clientId = $BFNode->field_briefing_form_client_id->target_id;
            // Update briefing form status.
            $BFNode->set('field_briefing_form_status', 'ready');
            $updateBFNode = $BFNode->save();
            if($updateBFNode) {
              // send mail to clinet for catalogue ready for client review.
              $sendmail = $this->SendCommonMailFunctionWithParams($briefingFormID, $catalogueId, $bf_clientId, $field_mail_type = '5');
              $sendMailDecode = json_decode($sendmail, true);
              $sendmail_status = $sendMailDecode['status'];
              $sendmail_status_msg = $sendMailDecode['status_message'];
              $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully. '.$sendmail_status_msg]; // sending success 
              /*if($sendMailDecode['status']=='success') {
                $sendmail_status = $sendMailDecode['status'];
                $sendmail_status_msg = $sendMailDecode['status_message'];
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully. '.$sendmail_status_msg]; // sending success 
                
              } else { 
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully. '.$sendmail_status_msg]; // sending success response.
              }*/
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_finished') { // Finished - Team Leader / Manager.
        // Update catalogue status.
        $BFNode = Node::load($briefingFormID);
        $catalogueNode1   = Node::load($catalogueId);
        $existCatStatus1 = $catalogueNode1->field_catalogue_status->value;
        $catalogueNode1->set('field_catalogue_status', 'finished');
        $updateCatalogueNode1 = $catalogueNode1->save();
        if($updateCatalogueNode1) {
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        } else {
          $catalogueNode1->set('field_catalogue_status', $existCatStatus1);
          $updateCatStatus = $catalogueNode1->save();
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_published') { // Published - Team Leader / Manager.
        
        $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_cancelled') { // Cancelled - Team Leader / Manager.
        
        $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.

      } else {
        $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
      }

    } else if(!empty($userType) && $userType == 'supervisor') { // Quality Assurance.

      // Check the post status is completed
      if(!empty($workflowStatus) && $workflowStatus == 'catalogue_completed') { // Catalogue Completed - Quality Assurance.

        $GetAllCatPageStatus = $this->CheckBFCatalogueAllAssignedPageStatusWithOutUserId($catalogueId);
        if(!isset($GetAllCatPageStatus['status']) && $GetAllCatPageStatus) {
          // Have to update asset status and catalogues status and work flow status is completed.
          $catalogueNode->set('field_catalogue_status', 'clipped');
          $updateCatalogueNode = $catalogueNode->save();
          if($updateCatalogueNode) {
            // Send email notification to Team leader and QC(if assigned).
            $SendMail = $this->SendMailCurrentUserAllPageClippingCompletedTOTeamLeaderAndQC($briefingFormID, $catalogueId, $pageNo = '', $userId);
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }
        } else {
          // Return Response - All pages are not completed.
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.'];
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_hold') { // Catalogue Hold - Quality Assurance.
 
        // Have to update Briefingform Assets status as catalogue_hold.
        $GetBFAllAssetStatus = $this->GetBFAllAssetStatusByParams($briefingFormID, $catalogueId);
        if(!empty($GetBFAllAssetStatus)) {
          foreach($GetBFAllAssetStatus as $assets) {
            $assetNodeId = $assets['asset_node_id'];
            $assetNode = Node::load($assetNodeId);
            $existassetstatus = $assetNode->field_bf_asset_status->value;
            $assetNode->set('field_bf_asset_status', 'hold');
            $updateAssets = $assetNode->save();
            if($updateAssets) {
              // Update hold status to all catalogue pages by catalogue id.
              $updateAllPageStatus = $this->updateBFAllPageStatus($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_hold', $userId, $userType);
              if($updateAllPageStatus) {
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                // If process is failure means have to role back the status.
                $assetNode->set('field_bf_asset_status', $existassetstatus);
                $updateAssets = $assetNode->save();
              }
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($pageStatus) && $workflowStatus == 'catalogue_withdrawn') { // Catalogue Withdraw - Quality Assurance.
 
        // Have to update Briefingform Assets status as catalogue_hold.
        $GetBFAllAssetStatus = $this->GetBFAllAssetStatusByParams($briefingFormID, $catalogueId);
        if(!empty($GetBFAllAssetStatus)) {
          foreach($GetBFAllAssetStatus as $assets) {
            $assetNodeId = $assets['asset_node_id'];
            $assetNode = Node::load($assetNodeId);
            $existassetstatus = $assetNode->field_bf_asset_status->value;
            $assetNode->set('field_bf_asset_status', 'withdraw');
            $updateAssets = $assetNode->save();
            // update catalogue status.
            $catalogueNode->set('field_catalogue_status', 'withdrawn');
            $updateCatalogueNode = $catalogueNode->save();
            if($updateAssets) {
              // Update BF all page status as catalogue_withdrawn.
              $updateAllPageStatus = $this->updateBFAllPageStatus($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_withdrawn', $userId, $userType);
              if($updateAllPageStatus) {
                $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
                // If process is failure means have to role back the status.
                $assetNode->set('field_bf_asset_status', $existassetstatus);
                $updateAssets = $assetNode->save();
              }
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_assign') { // To Assign - Team Leader / Manager.

        // update briefing form status.
        $BFNode->set('field_briefing_form_status', 'in_process');
        $updateBFNode = $BFNode->save();
        // Load catalogue by node id.
        $catalogueNode1   = Node::load($catalogueId);
        // Existing catalogue status.
        $existCatStatus1 = $catalogueNode1->field_catalogue_status->value;
        // Update catalogue status.
        $catalogueNode1->set('field_catalogue_status', 'assign');
        $updateCatalogueNode1 = $catalogueNode1->save();
        // Check catalogue status is updated or not.  
        if($updateCatalogueNode1) {
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        } else {
          // If process is failure means have to role back the status.
          $BFNode->set('field_briefing_form_status', $existBFStatus);
          $updateAssets = $assetNode->save();
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_clipping') { // To Clipping - Quality Assurance.

        // update briefing form status.
        $BFNode->set('field_briefing_form_status', 'in_process');
        $updateBFNode = $BFNode->save();
        // update catalogue status.
        $catalogueNode->set('field_catalogue_status', 'clipping');
        $updateCatalogueNode = $catalogueNode->save();
        if($updateBFNode && $updateCatalogueNode) {
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        } else {
          // If process is failure means have to role back the status.
          $BFNode->set('field_briefing_form_status', $existBFStatus);
          $updateAssets = $assetNode->save();
          // If process is failure means have to role back the status.
          $catalogueNode->set('field_catalogue_status', $existCatStatus);
          $updateCatalogueNode = $catalogueNode->save();
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_ready_to_client_review') { // Ready to Client Review - Quality Assurance.
        
        // All BF Catalogue Assignees pages to next level data insert.
        $GetAssigningData = $this->GetAndInsertCatalogueAllPagesByCatalogueIdAndUserType($catalogueId, $userType = 'leader', $pageStatus = '', $workflowStatus = 'catalogue_ready_to_client_review', $NextUserType = 'poc_user');
        if($GetAssigningData) {
          // Check all catalogue pages are updated as ready to client review status.
          $checkAllpageStatus = $this->checkAllCataloguePageStatusByParams($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_client_review', $userType = 'poc_user', $userId);
          if($GetAssigningData) {
            // Update briefing form status.
            $BFNode->set('field_briefing_form_status', 'ready');
            $updateBFNode = $BFNode->save();
            if($updateBFNode) {
              $bf_clientId = $BFNode->field_briefing_form_client_id->target_id;
              // send mail to clinet for catalogue ready for client review.
              $sendmail = $this->SendCommonMailFunctionWithParams($briefingFormID, $catalogueId, $bf_clientId, $field_mail_type = '5');
              if($sendmail) {
                $decodeData = json_decode($sendmail);
                $sendmail_status_msg = $decodeData['status_message'];
              } else { $sendmail_status_msg = 'mail not send successfully'; }
              $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.'.$sendmail_status_msg]; // sending success response.
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
            }
          }
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_finished') { // Finished - Quality Assurance.
        // Update catalogue status.
        $BFNode = Node::load($briefingFormID);
        $catalogueNode1   = Node::load($catalogueId);
        $existCatStatus1 = $catalogueNode1->field_catalogue_status->value;
        $catalogueNode1->set('field_catalogue_status', 'finished');
        $updateCatalogueNode1 = $catalogueNode1->save();
        if($updateCatalogueNode1) {
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        } else {
          $catalogueNode1->set('field_catalogue_status', $existCatStatus1);
          $updateCatStatus = $catalogueNode1->save();
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_published') { // Published - Quality Assurance.
        
        $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_cancelled') { // Cancelled - Quality Assurance.
        
        $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.

      } else {
        $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
      }

    } else if(!empty($userType) && $userType == 'operator') { // Designer.
  
      if(!empty($workflowStatus) && $workflowStatus == 'catalogue_clipping') { // Clipping - Designer.
        // update briefing form status.
        $BFNode->set('field_briefing_form_status', 'in_process');
        $updateBFNode = $BFNode->save();
        // update catalogue status.
        $catalogueNode1   = Node::load($catalogueId);
        $catalogueNode1->set('field_catalogue_status', 'clipping');
        $updateCatalogueNode1 = $catalogueNode1->save();
        if($updateBFNode) { // && $updateCatalogueNode1
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        } else {
          // If process is failure means have to role back the status.
          $BFNode->set('field_briefing_form_status', $existBFStatus);
          $updateAssets = $assetNode->save();
          // If process is failure means have to role back the status.
          $catalogueNode->set('field_catalogue_status', $existCatStatus);
          $updateCatalogueNode = $catalogueNode->save();
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }
      }
    } else if(!empty($userType) && $userType == 'poc_user') { // POC Clients

      if(!empty($workflowStatus) && $workflowStatus == 'catalogue_approved') { // Approved - POC Clients.

        $updateAllPageStatus = $this->updateBFAllPageStatusByType($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_approved', $userId, $userType);
        if($updateAllPageStatus) {
          // Update catalogue status.
          $BFNode = Node::load($briefingFormID);
          $existCatStatus = $catalogueNode->field_catalogue_status->value;
          $catalogueNode->set('field_catalogue_status', 'approved');
          $updateCatStatus = $catalogueNode->save();
          if($updateCatStatus) {
            // Check all catalogue status is approved against the briefing form id in catalogue content type referenced.
            /*$CheckAllCatalogueStatus = $this->CheckAllCatalogueStatusIsApprovedOrNot($briefingFormID, $catalogueId, $workflowStatus);
            if($CheckAllCatalogueStatus) {
              // If all catalogue pages are approved means have to update briefing form status as completed.
              $CatalogueNodeIds = $CheckAllCatalogueStatus;
            }*/
            $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
          } else {
            $catalogueNode->set('field_catalogue_status', $existCatStatus);
            $updateCatStatus = $catalogueNode->save();
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_finished') { // Finished - POC Clients.
        // Update catalogue status.
        $BFNode = Node::load($briefingFormID);
        $catalogueNode1   = Node::load($catalogueId);
        $existCatStatus1 = $catalogueNode1->field_catalogue_status->value;
        $catalogueNode1->set('field_catalogue_status', 'finished');
        $updateCatalogueNode1 = $catalogueNode1->save();
        if($updateCatalogueNode1) {
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
        } else {
          $catalogueNode1->set('field_catalogue_status', $existCatStatus1);
          $updateCatStatus = $catalogueNode1->save();
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
        }

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_published') { // Published - POC Clients.
        
        $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_cancelled') { // Cancelled - POC Clients.
        
        $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.

      } else if(!empty($workflowStatus) && $workflowStatus == 'catalogue_withdrawn') { // Withdrawn - POC Clients.

        // Have to update Briefingform Assets status as catalogue_hold.
        $GetBFAssetStatus = $this->GetBFAssetStatusByParams($briefingFormID, $catalogueId);
        if(!empty($GetBFAssetStatus)) {
          $assetNodeId = $GetBFAssetStatus;
          $assetNode = Node::load($assetNodeId);
          $existassetstatus = $assetNode->field_bf_asset_status->value;
          $assetNode->set('field_bf_asset_status', 'withdraw');
          $updateAssets = $assetNode->save();
          if($updateAssets) {
            // Update BF all page status as catalogue_withdrawn.
            $updateAllPageStatus = $this->updateBFAllPageStatus($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_withdrawn', $userId, $userType);
            // Update catalogue workflow status as catalogue_hold.
            //$updateCatalogueWorkflow = $this->updateCatalogueWorkflowStatusByparams($briefingFormID, $catalogueId, $workflowStatus = 'catalogue_withdrawn', $userId);
            if($updateAllPageStatus) {
              $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.']; // sending success response.
            } else {
              $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
              // If process is failure means have to role back the status.
              $assetNode->set('field_bf_asset_status', $existassetstatus);
              $updateAssets = $assetNode->save();
            }
          } else {
            $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
          }
        }
      } else {
        $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
      }

    } else {
      $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.']; // sending error response.
    }
    return $result;
  }

  /**
   * Function :: Get all assets by briefing forom id, catalogue id, type is catalogue.
   */
  public function GetBFAllAssetStatusByParams($briefingFormID, $catalogueId) {
    $arrData = array();
    // Select query.
    $query = \Drupal::database()->select('node__field_asset_briefingform_id', 'nfabfid');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_asset_catalogue_id', 'nfbfacid', 'nfbfacid.entity_id = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_asset_status', 'nfbfacs', 'nfbfacs.entity_id = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_form_type', 'nfbfft', 'nfbfft.entity_id = nfabfid.entity_id');
    $query->addField('nfabfid', 'entity_id', 'asset_node_id');
    $query->addField('nfbfacs', 'field_bf_asset_status_value', 'asset_status');
    $query->addField('nfbfft', 'field_bf_form_type_value', 'asset_form_type');
    $query->condition('nfabfid.field_asset_briefingform_id_target_id', $briefingFormID, '=');
    $query->condition('nfbfacid.field_bf_asset_catalogue_id_target_id', $catalogueId, '=');
    $query->condition('nfbfft.field_bf_form_type_value', 'catalogue', '=');
    $results = $query->execute()->fetchAll();
    if($results) {
      foreach($results as $res) {
        $arrData[] = array(
          'asset_node_id'   => $res->asset_node_id,
          'asset_status'    => $res->asset_status,
          'asset_form_type' => $res->asset_form_type
        );
      }
      return $arrData;
    } else {
      return $arrData;
    }
  }

  /**
   * Funtion :: Send common mail function with params.
   */
  public function SendCommonMailFunctionWithParams($briefingFormId, $catalogueId, $bf_clientId, $field_mail_type) {

    /**********************************************************/
    /******* Sending Mail using CURL Function - Start *********/
    /**********************************************************/
    header("Content-Type: text/json;");
    $host = \Drupal::request()->getSchemeAndHttpHost();
    // Curl function.
    $url = $host.'/briefingform/bfpostmail';
    $data = array(
      "briefingform_id"   => $briefingFormId,
      "catalogue_id"      => $catalogueId,
      "field_client_id"   => $bf_clientId,
      "field_mail_type"   => $field_mail_type
    );
    $data_string = json_encode($data);
    $header = array("Content-Type: application/json");
    $curl   = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data_string
    ));
    $response = curl_exec($curl);
    \Drupal::logger('catalogue-workflow-sendmail')->notice('@response || %data_string],', [
      '@response' => json_encode($response),
      '%data_string' => $data_string,
    ]);
    curl_close($curl);
    return $response;
    /**********************************************************/
    /******** Sending Mail using CURL Function - End **********/
    /**********************************************************/
  }
  
  /**
   * Function :: Update briefing form catalogue all page status by user type.
   */
  public function updateBFAllPageStatusByType($briefingFormID, $catalogueId, $pageStatus, $userId, $userType) {
    $inputData = json_encode(array($briefingFormID, $catalogueId, $pageStatus, $userId, $userType));
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpuid', 'nfbfcpuid.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_clipping_count', 'nfbfccc', 'nfbfccc.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'cataupage_node_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catau_page_number');
    $query->addField('nfbfcau', 'field_bfcatalogue_assigning_user_target_id', 'catau_node_id');
    $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'catau_date');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catau_page_status');
    $query->addField('nfbfcpuid', 'field_bf_catau_page_userid_target_id', 'catau_userid');
    $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'acatau_user_role');
    $query->addField('nfbfccc', 'field_bf_catau_clipping_count_value', 'catau_clipping_count');
    $query->addField('nfd', 'type', 'node_type');
    $query->addField('nfd', 'title', 'node_title');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcpur.field_bf_catau_assigng_user_role_value', $userType);
    $result = $query->execute()->fetchAll();
    if($result) {
      foreach($result as $res) {
        $cataupage_node_id = $res->cataupage_node_id;
        $cataupageNode = Node::load($cataupage_node_id);
        $cataupageNode->set('field_bf_catau_page_status', $pageStatus);
        $updatecataupageNode = $cataupageNode->save();
        if($updatecataupageNode) {
          $arrData = array(
            "type"                              => $res->node_type,
            "title"                             => $res->node_title,
            "field_bf_catau_page_catalogue"     => $res->catalogue_id,
            "field_bfcatalogue_assigning_user"  => $res->catau_node_id,
            "field_bf_catau_page_userid"        => $userId,
            "field_bf_catau_page_number"        => $res->catau_page_number,
            "field_bf_catau_page_date"          => date('Y-m-d\TH:i:s', REQUEST_TIME),
            "field_bf_catau_page_status"        => $pageStatus
          );
          $encodedata = json_encode($arrData);
          $node_data = array(
            "type"                              => "bf_cat_assuser_assignees_history",
            "title"                             => $cataupageNode->getTitle(),
            'field_bf_cataupageassignee_date'   => REQUEST_TIME,
            'field_bf_cataupageassignee_json'   => $encodedata,
            'field_bf_cataupageassignee_nid'    => $cataupage_node_id,
            'field_bf_cataupageassigne_status'  => $pageStatus,
            'uid'                               => $userId
          );
          $node1 = Node::create($node_data);
          $node1->save();
          $nodeHistory = $node1->id();
        }
      }
      \Drupal::logger('catalogue-workflow-allpage-update')->notice('@status || %inputData ||  %updatecataupageNode ||  %encodedata ||  %nodeHistory],', [
        '@status' => 'catalogue workflow page level status updated successfully',
        '%inputData' => $inputData,
        '%updatecataupageNode' => $updatecataupageNode,
        '%encodedata' => $encodedata,
        '%nodeHistory' => $nodeHistory,
      ]);
      return true;
    } else {
      \Drupal::logger('catalogue-workflow-allpage-update')->notice('@status || %inputData],', [
        '@status' => 'catalogue workflow page level status not updated successfully',
        '%inputData' => $inputData,
      ]);
      return false;
    }
  }

  /**
   * Function :: Check all catalogue status is approved or not.
   */
  public function CheckAllCatalogueStatusIsApprovedOrNot($briefingFormID, $catalogueId, $workflowStatus) {
    // Get all catalogue id from briefing form id in catalogue content type by referenced.
    $CheckAndGetData = $this->GetAndCheckCatalogueStatusByParams($briefingFormID, $condition = '!=');
    if($CheckAndGetData) {
      return false; // it will return all page not approved as => NO.
    } else {
      $arrData = array();
      $GetCatalogueIds = $this->GetAndCheckCatalogueStatusByParams($briefingFormID, $condition = '=');
      if($GetCatalogueIds){
        foreach($GetCatalogueIds as $res) {
          $arrData[] = $res->catalogue_id;
        }
      }
      return $arrData; // it will return all page approved as => YES.
    }
  }

  /**
   * Function :: Get and check catalogue status and return catalogie id.
   */
  public function GetAndCheckCatalogueStatusByParams($briefingFormID, $condition) {
    // Select query.
    $query = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfredid');
    $query->leftjoin('node__field_catalogue_status', 'nfcs', 'nfcs.entity_id = nfbfredid.entity_id');
    $query->addField('nfbfredid', 'entity_id', 'catalogue_id');
    $query->addField('nfcs', 'field_catalogue_status__value', 'catalogue_status');
    $query->condition('nfbfredid.field_briefing_form_reference_id_target_id', $briefingFormID);
    $query->condition('nfcs.field_catalogue_status__value', 'approved', $condition);    
    $result = $query->execute()->fetchAll();
    return $result;
  }

  /**
   * Funtion :: Check all catalogue page status is given params are updated
   */
  public function checkAllCataloguePageStatusByParams($briefingFormID, $catalogueId, $workflowStatus, $userType, $userId) {
    // Get All Catalogue id's from briefing form id.
    $GetAllCatalogueIds = $this->GetAllCatalogueIdFromBriefingFromId($briefingFormID);
    if($GetAllCatalogueIds) {
      // Select query.
      $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
      $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
      $query->addField('nfbfcpc', 'entity_id', 'cataupage_node_id');
      $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
      $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catau_page_status');
      $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'acatau_user_role');
      $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $GetAllCatalogueIds, 'IN');
      $query->condition('nfbfcps.field_bf_catau_page_status_value', $workflowStatus, '!=');
      $query->condition('nfbfcpur.field_bf_catau_assigng_user_role_value', $userType);
      $result = $query->execute()->fetchAll();
      if($result) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }

  /**
   * Function :: Get All Catalogue id from briefing form id.
   */
  public function GetAllCatalogueIdFromBriefingFromId($briefingformId) {
    $arrData = array();
    // Select query.
    $query = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfredid');
    $query->addField('nfbfredid', 'entity_id', 'catalogue_id');
    $query->condition('nfbfredid.field_briefing_form_reference_id_target_id', $briefingformId);
    $result = $query->execute()->fetchAll();
    if($result) {
      foreach($result as $res) {
        $arrData[] = $res->catalogue_id;
      }
    }
    return $arrData;
  }

  /**
   * Function :: Send mail current user all page clipping completed to team leader and QC.
   */
  public function SendMailCurrentUserAllPageClippingCompletedTOTeamLeaderAndQC($briefingFormId, $catalogueId, $pageNo, $userId) {
    // Get Catalogue Assigned page details.
    $getCatPageAssignedDetails = $this->GetCatPageAssignedDetailsByParam($briefingFormId, $catalogueId, $pageNo);
    $teamleaderId = $getCatPageAssignedDetails['field_bf_catasur_loggedin_uid'];
    /**********************************************************/
    /******* Sending Mail using CURL Function - Start *********/
    /**********************************************************/
    header("Content-Type: text/json;");
    $host = \Drupal::request()->getSchemeAndHttpHost();
    // Curl function.
    $url = $host.'/briefingform/clippingqccompletedsendmail';
    $GetBriefingForm  = $this->GetBriefingFormByNodeId($briefingFormId);
    $bf_client_id     = (isset($GetBriefingForm->field_briefing_form_client_id->target_id) && !empty($GetBriefingForm->field_briefing_form_client_id->target_id))?$GetBriefingForm->field_briefing_form_client_id->target_id:null;
    $data = array(
      "briefingform_id" => $briefingFormId,
      "catalogue_id"    => $catalogueId,
      "field_client_id" => $bf_client_id,
      "field_mail_type" => '9',
      "page_number"     => $pageNo,
      "user_id"         => $userId,
      'teamleader_id'   => $teamleaderId,
      'type'            => 'operator'
    );
    $data_string = json_encode($data);
    $header = array("Content-Type: application/json");
    $curl   = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data_string
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    /**********************************************************/
    /******** Sending Mail using CURL Function - End **********/
    /**********************************************************/
    return $response;
  }

  /**
   * Function :: Get catalogue assigned page details by params (briefing form id, catalogue id, page number)
   */
  public function GetCatPageAssignedDetailsByParam($briefingFormID, $catalogueId, $pageNo) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbcpid');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbcpid.entity_id');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbcpid.entity_id');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcau.field_bfcatalogue_assigning_user_target_id');
    $query->leftjoin('node__field_bf_catasur_briefingform_id', 'nfbfcbfid', 'nfbfcbfid.entity_id = nfd.nid');
    $query->leftjoin('node__field_bf_catasur_loggedin_userid', 'nfbfcluid', 'nfbfcluid.entity_id = nfbfcbfid.entity_id');
    $query->addField('nfbcpid', 'entity_id', 'field_catau_entity_id');
    $query->addField('nfbcpid', 'field_bf_catau_page_catalogue_target_id', 'field_catau_catalogue_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'field_bf_catau_page_number');
    $query->addField('nfbfcau', 'field_bfcatalogue_assigning_user_target_id', 'field_bf_cataur_id');
    $query->addField('nfd', 'nid', 'field_bf_cataur_entity_id');
    $query->addField('nfbfcbfid', 'field_bf_catasur_briefingform_id_target_id', 'field_bf_catasur_bf_id');
    $query->addField('nfbfcluid', 'field_bf_catasur_loggedin_userid_target_id', 'field_bf_catasur_loggedin_uid');
    $query->condition('nfbcpid.field_bf_catau_page_catalogue_target_id', $catalogueId, '=');
    if($pageNo) {
      $query->condition('nfbfcpn.field_bf_catau_page_number_value', $pageNo, '=');
    }
    $query->condition('nfbfcbfid.field_bf_catasur_briefingform_id_target_id', $briefingFormID, '=');
    $query->orderBy('nfbcpid.entity_id', 'ASC');
    $query->range(0,1);
    $results = $query->execute()->fetchAssoc();
    return $results;
  }
}
?>