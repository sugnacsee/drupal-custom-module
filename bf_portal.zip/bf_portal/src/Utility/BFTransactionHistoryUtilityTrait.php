<?php
namespace Drupal\bf_portal\Utility;

use Drupal\Component\Utility\UrlHelper;
use Drupal\file\Entity\File;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Drupal\paragraphs\Entity\Paragraph;
use Aws\S3\S3Client;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Database\Database;
use Drupal\Core\Cache\Cache;
use Drupal\workflow\Entity\WorkflowConfigTransition;
use Drupal\workflow\Entity\WorkflowState;
use Drupal\workflow\Entity\Workflow;
use Drupal\workflow\Entity\WorkflowManager;
use Drupal\workflow\Entity\WorkflowTransition;
use Drupal\Core\Datetime\Entity\DateFormat;

trait BFTransactionHistoryUtilityTrait
{

  /**
   * Briefing form - save all type of transaction history.
   */
  public function BFTransactionHistory($method, $type, $responseData, $InsUserId, $result) {
    $encodeData = json_encode($responseData);
    if($method=='POST') {
      $createdBy    = $InsUserId;
      $createdDate  = date('Y-m-d H:i:s');
      $updatedBy    = null;
      $updatedDate  = null;
    } else {
      $createdBy    = null;
      $createdDate  = null;
      $updatedBy    = $InsUserId;
      $updatedDate  = date('Y-m-d H:i:s');
    }
    $status         = $result['status'];
    $status_message = $result['status_message'];
    $fieldArray = array(
      'bf_th_method' 		 		=> $method,
      'bf_th_type_name' 		=> $type,
      'bf_th_content' 	    => $encodeData,
      'bf_th_created_by' 	  => $createdBy,
      'bf_th_created_date'  => $createdDate,
      'bf_th_updated_by' 	  => $updatedBy,
      'bf_th_updated_date'  => $updatedDate,
      'bf_th_status_msg' 	  => $status_message,
      'bf_th_status'	      => $status,
    );
    try{
      \Drupal::logger('Briefingform-history')->info('%fieldArray],', [
        '%fieldArray' => json_encode($fieldArray)
      ]);
      // Database connection.
      $db = \Drupal::database();
      $insertQry = $db->insert('briefingform_transaction_history')->fields($fieldArray)->execute();
      if($insertQry){
        return true;
      } else {
        return false;
      }
    } catch (Exception $e) {
      return $e;
    }
  }
}
?>