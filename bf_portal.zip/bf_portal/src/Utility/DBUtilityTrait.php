<?php
namespace Drupal\bf_portal\Utility;

use Drupal\Component\Utility\UrlHelper;
use Drupal\field\Entity\FieldConfig;
use Drupal\file\Entity\File;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Drupal\paragraphs\Entity\Paragraph;
use Aws\S3\S3Client;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Database\Database;
use Drupal\Core\Cache\Cache;
use Drupal\workflow\Entity\WorkflowConfigTransition;
use Drupal\workflow\Entity\WorkflowState;
use Drupal\workflow\Entity\Workflow;
use Drupal\workflow\Entity\WorkflowManager;
use Drupal\workflow\Entity\WorkflowTransition;
use Drupal\Core\Datetime\Entity\DateFormat;
use Drupal\Core\Database\Query;
//use Drupal\bf_portal\Utility\BFTransactionHistoryUtilityTrait;

trait DBUtilityTrait
{

  //use BFTransactionHistoryUtilityTrait;

  /**
  * Function to fetch data from tables.
  */
  public function GetJSONData($jsondata) {
      $arrData = array();
      foreach($jsondata as $resData) {
        if($resData['type'] != 'briefingform') {
          $type = explode('--',$resData['type']);
          $arrData['type'] = $type[1];
        } else {
          $arrData['type'] = $resData['type'];
        }
        if(isset($resData['id'])&& !empty($resData['id'])) {
          $arrData['nodeId'] = $resData['id'];
        } else {
          $arrData['nodeId'] = '';
        }
        foreach($resData['attributes'] as $key => $value) {
            $arrData[$key] = $value;
        }
      }
      return $arrData;
    }

    function getRelationShipID($relationships) {
      // Get Author id from user table using param of UUID.
      $query = \Drupal::database()->select('users', 'u');
      $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = u.uid');
      $query->fields('u', array('uid', 'uuid'));
      $query->fields('ufd', array('name'));
      $query->condition('u.uuid', $relationships['id']);
      $results = $query->execute()->fetchAssoc();
      if(!empty($results['uid']))
      {
          return $results['uid'];
      } else {
          return 0;
      }
    }

    /**
   * Function to fetch data from tables.
   */
  public function SetNodeFields() {
    return $field = array(
        'type',
        'title',
        'field_catalogue_title',
        'field_enable_animation_required',
        'field_enable_catalogue_ecommerce',
        'field_final_catalogue_output',
        'field_enable_multiple_versions',
        'field_term_and_conditions',
        'field_briefing_form_status',
        'field_live_dates',
        'field_preview_date',
        'field_briefing_form_author',
        'field_bf_catalogue_portal',
    );      
  }

  /**
  * Function :: Get Briefing form by node id.
  */
  public function GetBriefingFormByNodeId($nid) {
    if($nid) {
      $node = \Drupal\node\Entity\Node::load($nid);
      return $node;
    } else {
      return false;
    }
  }

  /**
  * Function to fetch data from assets type tables.
  */
  public function GetAssetsTypeDetails() {

    $query = \Drupal::database()->select('node__field_briefing_form_assets_type', 'at');
    $query->fields('at', ['entity_id','field_briefing_form_assets_type_value']);
    $query->orderBy('entity_id', 'ASC');
    $results = $query->execute()->fetchAll();
    foreach($results as $rck => $data){
      $arrData[] = array(
        'entity_id'                 => $data->entity_id,
        'briefing_form_assets_type' => $data->field_briefing_form_assets_type_value
      );
    }
    return $arrData;
  }

  /**
   * Function to fetch data from assets type tables.
   */
  Public function getBriefingFormListDetails($userID, $clientID, $BFStatus) { 

    $nodeType = 'briefingform';
    try{
      $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->leftjoin('node__field_briefing_form_animation_re', 'nfear', 'nfear.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_author', 'nfbfa', 'nfbfa.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_status', 'nfbfs', 'nfbfs.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_catalogue_title', 'nfct', 'nfct.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_ecommerce_re', 'nfecc', 'nfecc.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_final_catalogue_output', 'nffco', 'nffco.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_live_from_date', 'nfbflfd', 'nfbflfd.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_live_to_date', 'nfbfltd', 'nfbfltd.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_multiple_ver', 'nfemv', 'nfemv.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_preview_date', 'nfpd', 'nfpd.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_term_and_conditions', 'nftac', 'nftac.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_client_id', 'nfbfcid', 'nfbfcid.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_catalogue_section', 'nfbfcsec', 'nfbfcsec.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_special_instructions', 'nfbfspin', 'nfbfspin.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_completion_date', 'nfbfcd', 'nfbfcd.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_production_due_date', 'nfbfpdd', 'nfbfpdd.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_qa_date', 'nfbfqad', 'nfbfqad.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_catalogue_portal', 'nfbfcp', 'nfbfcp.entity_id = nfd.nid');
      $query->leftjoin('users', 'users', 'users.uid = nfd.uid');
      $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfd.uid');
      $query->fields('nfd', array('nid', 'type', 'title', 'uid','created', 'changed'));
      $query->fields('nfear', array('field_briefing_form_animation_re_value'));
      $query->fields('nfbfa', array('field_briefing_form_author_target_id'));
      $query->fields('nfbfs', array('field_briefing_form_status_value'));
      $query->fields('nfct', array('field_briefing_catalogue_title_value'));
      $query->fields('nfecc', array('field_briefing_form_ecommerce_re_value'));
      $query->fields('nffco', array('field_bf_final_catalogue_output_value'));
      $query->fields('nfbflfd', array('field_bf_live_from_date_value'));
      $query->fields('nfbfltd', array('field_bf_live_to_date_value'));
      $query->fields('nfemv', array('field_briefing_form_multiple_ver_value'));
      $query->fields('nfpd', array('field_briefing_form_preview_date_value'));
      $query->fields('nftac', array('field_bf_term_and_conditions_value'));
      $query->fields('nfbfcid', array('field_briefing_form_client_id_target_id'));
      $query->fields('nfbfcsec', array('field_bf_catalogue_section_value'));
      $query->fields('nfbfspin', array('field_bf_special_instructions_value'));
      $query->fields('nfbfcd', array('field_bf_completion_date_value'));
      $query->fields('nfbfpdd', array('field_bf_production_due_date_value'));
      $query->fields('nfbfqad', array('field_bf_qa_date_value'));
      $query->fields('nfbfcp', array('field_bf_catalogue_portal_value'));
      $query->fields('ufd', array('name','uid'));
      $query->condition('nfd.type', $nodeType);
      $query->condition('nfbfcid.field_briefing_form_client_id_target_id', $clientID);
      //$query->condition('nfbfa.field_briefing_form_author_target_id', $userID);
      if($BFStatus=='in_process') {
        $query->condition('nfbfs.field_briefing_form_status_value', $BFStatus);
      }
      $query->orderBy('nfd.nid', 'DESC');
      $query->range(0, 1);
      $results = $query->execute()->fetchAll();
      if($results) {
        foreach($results as $rck => $res){
          // Get Assets Files Using Briefing Form Id Param.
          $GetAssetsData  = $this->GetAssetDataByBriefingFormId($res->nid);
          // Client id.
          $clientId               = !empty($res->field_briefing_form_client_id_target_id) && !is_null($res->field_briefing_form_client_id_target_id)?$res->field_briefing_form_client_id_target_id:null;
          // Merge Live From Date and To Date.
          $liveFromDates  = !is_null($res->field_bf_live_from_date_value)?$res->field_bf_live_from_date_value:null;
          $liveFromDate   = date('Y-m-d\TH:i:s', strtotime($liveFromDates));
          $liveToDates    = !is_null($res->field_bf_live_to_date_value)?$res->field_bf_live_to_date_value:null;
          $liveToDate     = date('Y-m-d\TH:i:s', strtotime($liveToDates));
          $liveDate       = $liveFromDate.' - '.$liveToDate;
          // Convert preview date.
          $preview_dates      = !is_null($res->field_briefing_form_preview_date_value)?$res->field_briefing_form_preview_date_value:null;
          $preview_dates_utc  = new \DateTime($preview_dates, new \DateTimeZone('UTC'));
          $previewDate        = $preview_dates_utc->format('Y-m-d\TH:i:s');
          // Load Group.
          $groups = Group::load($clientId);
          $client_time        = $groups->field_client_time->value;
          $client_timeZone    = ($client_time != Null) ? $client_time : 'UTC';
          // Load User.
          $user_detail        = \Drupal\user\Entity\User::load($res->uid);
          $user_timezone      = $user_detail->timezone->value;
          // Node created date and time.
          $created            = date('Y-m-d\TH:i:s', $res->created);
          $createdDate        = convertDateFromTimezone($created, $user_timezone, $client_timeZone, 'Y-m-d\TH:i:s');
          //$createdDate      = date('Y-m-d\TH:i:s', $res->created);
          // Node updated date and time.
          $changed            = date('Y-m-d\TH:i:s', $res->changed);
          $changedDate        = convertDateFromTimezone($changed, $user_timezone, $client_timeZone, 'Y-m-d\TH:i:s');
          //$changedDate      = date('Y-m-d\TH:i:s', $res->changed);
          // Briefing Form Catalogue Completion date.
          $completionDate     = !is_null($res->field_bf_completion_date_value)?$res->field_bf_completion_date_value:null;
          // Briefing Form Catalogue Production Due Date.
          $productionDueDate  = !is_null($res->field_bf_production_due_date_value)?$res->field_bf_production_due_date_value:null;
          // Briefing Form Catalogue Production Due Date.
          $QADate             = !is_null($res->field_bf_qa_date_value)?$res->field_bf_qa_date_value:null;
          $arrData[] = array(
            'nid' 		                          => $res->nid,
            'type' 		                          => !is_null($res->type)?$res->type:null,
            'uid' 		                          => !is_null($res->uid)?$res->uid:null,
            'field_catalogue_title' 		        => !is_null($res->field_briefing_catalogue_title_value)?$res->field_briefing_catalogue_title_value:null,
            'field_enable_animation_required'   => !is_null($res->field_briefing_form_animation_re_value)?$res->field_briefing_form_animation_re_value:null,
            'field_briefing_form_author' 		    => !is_null($res->name)?$res->name:null,
            'field_briefing_form_status' 		    => !is_null($res->field_briefing_form_status_value)?$res->field_briefing_form_status_value:null,
            'field_enable_catalogue_ecommerce' 	=> !is_null($res->field_briefing_form_ecommerce_re_value)?$res->field_briefing_form_ecommerce_re_value:null,
            'field_final_catalogue_output' 		  => !is_null($res->field_bf_final_catalogue_output_value)?$res->field_bf_final_catalogue_output_value:null,
            'field_live_dates' 		              => $liveDate,
            'field_enable_multiple_versions' 		=> !is_null($res->field_briefing_form_multiple_ver_value)?$res->field_briefing_form_multiple_ver_value:null,
            'field_preview_date' 		            => $previewDate,
            'field_term_and_conditions' 		    => !is_null($res->field_bf_term_and_conditions_value)?$res->field_bf_term_and_conditions_value:null,
            'field_briefing_form_client_id'     => !is_null($res->field_briefing_form_client_id_target_id)?$res->field_briefing_form_client_id_target_id:null,
            'field_bf_catalogue_section'        => !is_null($res->field_bf_catalogue_section_value)?$res->field_bf_catalogue_section_value:null,
            'field_bf_special_instructions'     => !is_null($res->field_bf_special_instructions_value)?$res->field_bf_special_instructions_value:null,
            'field_briefing_form_created_date'  => $createdDate,
            'field_briefing_form_changed_date'  => $changedDate,
            'field_catalogue_completion_date'   => $completionDate,
            'field_catalogue_prod_due_date'     => $productionDueDate,
            'field_bf_catalogue_portal'         => !is_null($res->field_bf_catalogue_portal_value)?$res->field_bf_catalogue_portal_value:null,
            'field_bf_qa_date'                  => $QADate,
            'field_upload_assets_files' 		    => $GetAssetsData,
          );
        }
      } else {
        $arrData = ['status' => 'error', 'status_message' => 'Briefing form details not found.'];
      }
      return $arrData;
    } catch(\Exception $e){
      $results = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $results;
    }
  }

  /**
  * Function For Get All Asset Data By Using Param BriefingForm Id.
  **/
  function GetAssetDataByBriefingFormId($BriefingFormID) {

    // S3 Bucket settings.
    $config = \Drupal::config('s3fs.settings');
    $s3config = $config->get();
    $domain = UrlHelper::filterBadProtocol($s3config['domain']);
    // Select query to get briefing form assets details.
    $query = \Drupal::database()->select('node__field_asset_briefingform_id', 'nfabid');
    $query->leftjoin('node__field_bf_asset_comments', 'nfbfac', 'nfbfac.entity_id = nfabid.entity_id');
    $query->leftjoin('node__field_bf_asset_id', 'nfbfaid', 'nfbfaid.entity_id = nfabid.entity_id');
    $query->leftjoin('node__field_bf_asset_type_id', 'nfbfatid', 'nfbfatid.entity_id = nfabid.entity_id');
    $query->leftjoin('node__field_bf_form_type', 'nfbfft', 'nfbfft.entity_id = nfabid.entity_id');
    $query->leftjoin('node__field_briefing_form_assets_type', 'nfbfat', 'nfbfat.entity_id = nfbfatid.field_bf_asset_type_id_target_id');
    $query->leftjoin('node__field_bf_asset_catalogue_id', 'nfbfacid', 'nfbfacid.entity_id = nfabid.entity_id');
    $query->leftjoin('file_managed', 'fm', 'fm.fid = nfbfaid.field_bf_asset_id_value');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfabid.entity_id');
    $query->fields('nfabid', array('bundle', 'entity_id', 'field_asset_briefingform_id_target_id'));
    $query->fields('nfbfac', array('field_bf_asset_comments_value'));
    $query->fields('nfbfaid', array('field_bf_asset_id_value'));
    $query->fields('nfbfatid', array('field_bf_asset_type_id_target_id'));
    $query->fields('nfbfft', array('field_bf_form_type_value'));
    $query->addField('nfbfat', 'entity_id', 'bf_asset_type_id');
    $query->addField('nfbfacid', 'field_bf_asset_catalogue_id_target_id', 'field_catalogue_id');
    $query->fields('nfbfat', array('field_briefing_form_assets_type_value'));
    $query->fields('fm', array('fid', 'uri', 'filename', 'filemime'));
    $query->condition('nfabid.field_asset_briefingform_id_target_id', $BriefingFormID);
    $results = $query->execute()->fetchAll();
    if(!empty($results))
    {
      foreach($results as $res) {
        //$drupal_file_uri = File::load($res->uri)->getFileUri();
        // /sites/default/files/images/blah.jpg
        //$path = file_url_transform_relative(file_create_url($drupal_file_uri));
        $cat_imgs = '';
        if($res->field_catalogue_id!=null) {
          $query = db_select('node__field_catalogue_image', 'nfbfcimg');
          $query->addField('nfbfcimg', 'field_catalogue_image_target_id', 'fid');
          $query->condition('nfbfcimg.entity_id', $res->field_catalogue_id, '=');
          $query->orderBy('nfbfcimg.field_catalogue_image_target_id', 'ASC');
          $query->range(0, 1);
          $results = $query->execute()->fetchAssoc();
          if($results) {
            $fid = $results['fid'];
            if($fid) {
              $file 	  = File::load($fid);
              if($file) {
                $file_uri = $file->getFileUri();
                if($file_uri) {
                  $cat_imgs = file_create_url($file_uri);
                } else {
                  $cat_imgs = '';
                }
              } else {
                $cat_imgs = '';
              }
              /*$path_explode   = explode("s3:/",$file_uri);
              if($path_explode[1] != ""){
                  $cat_img[]  = str_replace('s3:/','https://' . $domain, $file_uri);
              } else {
                  $cat_img[]  = str_replace('private:/','https://' . $domain, $file_uri);
              }*/
            }
          }
        }
        $AssetData[] = array (
          "field_form_type" 		      => !is_null($res->field_bf_form_type_value)?$res->field_bf_form_type_value:null,
          "field_assets_nid"          => !is_null($res->entity_id)?$res->entity_id:null,
          "field_assets_fid" 		      => !is_null($res->fid)?$res->fid:null,
          "field_assets_uri" 		      => !is_null($res->uri)?$res->uri:null,
          "field_assets_filename"     => !is_null($res->filename)?$res->filename:null,
          "field_assets_filemime"     => !is_null($res->filemime)?$res->filemime:null,
          "field_asset_type_id"       => !is_null($res->field_bf_asset_type_id_target_id)?$res->field_bf_asset_type_id_target_id:null,
          "field_asset_type"          => !is_null($res->field_briefing_form_assets_type_value)?$res->field_briefing_form_assets_type_value:null,
          "field_asset_notes" 	      => !is_null($res->field_bf_asset_comments_value)?$res->field_bf_asset_comments_value:null,
          "field_catalogue_id"        => !is_null($res->field_catalogue_id)?$res->field_catalogue_id:null,
          "field_catalogue_first_img" => !empty($cat_imgs)?$cat_imgs:null,
        );
      }
      return $AssetData;
    } else {
      $AssetData = [];
      return $AssetData;
    }
  }

  /**
  * Function for delete all asset data by using param NId.
  **/
  public function DeleteAllAssetsByParam($nodeType,$field_upload_assets_files) {
    foreach($field_upload_assets_files as $res) {
        $nid = $res['field_assets_nid'];
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
        // Check if node exists with the given nid.
        if ($node) {
          $node->delete();
        }
    }
    return;
  }

  /**
  * Function for delete asset data by using param NId.
  **/
  public function DeleteAssetByParam($nid) {
    try{
      $node = Node::load($nid);
      if ($node) {
        $node->delete();
        $result = ['status' => 'success', 'status_message' => 'Assets details deleted successfully.'];
      } else {
        $result = ['status' => 'error', 'status_message' => 'Assets details not deleted successfully. Please try after some times.'];
      }
    } catch (Exception $e) {
      $result = ['status' => 'error', 'status_message' => 'Bad Request.'];
    }
    return $result;
  }

  public function getBriefingFormIdByUID($userID, $nodeType) {
    $query = \Drupal::database()->select('node_field_data', 'nfd');
    $query->leftjoin('node__field_briefing_form_author', 'nfbfa', 'nfbfa.entity_id = nfd.nid');
    $query->leftjoin('users', 'users', 'users.uid = nfd.uid');
    $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfd.uid');
    $query->addField('nfd', 'nid', 'briefingform_id');
    $query->addField('nfd', 'type', 'node_type');
    $query->addField('nfd', 'uid', 'briefingform_userid');
    $query->addField('users', 'uid', 'user_id');
    $query->condition('nfd.type', $nodeType);
    $query->condition('nfbfa.field_briefing_form_author_target_id', $userID);
    $query->orderBy('nfd.nid', 'DESC');
    //$query->range(0, 1);
    $results = $query->execute()->fetchAll();
    foreach($results as $res) {
      $arrData[] = $res->briefingform_id;
    }
    return $arrData;
  }

  /**
  * Function :: Get total records counts of all the catalogue list from a specific client by bf client id.
  */
  /*public function GetTotalBriefingFormCataloguesList($resultData, $requestparams) {

    $gtype          = 'catalogue';
    $status         = '1';
    $totalRecords = 0;
    try{
      foreach($resultData as  $key => $value){
        if($key!='' && $value!=null){
          // Get Catalogue Data Using Client Id and Status.
          $query = \Drupal::database()->select('node_field_data', 'nfd');
          $query->leftjoin('group_content_field_data', 'gcfd', 'gcfd.entity_id = nfd.nid');
          $query->fields('nfd', array('nid', 'type', 'title', 'uid'));
          $query->fields('gcfd', array('id', 'gid', 'type', 'label', 'entity_id'));
          $query->condition('nfd.type', $gtype, '=');
          $query->condition('gcfd.gid', $key, '=');
          $results = $query->execute()->fetchAll();
          $totalRecords+= count($results);
        }
      }
      return $totalRecords;
    } catch(\Exception $e){
      return $results = 0;
    }
  }*/

  public function GetBriefingFormCataloguesList_clientInarray($result_data) {

    $arrData = array(); $i=0;
    foreach($result_data['clients'] as  $key => $value){
      if($key!='' && $value!=null){
        $arrData[$i] = $key;
        $i++;
      }
    }
    return $arrData;
  }


  public function GetBriefingFormCataloguesList_withoutorganisationsInarray($userid) {
    $clientArray = array();
    $gcfdT = array('client-group_membership', 'organisation-group_membership');
    if($userid) {
      $query = \Drupal::database()->select('users_field_data', 'ufd');
      $query->innerjoin('group_content_field_data', 'gcfd', 'gcfd.entity_id = ufd.uid');
      $query->addField('ufd', 'uid', 'ufd_uid');
      $query->addField('ufd', 'name', 'ufd_name');
      $query->addField('ufd', 'mail', 'ufd_email');
      $query->addField('gcfd', 'id', 'gcfd_id');
      $query->addField('gcfd', 'type', 'gcfd_type');
      $query->addField('gcfd', 'gid', 'gcfd_gid');
      $query->addField('gcfd', 'entity_id', 'gcfd_entity_id');
      $query->addField('gcfd', 'label', 'gcfd_label');
      $query->addField('gcfd', 'uid', 'gcfd_entity_uid');
      $query->condition('gcfd.type', $gcfdT, 'IN');
      $query->condition('ufd.uid', $userid, '=');
      $results = $query->execute()->fetchAll();
      if($results) {
        $i=0;
        foreach($results as $res) {
          $clientArray[$i] = $res->gcfd_id;
          $i++;
        }
      }
    }
    return $clientArray;
  }

  /**
   * Get briefing form data for automation process.
   */
  public function GetBriefingFormAutomationData($briefingFormId, $assetsNodeId) { // uri
  
    // S3 Bucket settings.
    $config = \Drupal::config('s3fs.settings');
    $s3config = $config->get();
    $domain = UrlHelper::filterBadProtocol($s3config['domain']);
    if(!empty($briefingFormId)) {
      $node = \Drupal\node\Entity\Node::load($briefingFormId);
      if($node) {
        // Preview date.
        if(isset($node->field_briefing_form_preview_date->value) && !empty($node->field_briefing_form_preview_date->value)) {
          $previewDate = date('Y-m-d', strtotime($node->field_briefing_form_preview_date->value)).'T00:00:24+00:00';
        } else {
          $previewDate = NULL;
        }
        // Live from date.
        if(isset($node->field_bf_live_from_date->value) && !empty($node->field_bf_live_from_date->value)) {
          $liveFromDate = date('Y-m-d', strtotime($node->field_bf_live_from_date->value)).'T00:00:24+00:00';
        } else {
          $liveFromDate = NULL;
        }
        // Live to date.
        if(isset($node->field_bf_live_to_date->value) && !empty($node->field_bf_live_to_date->value)) {
          $liveToDate = date('Y-m-d', strtotime($node->field_bf_live_to_date->value)).'T00:00:24+00:00';
        } else {
          $liveToDate = NULL;
        }
        $node_storage = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($assetsNodeId); 
        $assets_count = count($node_storage);
        if($node_storage) {
          foreach($node_storage as $resnode) {
            $asset_bf_form_type = $resnode->field_bf_form_type->value;
            if(!empty($asset_bf_form_type) && $asset_bf_form_type == 'catalogue') {
              $assets_node_id = $resnode->nid->value;
              $assetsFID      = $resnode->field_bf_asset_id->value;
              // Load files by using fid.
              $file           = File::load($assetsFID);
              $file_mimetype  = $file->getMimeType();
              if($file_mimetype == 'application/pdf') {
                $file_uri1 	    = $file->getFileUri();
                $path_explode1   = explode("s3:/",$file_uri1);
                if($path_explode1[1] != ""){
                  $file_path1      = str_replace('s3:/','https://' . $domain, $file_uri1);
                } else {
                  $file_path1      = str_replace('private:/','https://' . $domain, $file_uri1);
                }
                //$file_url         = $file->url();
                //$url              = Url::fromUri($file_url);
                $file_name        = $file->getFilename();
                $file_user_entity = $file->getOwner();
                $file_user_id     = $file->getOwnerId();
                $size             = $file->getSize();
                $arrData[] = array(
                  'title'                       => (isset($resnode->title->value) && !empty($resnode->title->value) && $resnode->title->value!='null')?$resnode->title->value:NULL,
                  'status'                      => 'created',
                  'clipper'                     => 'client',
                  'portal'                      => (isset($node->field_bf_catalogue_portal->value) && !empty($node->field_bf_catalogue_portal->value) && $node->field_bf_catalogue_portal->value!='null')?$node->field_bf_catalogue_portal->value:'client',
                  'readyByDate'                 => $previewDate,
                  'startDate'                   => $liveFromDate,
                  'endDate'                     => $liveToDate,
                  'clientId'                    => (isset($node->field_briefing_form_client_id->target_id) && !empty($node->field_briefing_form_client_id->target_id) && $node->field_briefing_form_client_id->target_id!='null')?$node->field_briefing_form_client_id->target_id:NULL,
                  'assets_node_id'              => $assets_node_id,
                  'assets_file_url'             => $file_path1,
                  'assets_file_name'            => $file_name,
                  'field_briefing_form_author'  => (isset($node->field_briefing_form_author->target_id) && !empty($node->field_briefing_form_author->target_id) && $node->field_briefing_form_author->target_id!='null')?$node->field_briefing_form_author->target_id:NULL,
                  'field_bf_catalogue_section'  => (isset($node->field_bf_catalogue_section->value) && !empty($node->field_bf_catalogue_section->value) && $node->field_bf_catalogue_section->value!='null')?$node->field_bf_catalogue_section->value:NULL
                );
              }
            }
          }
          return $arrData;
        }
      }
    }
  }

  /**
   * Get briefing form assets by using param briefing form id and assets id's.
   */
  public function GetBriefingAssetsByNid($briefingFormId, $assetsNodeId) {
    $node_storage = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($nids);
    if($node_storage) {
      foreach($node_storage as $resnode) {
        $assets_node_id = $resnode->nid->value;
        $assetsFID      = $resnode->field_bf_asset_id->value;
        // Load files by using fid.
        $file           = File::load($file_fid);
        $file_mimetype  = $file->getMimeType();
        if($file_mimetype == 'application/pdf') {
          $file_url         = $file->url();
          $url              = Url::fromUri($file_url);
          $file_name        = $file->getFilename();
          $file_user_entity = $file->getOwner();
          $file_user_id     = $file->getOwnerId();
          $size             = $file->getSize();
          $arrData[] = array(
            'assets_node_id'    => $assets_node_id,
            'assets_file_url'   => $url,
            'assets_file_name'  => $file_name
          );
        }
      }
      return $arrData;
    } else {
      $arrData = array();
      return $arrData;
    }
  }

  public function GetBFIDByParams($userID) {
    $BFIds = array();
    $query = \Drupal::database()->select('node__field_bf_catau_page_userid', 'A');
    $query->leftjoin('node__field_bf_catau_page_number', 'B', 'B.entity_id = A.entity_id');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'C', 'C.entity_id = A.entity_id');
    $query->leftjoin('node__field_bf_catasur_briefingform_id', 'D', 'D.entity_id = C.field_bfcatalogue_assigning_user_target_id');
    $query->addField('A', 'field_bf_catau_page_userid_target_id', 'field_bf_catau_page_userid');
    $query->addField('B', 'field_bf_catau_page_number_value', 'field_bf_catau_page_number');
    $query->addField('C', 'field_bfcatalogue_assigning_user_target_id', 'field_bfcatalogue_assigning_user_nid');
    $query->addField('D', 'field_bf_catasur_briefingform_id_target_id', 'field_bf_catasur_briefingform_id');
    $query->condition('A.field_bf_catau_page_userid_target_id ', $userID, '=');
    $results = $query->execute()->fetchAll();
    if($results) {
      foreach($results as $res) {
        $bfid = $res->field_bf_catasur_briefingform_id;
        if (!in_array($bfid, $BFIds)) {
          $BFIds[] = $res->field_bf_catasur_briefingform_id;
        }
      }
    }
    return $BFIds;
  }

  public function CheckAndGetBFIdForSearchCatalogueStatus($BF_type, $workflow_status, $clientsArray) {
    $BF_array     = array();
    $Result_array = array();
    // First have to get all mapped briefing form id from given clients.
    $query = \Drupal::database()->select('node__field_briefing_form_client_id', 'nfbfci');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfci.entity_id');
    $query->addField('nfbfci', 'entity_id' , 'field_briefing_form_id');
    $query->addField('nfbfci', 'field_briefing_form_client_id_target_id' , 'field_briefing_form_client_id');
    $query->addField('nfd', 'type', 'nfd_type');
    $query->addField('nfd', 'title', 'nfd_title');
    $query->addField('nfd', 'uid', 'nfd_uid');
    $query->addField('nfd', 'created', 'nfd_created');
    $query->addField('nfd', 'changed', 'nfd_updated');
    $query->condition('nfd.type', $BF_type, '=');
    $query->condition('nfbfci.field_briefing_form_client_id_target_id', $clientsArray, 'IN');
    $results1 = $query->execute()->fetchAll();
    if($results1) { $i=0;
      foreach($results1 as $res1) {
        $BF_array[$i] = $res1->field_briefing_form_id;
        $i++;
      }
    }
    if($BF_array) {
      // Check and get matched status in result BF_array briefing form id.
      $query1 = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfrefid');
      $query1->leftjoin('node__field_catalogue_workflow', 'nfcw', 'nfcw.entity_id = nfbfrefid.entity_id');
      $query1->addField('nfbfrefid', 'entity_id' , 'field_catalogue_id');
      $query1->addField('nfbfrefid', 'field_briefing_form_reference_id_target_id' , 'field_briefing_form_id');
      $query1->addField('nfcw', 'field_catalogue_workflow_value' , 'field_catalogue_workflow_status');
      $query1->condition('nfbfrefid.field_briefing_form_reference_id_target_id', $BF_array, 'IN');
      $query1->condition('nfcw.field_catalogue_workflow_value', $workflow_status, '=');
      $results2 = $query1->execute()->fetchAll();
      if($results2) {$j=0;
        foreach($results2 as $res2) {
          $catalogueId = $res2->field_catalogue_id;
          $briefingFormId = $res2->field_briefing_form_id;
          $workflowStatus = $res2->field_catalogue_workflow_status;
          $Result_array[$j] = $res2->field_briefing_form_id;
          $j++;
        }
      }
    }
    return $Result_array;
  }

  /**
  * Function :: #5 and #6 api new get all briefing form list by using user id (logged in user) and filter parameters.
  */
  public function GetBriefingFormFullListbyUserID($result_data, $requestparams) {

    # Get the DB Connection
		$db 	= \Drupal::database();
    $userID         = (isset($requestparams['userid']) && !empty($requestparams['userid']) && $requestparams['userid']!=null) ? $requestparams['userid']:null;
    // Get client id in array format.
    $clientsArray = $this->GetBriefingFormCataloguesList_clientInarray($result_data);
    if(empty($clientsArray)) {
      $clientsArray = $this->GetBriefingFormCataloguesList_withoutorganisationsInarray($userID);
    }
    $testClientArray = implode(",",$clientsArray);
    \Drupal::logger('API-5-request-array')->notice('@result_data ||  %clientsArray],', [
      '@result_data' => json_encode($result_data),
      '@clientsArray' => $testClientArray
    ]);
    $request_param  = implode(', ', $requestparams);
    $clientsArrays  = implode(', ', $clientsArray);
    $pageNo         = (isset($requestparams['pageno']) && !empty($requestparams['pageno']) && $requestparams['pageno']!=null) ? $requestparams['pageno']:null;
    $pageLimit      = (isset($requestparams['pagelimit']) && !empty($requestparams['pagelimit']) && $requestparams['pagelimit']!=null) ? $requestparams['pagelimit']:null;
    $BFStatus       = (isset($requestparams['status']) && !empty($requestparams['status']) && $requestparams['status']!=null) ? $requestparams['status']:null;
    $clientName     = (isset($requestparams['client']) && !empty($requestparams['client']) && $requestparams['client']!=null) ? $requestparams['client']:null;
    $sortBy         = (isset($requestparams['sortby']) && !empty($requestparams['sortby']) && $requestparams['sortby']!=null) ? $requestparams['sortby']:null;
    $dueDate        = (isset($requestparams['duedate']) && !empty($requestparams['duedate']) && $requestparams['duedate']!=null) ? $requestparams['duedate']:null;
    $keywordsearch  = (isset($requestparams['keywordsearch']) && !empty($requestparams['keywordsearch']) && $requestparams['keywordsearch']!=null) ? urldecode($requestparams['keywordsearch']):null;
    $briefingformid = (isset($requestparams['briefingformid']) && !empty($requestparams['briefingformid']) && $requestparams['briefingformid']!=null) ? $requestparams['briefingformid']:null;
    $lastsevendate  = (isset($requestparams['lastsevendate']) && !empty($requestparams['lastsevendate']) && $requestparams['lastsevendate']!=null) ? $requestparams['lastsevendate']:null;
    $usertype       = (isset($requestparams['usertype']) && !empty($requestparams['usertype']) && $requestparams['usertype']!=null) ? $requestparams['usertype']:null;
    $BF_type        = 'briefingform';
    $status         = '1';
    if($sortBy==null || $sortBy == '' || $sortBy == 'Latest') {
      $recordSortBy = 'DESC';
    } else if($sortBy =='Oldest') {
      $recordSortBy = 'ASC';
    } else {
      $recordSortBy = 'DESC';
    }
    /*$user = User::load($userID);
    $user_org = rp_extras_get_groups_for_user($user);
    print_r($user_org);
    print_r($clientsArray);
    exit;*/
    // Check catalogue status
    $CheckAndGetBFId = $this->CheckAndGetBFIdForSearchCatalogueStatus($BF_type, $BFStatus, $clientsArray);
    $bfid_array      = (isset($CheckAndGetBFId))? $CheckAndGetBFId:null;
    try{
      // Get briefing form data using parameters.
      $query = \Drupal::database()->select('node__field_briefing_form_client_id', 'nfbfci');
      $query->leftjoin('node__field_briefing_form_title', 'nfbft', 'nfbft.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_briefing_form_status', 'nfbfs', 'nfbfs.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_briefing_catalogue_title', 'nfbfct', 'nfbfct.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_briefing_form_animation_re', 'nfbfare', 'nfbfare.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_briefing_form_ecommerce_re', 'nfbfere', 'nfbfere.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_briefing_form_multiple_ver', 'nfbfmver', 'nfbfmver.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_briefing_form_preview_date', 'nfbfpd', 'nfbfpd.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_term_and_conditions', 'nfbftac', 'nfbftac.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_final_catalogue_output', 'nfbffco', 'nfbffco.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_live_from_date', 'nfbflfd', 'nfbflfd.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_live_to_date', 'nfbfltd', 'nfbfltd.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_catalogue_section', 'nfbfcs', 'nfbfcs.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_special_instructions', 'nfbfsi', 'nfbfsi.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_completion_date', 'nfbfcd', 'nfbfcd.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_production_due_date', 'nfbfpdd', 'nfbfpdd.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_qa_date', 'nfbfqad', 'nfbfqad.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_briefing_form_author', 'nfbfau', 'nfbfau.entity_id = nfbfci.entity_id');
      $query->leftjoin('node__field_bf_catalogue_portal', 'nfbfcp', 'nfbfcp.entity_id = nfbfci.entity_id');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfci.entity_id');
      $query->leftjoin('groups_field_data', 'gfd', 'gfd.id = nfbfci.field_briefing_form_client_id_target_id');
      $query->leftjoin('group_content_field_data', 'gcfd', 'gcfd.id = gfd.id');
      $query->leftjoin('users', 'users', 'users.uid = nfd.uid');
      $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfd.uid');

      $query->addField('nfbfci', 'entity_id' , 'field_briefing_form_id');
      $query->addField('nfbfci', 'field_briefing_form_client_id_target_id' , 'field_briefing_form_client_id');
      $query->addField('nfbft', 'field_briefing_form_title_value' , 'field_briefing_form_title');
      $query->addField('nfbfs', 'field_briefing_form_status_value' , 'field_briefing_form_status');
      $query->addField('nfbfct', 'field_briefing_catalogue_title_value' , 'field_briefing_catalogue_title');
      $query->addField('nfbfare', 'field_briefing_form_animation_re_value' , 'field_briefing_form_animation_required');
      $query->addField('nfbfere', 'field_briefing_form_ecommerce_re_value' , 'field_briefing_form_ecommerce_required');
      $query->addField('nfbfmver', 'field_briefing_form_multiple_ver_value' , 'field_briefing_form_multiple_version');
      $query->addField('nfbfpd', 'field_briefing_form_preview_date_value' , 'field_briefing_form_preview_date');
      $query->addField('nfbftac', 'field_bf_term_and_conditions_value' , 'field_bf_term_and_conditions');
      $query->addField('nfbffco', 'field_bf_final_catalogue_output_value' , 'field_bf_final_catalogue_output');
      $query->addField('nfbflfd', 'field_bf_live_from_date_value' , 'field_bf_live_from_date');
      $query->addField('nfbfltd', 'field_bf_live_to_date_value' , 'field_bf_live_to_date');
      $query->addField('nfbfcs', 'field_bf_catalogue_section_value' , 'field_bf_catalogue_section');
      $query->addField('nfbfsi', 'field_bf_special_instructions_value' , 'field_bf_special_instructions');
      $query->addField('nfbfcd', 'field_bf_completion_date_value' , 'field_bf_completion_date');
      $query->addField('nfbfpdd', 'field_bf_production_due_date_value' , 'field_bf_production_due_date');
      $query->addField('nfbfqad', 'field_bf_qa_date_value' , 'field_bf_qa_date');
      $query->addField('nfbfau', 'field_briefing_form_author_target_id' , 'field_briefing_form_author');
      $query->addField('nfbfcp', 'field_bf_catalogue_portal_value' , 'field_bf_catalogue_portal');
      $query->addField('nfd', 'type', 'nfd_type');
      $query->addField('nfd', 'title', 'nfd_title');
      $query->addField('nfd', 'uid', 'nfd_uid');
      $query->addField('nfd', 'created', 'nfd_created');
      $query->addField('nfd', 'changed', 'nfd_updated');
      $query->addField('ufd', 'uid', 'user_id');
      $query->addField('ufd', 'name', 'user_name');
      $query->addField('ufd', 'mail', 'user_email');
      $query->addField('gfd', 'id', 'gfd_client_id');
      $query->addField('gfd', 'label', 'gfd_client_name');
      $query->condition('nfd.type', $BF_type, '=');
      $query->condition('nfbfci.field_briefing_form_client_id_target_id', $clientsArray, 'IN');
      if(!empty($usertype) && $usertype != null && ($usertype=='operator') && $userID) { // || $usertype=='operator'
        $GetBFIDs = $this->GetBFIDByParams($userID);
        if(!empty($GetBFIDs)) {
          $query->condition('nfbfci.entity_id', $GetBFIDs, 'IN');
        }
      }
      // Check briefing form status.
      if($BFStatus!=null && $BFStatus!='all') {
        //$query->condition('nfbfs.field_briefing_form_status_value', $db->escapeLike($BFStatus), '=');
        $query->condition('nfbfci.entity_id', $bfid_array, 'IN');
      }
      // Check briefing form client name.
      if($clientName!=null) {
        $query->condition('gfd.label', $db->escapeLike($clientName), '=');
      }
      // Check the briefing form catalogue production due date.
      if($dueDate!=null) {
        $catalogueDueDate = date('Y-m-d', strtotime($dueDate));
        $startDate = $catalogueDueDate.'T00:00:00';
        $endDate = $catalogueDueDate.'T23:59:59';
        $query->condition('nfbfpdd.field_bf_production_due_date_value', array($startDate, $endDate), 'BETWEEN');
      }
      // Keyword search condition in briefing form title, client name.
      if($keywordsearch!=null) {
        // Create the orConditionGroup.
        $orGroup = $query->orConditionGroup()
        ->condition('gfd.label', "%" . $db->escapeLike($keywordsearch) . "%" , 'LIKE')
        ->condition('nfbft.field_briefing_form_title_value', "%" . $db->escapeLike($keywordsearch) . "%" , 'LIKE');
        // Add the group to the query.
        $query->condition($orGroup);
      }
      // Briefing form id.
      if($briefingformid!=null) {
        $query->condition('nfbfci.entity_id', $db->escapeLike($briefingformid), '=');
      }
      // Last seven days.
      if($lastsevendate!=null) {
        $lastsevenLDate = strtotime(date('Y-m-d', strtotime($lastsevendate)).' 23:59:59');
        $lastsevenSDate = strtotime(date('Y-m-d', strtotime('-7 days')).' 00:00:00');
        $orGroup = $query->orConditionGroup()
        ->condition('nfd.created', array($lastsevenSDate, $lastsevenLDate), 'BETWEEN')
        ->condition('nfd.changed', array($lastsevenSDate, $lastsevenLDate), 'BETWEEN');
        // Add the group to the query.
        $query->condition($orGroup);
      }
      $query->orderBy('nfbfci.entity_id', $recordSortBy);
      $countQuery = $query;
      // Get query total records count.
      $countresults     = $countQuery->execute()->fetchAll();
      $GetTotalRecords  = count($countresults);
      // Page limit.
      $pagelimits       = (isset($pageLimit) || $pageLimit!='0') ? $pageLimit : 100;
      // Page number.
      $pagenos          = (isset($pageNo) || $pageNo!='0') ? $pageNo : 1;
      // Get page offset.
      $offset           = ($pagenos-1) * $pagelimits;
      // Get total pages.catalogue_approved
      $total_pages      = ceil($GetTotalRecords / $pagelimits);
      $query->range($offset, $pagelimits);
      // Get query result set.
      $results = $query->execute()->fetchAll();
      if($results) {
        foreach($results as $res) {
          // Briefing form - catalogue live from date.
          $live_from_date   = !empty($res->field_bf_live_from_date)?date('Y/m/d H:i:s', strtotime($res->field_bf_live_from_date)):null;
          // Briefing form - catalogue live to date.
          $live_to_date     = !empty($res->field_bf_live_to_date)?date('Y/m/d H:i:s', strtotime($res->field_bf_live_to_date)):null;
          // Briefing form - catalogue live date.
          $bf_live_date     = $live_from_date.'-'.$live_to_date;
          // Briefing form - preview date.
          $preview_date     = !empty($res->field_briefing_form_preview_date)?$res->field_briefing_form_preview_date:null;
          // Briefing form - production due date.
          $production_date  = !empty($res->field_bf_production_due_date)?$res->field_bf_production_due_date:null;
          // Briefing form - completion date.
          $completion_date  = !empty($res->field_bf_completion_date)?$res->field_bf_completion_date:null;
          // Briefing form - QA date.
          $bf_qa_date       = !empty($res->field_bf_qa_date)?$res->field_bf_qa_date:null;
          // Get total catalogue page count and noof variants by using briefing form id.
          $Getcatalogue     = $this->GetCataloguepagecountandvariantsbyparam($res->field_briefing_form_id, $userID, $usertype);
          // Node created date & time.
          //$created_date   = format_date($res->nfd_created, 'custom', 'Y-m-d');
          // Node changed date & time.
          //$updated_date   = format_date($res->nfd_updated, 'custom', 'Y-m-d');
          // Get user role by user id.
          $GetUserRole      = $this->GetUserRoleByUID($res->user_id);
          // Get Assets Files Using Briefing Form Id Param.
          $GetAssetsData    = $this->GetAssetDataByBriefingFormId($res->field_briefing_form_id);
          // Get Catalogue First image by param.
          //$GetCatalogueFirstImage = $this->GetCatalogueFirstImageByParams($res->field_briefing_form_id,$GetAssetsData);// Node created date & time.
          // Load Group.
          $groups = Group::load($res->field_briefing_form_client_id);
          $client_time            = $groups->field_client_time->value;
          $client_timeZone        = ($client_time != Null) ? $client_time : 'UTC';
          // Load User.
          $user_detail            = \Drupal\user\Entity\User::load($res->user_id);
          $user_timezone          = $user_detail->timezone->value;
          // Node created date & time.
          $created                = date('Y-m-d\TH:i:s', $res->nfd_created);
          $createdDateTime        = convertDateFromTimezone($created, $user_timezone, $client_timeZone, 'Y-m-d\TH:i:s');
          // Node created date & time.
          $changed                = date('Y-m-d\TH:i:s', $res->nfd_created);
          $updatedDateTime        = convertDateFromTimezone($changed, $user_timezone, $client_timeZone, 'Y-m-d\TH:i:s');
          //$createdDateTime   = date('Y-m-d\TH:i:s', $res->nfd_created);
          // Node updated date & time.
          //$updatedDateTime   = date('Y-m-d\TH:i:s', $res->nfd_updated);
          $arrData[] = array(
            'field_briefing_form_id'                  => $res->field_briefing_form_id,
            'field_briefing_form_client_id'           => $res->field_briefing_form_client_id,
            'field_briefing_form_title'               => $res->field_briefing_form_title,
            'field_briefing_form_status'              => $res->field_briefing_form_status,
            'field_briefing_catalogue_title'          => $res->field_briefing_catalogue_title,
            'field_briefing_form_animation_required'  => $res->field_briefing_form_animation_required,
            'field_briefing_form_ecommerce_required'  => $res->field_briefing_form_ecommerce_required,
            'field_briefing_form_multiple_version'    => $res->field_briefing_form_multiple_version,
            'field_briefing_form_preview_date'        => $preview_date,
            'field_bf_term_and_conditions'            => $res->field_bf_term_and_conditions,
            'field_bf_final_catalogue_output'         => $res->field_bf_final_catalogue_output,
            'field_briefing_form_live_date'           => $bf_live_date,
            'field_bf_catalogue_section'              => $res->field_bf_catalogue_section,
            'field_bf_special_instructions'           => $res->field_bf_special_instructions,
            'field_bf_completion_date'                => $completion_date,
            'field_bf_production_due_date'            => $production_date,
            'field_bf_qa_date'                        => $bf_qa_date,
            'field_briefing_form_author'              => $res->field_briefing_form_author,
            'field_bf_catalogue_portal'               => $res->field_bf_catalogue_portal,
            'field_client_name'                       => $res->gfd_client_name,
            'field_bf_user_id'                        => $res->user_id,
            'field_bf_user_type'                      => $GetUserRole,
            'field_bf_created_date'                   => $createdDateTime,
            'field_bf_updated_date'                   => $updatedDateTime,
            //'field_bf_catalogue_image'              => $GetCatalogueFirstImage,
            'field_upload_assets_files' 		          => $GetAssetsData,
            'field_cataloue_total_pages'              => $Getcatalogue['page_qty_total'],
            'field_cataloue_total_variants'           => $Getcatalogue['variant_count'],
            'field_cataloue_pages_assignees'          => $Getcatalogue['catalogue']['cat_page_assignee']
          );
        }
        $return = array(
          'status'        => 'success',
          'total_records' => $GetTotalRecords,
          'total_pages'   => $total_pages,
          'num_results'   => $pagelimits,
          'current_pageno'=> $pagenos,
          'result_rows'   => $arrData,
        );
        return $return;
      } else {
        $results = ['status' => 'error', 'status_message' => 'No Record Found.'];   
        return $results;
      }
    } catch(\Exception $e){
      $results = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $results;
    }
  }

  /**
   * Get Catalogue First Image by params.
   */
  public function GetCatalogueFirstImageByParams($field_briefing_form_id,$GetAssetsData) {
    $cat_img = array();
    // S3 Bucket settings.
    $config = \Drupal::config('s3fs.settings');
    $s3config = $config->get();
    $domain = UrlHelper::filterBadProtocol($s3config['domain']);
    if(!empty($GetAssetsData)) {
      foreach($GetAssetsData as $res) {
        $catid = $res['field_catalogue_id'];
        if($catid!=null) {
          $query = db_select('node__field_catalogue_image', 'nfbfcimg');
          $query->addField('nfbfcimg', 'field_catalogue_image_target_id', 'fid');
          $query->condition('nfbfcimg.entity_id', $catid, '=');
          $query->orderBy('nfbfcimg.field_catalogue_image_target_id', 'ASC');
          $query->range(0, 1);
          $results = $query->execute()->fetchAssoc();
          if($results) {
            $fid = $results['fid'];
            if($fid) {
              $file 	    = File::load($fid);
              $file_uri 	= $file->getFileUri();
              $cat_imgs[] = file_create_url($file_uri);
              /*$path_explode   = explode("s3:/",$file_uri);
              if($path_explode[1] != ""){
                  $cat_img[]  = str_replace('s3:/','https://' . $domain, $file_uri);
              } else {
                  $cat_img[]  = str_replace('private:/','https://' . $domain, $file_uri);
              }*/
            }
          }
        }
      }
    }
    return $cat_img;
  }

  /**
  * Get user role by UID.
  */
  public function GetUserRoleByUID($uid) {

    $query = db_select('users_field_data', 'ufd');
    $query->leftjoin('user__roles', 'ur', 'ur.entity_id = ufd.uid');
    $query->addField('ufd', 'uid', 'user_id');
    $query->addField('ur', 'roles_target_id', 'user_role');
    $query->condition('ufd.uid', $uid, '=');
    $query->orderBy('ur.roles_target_id', 'ASC');
    $result = $query->execute()->fetchAll();
    if(!empty($result)){ 
      foreach($result as $res) {
        $arrData[] = $res->user_role;
      }
    } else {
      $arrData = array();
    }
    return $arrData;
  }

  /**
  * Function :: Get catalogue total page count and count number of vatiants.
  */
  public function GetCataloguepagecountandvariantsbyparam($BFID, $userID, $usertype) {
    $variant_count  = 0;
    $page_qty_total = 0;
    // Get Catalogue id from briefing form id in briefing form assets.
    $query = db_select('node__field_asset_briefingform_id', 'nfbafid');
    $query->leftjoin('node__field_bf_asset_catalogue_id', 'nfbfacid', 'nfbfacid.entity_id = nfbafid.entity_id');
    $query->leftjoin('node__field_bf_asset_status', 'nfbfas', 'nfbfas.entity_id = nfbafid.entity_id');
    $query->leftjoin('node__field_bf_asset_total_pages', 'nfbfatp', 'nfbfatp.entity_id = nfbafid.entity_id');
    $query->leftjoin('node__field_bf_form_type', 'nfbfft', 'nfbfft.entity_id = nfbafid.entity_id');
    $query->addField('nfbafid', 'entity_id', 'field_assets_id');
    $query->addField('nfbafid', 'field_asset_briefingform_id_target_id', 'field_assets_bf_id');
    $query->addField('nfbfacid', 'field_bf_asset_catalogue_id_target_id', 'field_assets_catalogue_id');
    $query->addField('nfbfas', 'field_bf_asset_status_value', 'field_assets_status');
    $query->addField('nfbfatp', 'field_bf_asset_total_pages_value', 'field_assets_total_pages');
    $query->condition('nfbafid.field_asset_briefingform_id_target_id', $BFID, '=');
    $query->condition('nfbfas.field_bf_asset_status_value', 'verified', '=');
    $query->condition('nfbfft.field_bf_form_type_value', 'catalogue', '=');
    $result = $query->execute()->fetchAll();
    if($result) {
      foreach($result as $res) {
        $catId    = $res->field_assets_catalogue_id;
        // Get Total page count.
        $catalogueNode = Node::load($catId);
        $pageCount = $catalogueNode->field_catalogue_pagecount->value;
        $GetPages = $this->GetCatalogueAllPagesAssignedUserDetails($catId, $userID, $usertype);
        $arrData['catalogue']['cat_page_assignee'][$catId] = $GetPages;
        $page_qty_total+=$pageCount;
        $variant_count++;
      }
      $arrData['variant_count']   = $variant_count;
      $arrData['page_qty_total']  = $page_qty_total;
    } else {
      $arrData['variant_count']   = null;
      $arrData['page_qty_total']  = null;
      $arrData['catalogue']['cat_page_assignee'][] = null;
    }
    return $arrData;
    /*$arrData['variant_count']   = $variant_count;
    $arrData['page_qty_total']  = $page_qty_total; 
    $query = db_select('node__field_briefing_form_reference_id', 'nfbfrid');
    $query->leftjoin('node__field_catalogue_pagecount', 'nfcpc', 'nfcpc.entity_id = nfbfrid.entity_id');
    $query->addField('nfbfrid', 'entity_id', 'field_catalogue_id');
    $query->addField('nfcpc', 'field_catalogue_pagecount_value', 'field_catalogue_pagecount_value');
    $query->condition('nfbfrid.field_briefing_form_reference_id_target_id', $BFID, '=');
    $result = $query->execute()->fetchAll();
    if(!empty($result)){ 
      $variant_count = count($result);
      $page_qty_total = 0;
      foreach($result as $res) {
        $page_qty_total+=$res->field_catalogue_pagecount_value;
        $catId = $res->field_catalogue_id;
        $GetPages = $this->GetCatalogueAllPagesAssignedUserDetails($catId, $userID, $usertype);
        $arrData['catalogue']['cat_page_assignee'][$catId] = $GetPages;
      }
      $arrData['variant_count']   = $variant_count;
      $arrData['page_qty_total']  = $page_qty_total;
    }
    return $arrData;
    */
  }

  /**
   * Function :: #14api old - getting all the catalogues list from a specific client
   *  by using Briefing Form client id.
   */
  public function GetBriefingFormCataloguesListDetails($result_data, $requestparams) {

    # Get the DB Connection
		$db 	= \Drupal::database();
    // Get client id in array format.
    $clientsArray = $this->GetBriefingFormCataloguesList_clientInarray($result_data);
    $request_param = implode(', ', $requestparams);
    $clientsArrays = implode(', ', $clientsArray);
    /*\Drupal::logger('redpepper')->notice('@request_param ||  %clientsArray],', [
      '@request_param' => $request_param,
      '%clientsArray' => $clientsArrays,
    ]);*/
    $userID         = (isset($requestparams['userid']) && !empty($requestparams['userid']) && $requestparams['userid']!=null) ? $requestparams['userid']:null;
    $usertype       = (isset($requestparams['usertype']) && !empty($requestparams['usertype']) && $requestparams['usertype']!=null) ? $requestparams['usertype']:null;
    $pageNo         = (isset($requestparams['pageno']) && !empty($requestparams['pageno']) && $requestparams['pageno']!=null) ? $requestparams['pageno']:null;
    $pageLimit      = (isset($requestparams['pagelimit']) && !empty($requestparams['pagelimit']) && $requestparams['pagelimit']!=null) ? $requestparams['pagelimit']:null;
    $catStatus      = (isset($requestparams['status']) && !empty($requestparams['status']) && $requestparams['status']!=null) ? $requestparams['status']:null;
    $clientName     = (isset($requestparams['client']) && !empty($requestparams['client']) && $requestparams['client']!=null) ? $requestparams['client']:null;
    $sortBy         = (isset($requestparams['sortby']) && !empty($requestparams['sortby']) && $requestparams['sortby']!=null) ? $requestparams['sortby']:null;
    $dueDate        = (isset($requestparams['duedate']) && !empty($requestparams['duedate']) && $requestparams['duedate']!=null) ? $requestparams['duedate']:null;
    $keywordsearch  = (isset($requestparams['keywordsearch']) && !empty($requestparams['keywordsearch']) && $requestparams['keywordsearch']!=null) ? $requestparams['keywordsearch']:null;
    $briefingformid = (isset($requestparams['briefingformid']) && !empty($requestparams['briefingformid']) && $requestparams['briefingformid']!=null) ? $requestparams['briefingformid']:null;
    $gtype          = 'catalogue';
    $status         = '1';
    // Get total number of records.
    //$GetTotalRecords  = $this->GetTotalBriefingFormCataloguesList($clientsArray, $requestparams);
    // Page limit.
    //$pagelimits       = (isset($pageLimit) || $pageLimit!='0') ? $pageLimit : 100;
    // Page number.
    //$pagenos          = (isset($pageNo) || $pageNo!='0') ? $pageNo : 1;
    // Get page offset.
    //$offset           = ($pagenos-1) * $pagelimits;
    // Get total pages.
    //$total_pages      = ceil($GetTotalRecords / $pagelimits);
    // Check the sort by parameter.
    if($sortBy==null || $sortBy == '' || $sortBy == 'Latest') {
      $recordSortBy = 'DESC';
    } else if($sortBy =='Oldest') {
      $recordSortBy = 'ASC';
    } else {
      $recordSortBy = 'DESC';
    }
    try{
      // Get Catalogue Data Using Client Id and Status.
      $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->leftjoin('group_content_field_data', 'gcfd', 'gcfd.entity_id = nfd.nid');
      $query->leftjoin('groups_field_data', 'gfd', 'gfd.id = gcfd.gid');
      $query->leftjoin('node__field_catalogue_active', 'nfcact', 'nfcact.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_client_email', 'nfccmail', 'nfccmail.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_client_name', 'nfccname', 'nfccname.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_image', 'nfcimg', 'nfcimg.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_start_date', 'nfcsd', 'nfcsd.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_finish_date', 'nfcfd', 'nfcfd.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_completion_date', 'nfccd', 'nfccd.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_prod_due_date', 'nfcpdd', 'nfcpdd.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_ref_name', 'nfcrf', 'nfcrf.entity_id = nfd.nid');
      $query->leftjoin('node__field_active_catalogue_title', 'nfact', 'nfact.entity_id = nfd.nid');
      //$query->leftjoin('node__field_catalogue_image_link', 'nfcil', 'nfcil.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_queue_count', 'nfcqc', 'nfcqc.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_carousel_image', 'nfcci', 'nfcci.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_portal', 'nfcp', 'nfcp.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_pagecount', 'nfcpc', 'nfcpc.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_status', 'nfcstatus', 'nfcstatus.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_reference_id', 'nfbfrid', 'nfbfrid.entity_id = nfd.nid');
      $query->leftjoin('group__field_background_color', 'gfbgc', 'gfbgc.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_text_color', 'gftc', 'gftc.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_carousel_type', 'gfctype', 'gfctype.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_client_override_css', 'gfcocss', 'gfcocss.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_catalogue_theme', 'gfct', 'gfct.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_thumbnail_position', 'gftp', 'gftp.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_client_ga', 'gfecga', 'gfecga.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_geo_location', 'gfegl', 'gfegl.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_title_color', 'gftcolor', 'gftcolor.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_quick_view_lightbox', 'gfqvl', 'gfqvl.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_full_view_icon', 'gfefvi', 'gfefvi.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_category_list', 'gfecl', 'gfecl.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_user_login_help_text', 'gfulht', 'gfulht.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_retailer_id', 'gfretid', 'gfretid.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_geolocation_mapview', 'gfegmv', 'gfegmv.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_client_email', 'gfce', 'gfce.entity_id = gfd.id');
      $query->leftjoin('group__field_client_logo', 'gfclogo', 'gfclogo.entity_id = gfd.id');
      $query->addField('gcfd', 'id', 'gcfd_id');
      $query->addField('gcfd', 'gid', 'gcfd_group_id');
      $query->addField('gcfd', 'type', 'gcfd_type');
      $query->addField('gcfd', 'label', 'gcfd_label_username');
      $query->addField('gcfd', 'entity_id', 'gcfd_entity_userId');
      $query->addField('gfd', 'id', 'gfd_client_id');
      $query->addField('gfd', 'label', 'gfd_client_name');
      $query->addField('nfcact', 'field_catalogue_active_value', 'field_catalogue_active');
      $query->addField('nfccmail', 'field_catalogue_client_email_value', 'catalogue_client_email');
      $query->addField('nfccname', 'field_catalogue_client_name_value', 'catalogue_client_name');
      $query->addField('nfd', 'nid', 'nfd_catalogueID');
      $query->addField('nfd', 'type', 'nfd_type');
      $query->addField('nfd', 'title', 'nfd_catalogueName');
      $query->addField('nfd', 'uid', 'nfd_uid');
      $query->fields('nfcimg', array('field_catalogue_image_target_id', 'field_catalogue_image_alt', 'field_catalogue_image_title'));
      $query->addField('nfcsd', 'field_catalogue_start_date_value', 'field_catalogue_start_date');
      $query->addField('nfcfd', 'field_catalogue_finish_date_value', 'field_catalogue_finish_date');
      $query->addField('nfccd', 'field_catalogue_completion_date_value', 'field_catalogue_completion_date');
      $query->addField('nfcpdd', 'field_catalogue_prod_due_date_value', 'field_catalogue_production_due_date');
      $query->addField('nfcrf', 'field_catalogue_ref_name_value', 'field_catalogue_ref_name');
      $query->addField('nfact', 'field_active_catalogue_title_value', 'field_active_catalogue_title');
      //$query->fields('nfcil', array('field_catalogue_image_link_uri', 'field_catalogue_image_link_title'));
      $query->addField('nfcqc', 'field_catalogue_queue_count_value', 'field_catalogue_queue_count');
      $query->fields('nfcci', array('field_catalogue_carousel_image_uri', 'field_catalogue_carousel_image_title'));
      $query->addField('nfcp', 'field_catalogue_portal_value', 'field_catalogue_portal');
      $query->addField('nfbfrid', 'field_briefing_form_reference_id_target_id', 'field_briefing_form_id');
      $query->addField('gfbgc', 'field_background_color_value', 'field_background_color');
      $query->addField('gftc', 'field_text_color_value', 'field_text_color');
      $query->addField('gfctype', 'field_carousel_type_value', 'field_carousel_type');
      $query->addField('gfcocss', 'field_client_override_css_value', 'field_client_override_css');
      $query->fields('gfct', array('field_catalogue_theme_value', 'field_catalogue_theme_format'));
      $query->addField('gftp', 'field_thumbnail_position_value', 'field_thumbnail_position');
      $query->addField('gfecga', 'field_enable_client_ga_value', 'field_enable_client_ga');
      $query->addField('gfegl', 'field_enable_geo_location_value', 'field_enable_geo_location');
      $query->addField('gftcolor', 'field_title_color_value', 'field_title_color');
      $query->fields('gfqvl', array('field_quick_view_lightbox_target_id', 'field_quick_view_lightbox_target_revision_id'));
      $query->addField('gfefvi', 'field_enable_full_view_icon_value', 'field_enable_full_view_icon');
      $query->addField('gfecl', 'field_enable_category_list_value', 'field_enable_category_list');
      $query->addField('gfulht', 'field_user_login_help_text_value', 'field_user_login_help_text');
      $query->addField('gfretid', 'field_retailer_id_value', 'field_retailer_id');
      $query->addField('gfegmv', 'field_enable_geolocation_mapview_value', 'field_enable_geolocation_mapview');
      $query->addField('nfcpc', 'field_catalogue_pagecount_value', 'field_catalogue_pagecount');
      $query->addField('nfcstatus', 'field_catalogue_status_value', 'field_catalogue_status');
      $query->addField('gfce', 'field_client_email_value', 'field_client_email');
      $query->addField('gfclogo', 'field_client_logo_target_id', 'field_client_logo_target_id');
      $query->condition('nfd.type', $gtype, '=');
      $query->condition('gcfd.gid', $clientsArray, 'IN');
      // Check catalogue status.
      if($catStatus!=null && $catStatus!='all') {
        $query->condition('nfcstatus.field_catalogue_status_value', $db->escapeLike($catStatus), '=');
      }
      // Check catalogue client name.
      if($clientName!=null) {
        $query->condition('nfccname.field_catalogue_client_name_value', $db->escapeLike($clientName), '=');
      }
      // Check the catalogue due date.
      if($dueDate!=null) {
        $catalogueDueDate = date('Y-m-d', strtotime($dueDate));
        $startDate = $catalogueDueDate.'T00:00:00';
        $endDate = $catalogueDueDate.'T23:59:59';
        $query->condition('nfcfd.field_catalogue_finish_date_value', array($startDate, $endDate), 'BETWEEN');
      }
      // Keyword search condition in catalogue name, client name.
      if($keywordsearch!=null) {
        // Create the orConditionGroup.
        $orGroup = $query->orConditionGroup()
        ->condition('nfd.title', "%" . $db->escapeLike($keywordsearch) . "%" , 'LIKE')
        ->condition('nfccname.field_catalogue_client_name_value', "%" . $db->escapeLike($keywordsearch) . "%" , 'LIKE');
        // Add the group to the query.
        $query->condition($orGroup);
      }
      // Briefing form id.
      if($briefingformid!=null){
        $query->condition('nfbfrid.field_briefing_form_reference_id_target_id', $db->escapeLike($briefingformid), '=');
      }
      $query->groupBy('nfd.nid');
      $query->orderBy('nfd.nid', $recordSortBy);
      $countQuery = $query;
      // Get query total records count.
      $countresults     = $countQuery->execute()->fetchAll();
      $GetTotalRecords  = count($countresults);
      // Page limit.
      $pagelimits       = (isset($pageLimit) || $pageLimit!='0') ? $pageLimit : 100;
      // Page number.
      $pagenos          = (isset($pageNo) || $pageNo!='0') ? $pageNo : 1;
      // Get page offset.
      $offset           = ($pagenos-1) * $pagelimits;
      // Get total pages.
      $total_pages      = ceil($GetTotalRecords / $pagelimits);
      $query->range($offset, $pagelimits);
      // Get query result set.
      $results = $query->execute()->fetchAll();
      if($results) {
        foreach($results as $res) {
          // Get quick view lightbox details by gid.
          $imagePath = '';
          $getQuickViewLightbox = $this->getQuickViewLightboxBygid($res->gcfd_group_id);
          $image_path = $this->GetFileURLByFID($res->field_catalogue_image_target_id);
          if(isset($image_path) && $image_path!='') {
            $imagePath = $image_path;
          } 
          // Get Client Logo.
          if(!empty($res->field_client_logo_target_id)) {
            $logo_file  = File::load($res->field_client_logo_target_id);
            $logouri   = $logo_file->getFileUri();
            $logo_uri   = file_create_url($logouri);
          } else {
            $logo_uri   = '';
          }
          // !empty($field_bfcatregion_bf_id)?$field_bfcatregion_bf_id:null,
          $catId = !empty($results['nfd_catalogueID'])?$results['nfd_catalogueID']:null;
          $GetPages = $this->GetCatalogueAllPagesAssignedUserDetails($catId, $userID, $usertype ='');
          $arrData[] = array(
            'briefingform_id'                     => !empty($res->field_briefing_form_id)?$res->field_briefing_form_id:null,
            'title'                               => !empty($res->nfd_catalogueName)?$res->nfd_catalogueName:null,
            'field_catalogue_image'               => 'false',
            'image'                               => $imagePath,
            'field_catalogue_start_date'          => !empty($res->field_catalogue_start_date)?$res->field_catalogue_start_date:null,
            'field_catalogue_finish_date'         => !empty($res->field_catalogue_finish_date)?$res->field_catalogue_finish_date:null,
            'field_catalogue_completion_date'     => !empty($res->field_catalogue_completion_date)?$res->field_catalogue_completion_date:null,
            'field_catalogue_production_due_date' => !empty($res->field_catalogue_production_due_date)?$res->field_catalogue_production_due_date:null,
            'nid_1'                               => !empty($res->nfd_catalogueID)?$res->nfd_catalogueID:null,
            'share'                               => !empty($res->field_catalogue_ref_name)?$res->field_catalogue_ref_name:null,
            'field_catalogue_queue_count'         => !empty($res->field_catalogue_queue_count)?$res->field_catalogue_queue_count:null,
            'field_active_catalogue_title'        => !empty($res->field_active_catalogue_title)?$res->field_active_catalogue_title:null,
            'field_text_color'                    => !empty($res->field_text_color)?$res->field_text_color:null,
            'field_carousel_type'                 => !empty($res->field_carousel_type)?$res->field_carousel_type:null,
            'field_client_override_css'           => !empty($res->field_client_override_css)?$res->field_client_override_css:null,
            'field_catalogue_theme'               => !empty($res->field_catalogue_theme_value)?$res->field_catalogue_theme_value:null,
            'field_thumbnail_position'            => !empty($res->field_thumbnail_position)?$res->field_thumbnail_position:null,
            'field_enable_client_ga'              => !empty($res->field_enable_client_ga)?$res->field_enable_client_ga:null,
            'field_background_color'              => !empty($res->field_background_color)?$res->field_background_color:null,
            'field_background_color_1'            => !empty($res->field_background_color)?$res->field_background_color:null,
            'field_enable_geo_location'           => !empty($res->field_enable_geo_location)?$res->field_enable_geo_location:null,
            'field_title_color'                   => !empty($res->field_title_color)?$res->field_title_color:null,
            'field_catalogue_carousel_image'      => !empty($res->field_catalogue_carousel_image_uri)?$res->field_catalogue_carousel_image_uri:null,
            'field_enable_full_view_icon'         => !empty($res->field_enable_full_view_icon)?$res->field_enable_full_view_icon:null,
            'field_enable_category_list'          => !empty($res->field_enable_category_list)?$res->field_enable_category_list:null,
            'field_user_login_help_text'          => !empty($res->field_user_login_help_text)?$res->field_user_login_help_text:null,
            'field_retailer_id'                   => !empty($res->field_retailer_id)?$res->field_retailer_id:null,
            'domain'                              => null,
            'field_quick_view_lightbox'           => $getQuickViewLightbox,
            'field_enable_geolocation_mapview'    => !empty($res->field_enable_geolocation_mapview)?$res->field_enable_geolocation_mapview:null,
            'field_catalogue_portal'              => !empty($res->field_catalogue_portal)?$res->field_catalogue_portal:null,
            'field_catalogue_page'                => !empty($res->field_catalogue_pagecount)?$res->field_catalogue_pagecount:null,
            'field_catalogue_status'              => !empty($res->field_catalogue_status)?$res->field_catalogue_status:null,
            'field_catalogue_client_id'           => !empty($res->gfd_client_id)?$res->gfd_client_id:null,
            'field_catalogue_client_logo'         => $logo_uri,
            'field_catalogue_client_name'         => !empty($res->gfd_client_name)?$res->gfd_client_name:null,
            'field_catalogue_client_email'        => !empty($res->field_client_email)?$res->field_client_email:null,
            'field_page_assignees'                => $GetPages,
          );
        }
        $return = array(
          'status'        => 'success',
          'total_records' => $GetTotalRecords,
          'total_pages'   => $total_pages,
          'num_results'   => $pagelimits,
          'current_pageno'=> $pagenos,
          'result_rows'   => $arrData,
        );
        return $return;
      } else {
        $results = ['status' => 'error', 'status_message' => 'No Record Found.'];   
        return $results;
      }
    } catch(\Exception $e){
      $results = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $results;
    }
  }

  public function getQuickViewLightboxBygid($gid) {
    $query = \Drupal::database()->select('group__field_quick_view_lightbox', 'A');
    $query->fields('A', ['entity_id','field_quick_view_lightbox_target_id']);
    $query->condition('A.entity_id', $gid);
    $query->orderBy('entity_id', 'DESC');
    $results = $query->execute()->fetchAll();
    $i=0;$arrData = array();
    foreach($results as $rck => $data){
      $arrData[$i] = $data->field_quick_view_lightbox_target_id;
      $i++;
    }
    return $arrData;
  }

  /**
   * Get File Full URL from File Managed Table using FID.
   */
  public function GetFileURLByFID($fid) {
    $path = '';
    if($fid) {
      $file = File::load($fid);
      if($file->getFileUri()) {
        $path = file_create_url($file->getFileUri());
      }
    }
    return $path;
  }

  public function GetFileURLByTargetId($targetId) {
    // S3 Bucket settings.
    $config = \Drupal::config('s3fs.settings');
    $s3config = $config->get();
    $domain = UrlHelper::filterBadProtocol($s3config['domain']);
    $pdf_path = '';
    // Check the target id is empty or not.
    if ($targetId ) {
      $file 	        = File::load($targetId);
      $file_uri 	    = $file->getFileUri();
      $path_explode   = explode("s3:/",$file_uri);
      if($path_explode[1] != ""){
        $pdf_path   = str_replace('s3:/','https://' . $domain, $pdf_uri);
      }else{
        $pdf_path   = str_replace('private:/','https://' . $domain, $pdf_uri);
      }
    }
    return $pdf_path;
  }

  /**
  * Function for get all asset data by using current client and briefing form Id.
  **/
  public function getBFAssetsListByParams($userID, $BriefingFormID) {
    try{
      // S3 Bucket settings.
      $config = \Drupal::config('s3fs.settings');
      $s3config = $config->get();
      $domain = UrlHelper::filterBadProtocol($s3config['domain']);
      $pdf_path = '';
      // Assets Briefing Form Node Name.
      $nodeType = 'briefingform_assets';
      // Select Query.
      $query = \Drupal::database()->select('node__field_asset_briefingform_id', 'nfabfid');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfabfid.entity_id');
      $query->leftjoin('node__field_bf_asset_comments', 'nfbf_ac', 'nfbf_ac.entity_id = nfabfid.entity_id');
      $query->leftjoin('node__field_bf_asset_id', 'nfbf_aid', 'nfbf_aid.entity_id = nfabfid.entity_id');
      $query->leftjoin('node__field_bf_asset_type_id', 'nfbf_atid', 'nfbf_atid.entity_id = nfabfid.entity_id');
      $query->leftjoin('node__field_bf_form_type', 'nfbf_ft', 'nfbf_ft.entity_id = nfabfid.entity_id');
      $query->leftjoin('node__field_bf_asset_catalogue_id', 'nfbfacid', 'nfbfacid.entity_id = nfabfid.entity_id');
      $query->addField('nfd', 'nid', 'briefingform_asset_nid');
      $query->addField('nfd', 'type', 'node_type');
      $query->addField('nfd', 'title', 'node_title');
      $query->addField('nfd', 'uid', 'briefingform_userid');
      $query->addField('nfabfid', 'field_asset_briefingform_id_target_id', 'field_asset_briefingform_id');
      //$query->addField('nfabfid', 'entity_id', 'nfabfid.entity_id');
      $query->addField('nfbf_ac', 'field_bf_asset_comments_value', 'field_bf_asset_comments');
      $query->addField('nfbf_aid', 'field_bf_asset_id_value', 'field_bf_asset_id');
      $query->addField('nfbf_atid', 'field_bf_asset_type_id_target_id', 'field_bf_asset_type_id');
      $query->addField('nfbf_ft', 'field_bf_form_type_value', 'field_bf_form_type');
      $query->addField('nfbfacid', 'field_bf_asset_catalogue_id_target_id', 'field_catalogue_id');
      //$query->condition('nfd.type', $nodeType);
      //$query->condition('nfd.uid', $userID);
      $query->condition('nfabfid.field_asset_briefingform_id_target_id', $BriefingFormID);
      $query->orderBy('nfabfid.entity_id', 'ASC');
      $results = $query->execute()->fetchAll();
      if(!empty( $results )){
        foreach($results as $res) {
          // Get Asset type from id.
          $getAssetType = $this->GetAssetsTypeById($res->field_bf_asset_type_id);
          //$field_assets_file = $this->GetFileURLByTargetId($res->field_bf_asset_id);
          $field_assets_fid = $res->field_bf_asset_id;
          if($field_assets_fid) {
            $file 	        = File::load($field_assets_fid);
            $file_uri 	    = $file->getFileUri();
            $path_explode   = explode("s3:/",$file_uri); 
            if($path_explode[1] != ""){
              $file_path   = str_replace('s3:/','https://' . $domain, $file_uri);
            }else{
              $file_path   = str_replace('private:/','https://' . $domain, $file_uri);
            }
          } else { $file_path = ''; }
          $arrData[] = array(
            'field_assets_nid'        => !is_null($res->briefingform_asset_nid)?$res->briefingform_asset_nid:null,
            'field_assets_bf_id'      => !is_null($res->field_asset_briefingform_id)?$res->field_asset_briefingform_id:null,
            'field_form_type'         => !is_null($res->field_bf_form_type)?$res->field_bf_form_type:null,
            'field_assets_fid'        => !is_null($res->field_bf_asset_id)?$res->field_bf_asset_id:null,
            'field_assets_file'       => $file_path,
            'field_asset_type_id'     => !is_null($res->field_bf_asset_type_id)?$res->field_bf_asset_type_id:null,
            'field_asset_type_title'  => $getAssetType,
            'field_asset_notes'       => !is_null($res->field_bf_asset_comments)?$res->field_bf_asset_comments:null,
            'field_catalogue_id'      => !is_null($res->field_catalogue_id)?$res->field_catalogue_id:null
          );
        }
        return $arrData;
      } else {
        $results = ['status' => 'error', 'status_message' => 'No Record Found.'];   
        return $results;
      }
    } catch(\Exception $e){
      $results = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $results;
    }
  }

  /**
  * Function for get asset type name by using Id.
  **/
  public function GetAssetsTypeById($typeId) {
    // Node Load by using node id.
    $node = \Drupal\node\Entity\Node::load($typeId);
    if($node) {
      $title = $node->getTitle();
      if(!empty($title)) {
        return $title;
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  /**
  * Function for get all asset data by using current client and briefing form Id.
  **/
  public function GetBFAssetsNodeIDByParams($userID, $BriefingFormID) {
    $getBFAssetsList = $this->getBFAssetsListByParams($userID, $BriefingFormID);
    if(!empty( $getBFAssetsList )){
      $i=0;$arrData = array();
      foreach($getBFAssetsList as $key => $value) {
        $arrData[$i] = $value['field_assets_nid'];
        $i++;
      }
      return $arrData;
    } else {
      $results = ['status' => 'error', 'status_message' => 'No Record Found.'];   
      return $results;
    }
  }

  /**
  * Function :: Get all mail type for briefing form.
  */
  public function GetBFmailType() {
    // Get Node Details By using node type.
    $nids = \Drupal::entityQuery('node')
                  ->condition('status', 1)
                  ->condition('type', 'briefing_form_mail_type')
                  ->execute();
    foreach ($nids as $nid) {
      $node = \Drupal\node\Entity\Node::load($nid);
      $arrData[] = array(
        'mail_type_id'   => $node->id(),
        'mail_type_name' => $node->title->value
      );
    }
    return $arrData;
  }

  /** 
  * Function :: Get briefing form client catalogue intoduction popup.
  */
  public function GetBF_CatalogueIntroductionpopup($clientID) {
    //Drupal\group\Entity\Group
    $bf_client_introduction_pop = 0;
    $Group = \Drupal\group\Entity\Group::load($clientID);
    if($Group->id()) {
      $bf_client_introduction_pop = $Group->field_bf_client_introduction_pop->value;
    }
    $arrData['field_bf_client_introduction_pop'] = $bf_client_introduction_pop;
    return $arrData;
  }

  /** 
  * Function :: Save briefing form client catalogue intoduction popup status.
  */
  public function SaveBFCatalogueIntroductionpopupStatus($jsondata) {

    $clientID = $jsondata['field_bf_client_id'];
    $status   = $jsondata['field_bf_client_introduction_pop'];
    $userID   = $jsondata['field_user_id'];
    # Database Connection.
		$db 	= \Drupal::database();
    # Select Query From Group.
    $Group    = \Drupal\group\Entity\Group::load($clientID);
    $groupID  = isset($Group) && !empty($Group)?$Group->id():null;
    if($groupID!=null) {
      # Select Query.
      $query 	= $db->select('group__field_bf_client_introduction_pop', 'n');
      $query->fields('n');
      $query->condition('entity_id', $groupID, "=");
      $resultData = $query->execute()->fetchAssoc();
      if(!isset($resultData['field_bf_client_introduction_pop_value'])) {
        // Insert briefing form client catalogue intoduction popup status.
        try{
          $insertQry = \Drupal::database()->insert('group__field_bf_client_introduction_pop')
            ->fields([
              'bundle' => 'client',
              'deleted' => '0',
              'entity_id' => $clientID,
              'revision_id' => '1',
              'langcode' => 'en',
              'delta' => '0',
              'field_bf_client_introduction_pop_value' => $status
            ])->execute();
          if($insertQry) {
            $response = ['status' => 'success', 'status_message' => 'Client catalogue introduction popup status updated successfully.'];
          } else {
            $response = ['status' => 'error', 'status_message' => 'Client catalogue introduction popup status not updated successfully.'];
          }
          return $response;
        } catch (Exception $e) {
          $response = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
          return $response;
        }
      } else {
        $entityId = $resultData['entity_id'];
        // Update query briefing form client catalogue intoduction popup status.
        try{
          $updateQry = \Drupal::database()->update('group__field_bf_client_introduction_pop')
            ->fields(['field_bf_client_introduction_pop_value' => $status])
            ->condition('entity_id', $entityId)
            ->execute();
          if($updateQry) {
            $response = ['status' => 'success', 'status_message' => 'Client catalogue introduction popup status updated successfully.'];
          } else {
            $response = ['status' => 'error', 'status_message' => 'Client catalogue introduction popup status not updated successfully.'];
          }
          return $response;
        } catch (Exception $e) {
          $response = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
          return $response;
        }
      }
    } else {
      $response = ['status' => 'error', 'status_message' => 'Bad request.'];
      return $response;
    }
  }

  /**
  * Function Get User id by UUID.
  */
  public function GetUserIDBy_UUID($UUID) {
      $query 	= \Drupal::database()->select('users', 'U');
  $query->fields('U');
  $query->condition('U.uuid', $UUID, "=");
  $data 	 = $query->execute();
  $results = $data->fetchAssoc();
      if($results['uid']!='') {
          return $results['uid'];
      } else {
          return '0';
      }
  }

  /** 
  * Function :: Save briefing form region edit client’s notes.
  */
  public function SaveBFRegionClientNotesDetails($jsondata) {

    $field_bfcatregion_bf_id          = $jsondata['field_bfcatregion_bf_id'];
    $field_bfcatregion_catalogue_id   = $jsondata['field_bfcatregion_catalogue_id'];
    $field_bfcatregion_client_id      = $jsondata['field_bfcatregion_client_id'];
    $field_bfcatregion_client_notes   = $jsondata['field_bfcatregion_client_notes'];
    $field_bfcatregion_loggedinuserid = $jsondata['field_bfcatregion_loggedinuserid'];
    $field_bfcatregion_page_number    = $jsondata['field_bfcatregion_page_number'];
    $field_bfcatregion_region_id      = $jsondata['field_bfcatregion_region_id'];
    $field_bfcatregion_region_name    = $jsondata['field_bfcatregion_region_name'];
    $node_type                        = 'bf_catalogue_region_client_notes';
    $node_title                       = 'BF Catalogue Region Client Notes';
    $field_bfcatregion_bf_id          = !empty($field_bfcatregion_bf_id)?$field_bfcatregion_bf_id:null;
    $userID                           = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
    //$user   = User::load(\Drupal::currentUser()->id());
    //$userID = $user->get('uid')->value;
    /*if($field_bfcatregion_bf_id) {
      $userID = $this->GetBFDetailsByBFID($field_bfcatregion_bf_id);
    } else {
      $userID = null;
    }*/
    $CatNode = Node::load($field_bfcatregion_catalogue_id);
    $title = $CatNode->getTitle();
    try{
      $BFRegionCreatedData = array(
        'type'                              => $node_type,
        'title'                             => $title,
        'field_bfcatregion_bf_id'           => !empty($field_bfcatregion_bf_id)?$field_bfcatregion_bf_id:null,
        'field_bfcatregion_catalogue_id'    => !empty($field_bfcatregion_catalogue_id)?$field_bfcatregion_catalogue_id:null,
        'field_bfcatregion_client_id'       => !empty($field_bfcatregion_client_id)?$field_bfcatregion_client_id:null,
        'field_bfcatregion_client_notes'    => !empty($field_bfcatregion_client_notes)?$field_bfcatregion_client_notes:null,
        'field_bfcatregion_loggedinuserid'  => !empty($field_bfcatregion_loggedinuserid)?$field_bfcatregion_loggedinuserid:null,
        'field_bfcatregion_page_number'     => !empty($field_bfcatregion_page_number)?$field_bfcatregion_page_number:null,
        'field_bfcatregion_region_id'       => !empty($field_bfcatregion_region_id)?$field_bfcatregion_region_id:null,
        'field_bfcatregion_region_name'     => !empty($field_bfcatregion_region_name)?$field_bfcatregion_region_name:null
      );
      // Inserting New Record.
      $node = Node::create($BFRegionCreatedData);
      $Save = $node->save();
      $region_nid = $node->id();
      if($Save) {
        $result = ['status' => 'success', 'status_message' => 'Region clients details saved successfully.'];
      } else {
        $result = ['status' => 'error', 'status_message' => 'Region clients details not saved successfully.'];
      }
      $BFRegionCreatedData['region_nid'] = $region_nid;
      $responseData                      = $BFRegionCreatedData;
    } catch (Exception $e) {
      $result       = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      $responseData = $jsondata;
    }
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'POST', $node_type, $responseData, $userID, $result);
    return $result;
  }

  /** 
  * Function :: patch briefing form region edit client’s notes.
  */
  public function PatchBFRegionClientNotesDetails($jsondata) {

    $field_bfcatregion_node_id        = !empty($jsondata['field_bfcatregion_node_id'])?$jsondata['field_bfcatregion_node_id']:null;
    $field_bfcatregion_bf_id          = !empty($jsondata['field_bfcatregion_bf_id'])?$jsondata['field_bfcatregion_bf_id']:null;
    $field_bfcatregion_catalogue_id   = !empty($jsondata['field_bfcatregion_catalogue_id'])?$jsondata['field_bfcatregion_catalogue_id']:null;
    $field_bfcatregion_client_id      = !empty($jsondata['field_bfcatregion_client_id'])?$jsondata['field_bfcatregion_client_id']:null;
    $field_bfcatregion_client_notes   = !empty($jsondata['field_bfcatregion_client_notes'])?$jsondata['field_bfcatregion_client_notes']:null;
    $field_bfcatregion_loggedinuserid = !empty($jsondata['field_bfcatregion_loggedinuserid'])?$jsondata['field_bfcatregion_loggedinuserid']:null;
    $field_bfcatregion_page_number    = !empty($jsondata['field_bfcatregion_page_number'])?$jsondata['field_bfcatregion_page_number']:null;
    $field_bfcatregion_region_id      = !empty($jsondata['field_bfcatregion_region_id'])?$jsondata['field_bfcatregion_region_id']:null;
    $field_bfcatregion_region_name    = !empty($jsondata['field_bfcatregion_region_name'])?$jsondata['field_bfcatregion_region_name']:null;
    $node_type                        = 'bf_catalogue_region_client_notes';
    $node_title                       = 'BF Catalogue Region Client Notes';
    $userID                           = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
    //$user   = User::load(\Drupal::currentUser()->id());
    //$userID = $user->get('uid')->value;
    /*if($field_bfcatregion_bf_id) {
      $userID = $this->GetBFDetailsByBFID($field_bfcatregion_bf_id);
    } else {
      $userID = null;
    }*/
    try{
      // Updated Record.
      if($field_bfcatregion_node_id!=null) {
        $node = Node::load($field_bfcatregion_node_id);
        $nodeTitle = $node->getTitle();
        $node->set('type',$node_type);
        $node->set('title', $nodeTitle);
        $node->set('field_bfcatregion_bf_id', $field_bfcatregion_bf_id);
        $node->set('field_bfcatregion_catalogue_id', $field_bfcatregion_catalogue_id);
        $node->set('field_bfcatregion_client_id', $field_bfcatregion_client_id);
        $node->set('field_bfcatregion_client_notes', $field_bfcatregion_client_notes);
        $node->set('field_bfcatregion_loggedinuserid', $field_bfcatregion_loggedinuserid);
        $node->set('field_bfcatregion_page_number', $field_bfcatregion_page_number);
        $node->set('field_bfcatregion_region_id', $field_bfcatregion_region_id);
        $node->set('field_bfcatregion_region_name', $field_bfcatregion_region_name);
        $update = $node->save();
        $BFRegionUpdatedData = array(
          'type'                            => $node_type,
          'title'                           => $nodeTitle,
          'field_bfcatregion_bf_id'         => $field_bfcatregion_bf_id,
          'field_bfcatregion_catalogue_id'  => $field_bfcatregion_catalogue_id,
          'field_bfcatregion_client_id'     => $field_bfcatregion_client_id,
          'field_bfcatregion_client_notes'  => $field_bfcatregion_client_notes,
          'field_bfcatregion_loggedinuserid'=> $field_bfcatregion_loggedinuserid,
          'field_bfcatregion_page_number'   => $field_bfcatregion_page_number,
          'field_bfcatregion_region_id'     => $field_bfcatregion_region_id,
          'field_bfcatregion_region_name'   => $field_bfcatregion_region_name,
          'region_nid'                      => $field_bfcatregion_node_id
        );
        if($update) {
          $result       = ['status' => 'success', 'status_message' => 'Region clients details updated successfully.'];
          $responseData = $BFRegionUpdatedData;
        } else {
          $result       = ['status' => 'error', 'status_message' => 'Region clients details not updated successfully.'];
          $responseData = $BFRegionUpdatedData;
        }
      } else {
        $result       = ['status' => 'error', 'status_message' => 'Region clients details not updated successfully.'];
        $responseData = $jsondata;
      }
    } catch (Exception $e) {
      $result       = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      $responseData = $jsondata;
    }
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'PATCH', $node_type, $responseData, $userID, $result);
    return $result;
  }

  /** 
  * Function :: delete briefing form region edit client’s notes.
  */
  public function DeleteBFRegionClientNotesDetails($jsondata) {
    $node_type = 'bf_catalogue_region_client_notes';
    $userID    = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
    $field_bfcatregion_node_id = !empty($jsondata['field_bfcatregion_node_id'])?$jsondata['field_bfcatregion_node_id']:null;
    if($field_bfcatregion_node_id!=null) {
      try{
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($field_bfcatregion_node_id);
        // Check if node exists with the given nid.
        if ($node) {
          $delete = $node->delete();
          $result = ['status' => 'success', 'status_message' => 'Region clients details deleted successfully.'];
        } else {
          $result = ['status' => 'error', 'status_message' => 'Region clients details not deleted successfully.'];
        }
      } catch (Exception $e) {
        $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      }
    } else {
      $result = ['status' => 'error', 'status_message' => 'Region clients details not deleted successfully.'];
    }
    $responseData = $jsondata;
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'Delete', $node_type, $responseData, $userID, $result);
    return $result;
  }

  /**
  * Function for get catalogue reference based on catalogue id and regions with page number.
  */
  public function getCatalogueRegionClientNotesHandler($briefingformID, $catalogueID, $startpage = '', $endpage = '', $userID){
    try{
      if(isset($startpage) && isset($endpage)){
        $range = range($startpage, $endpage);
      }
      $query = \Drupal::database()->select('node__field_bfcatregion_bf_id', 'nfbfcat_bfid');
      $query->leftjoin('node__field_bfcatregion_catalogue_id', 'nfbfcat_catid', 'nfbfcat_catid.entity_id = nfbfcat_bfid.entity_id');
      $query->leftjoin('node__field_bfcatregion_client_id', 'nfbfcat_clientid', 'nfbfcat_clientid.entity_id= nfbfcat_bfid.entity_id');
      $query->leftjoin('node__field_bfcatregion_client_notes', 'nfbfcat_clientnotes', 'nfbfcat_clientnotes.entity_id = nfbfcat_bfid.entity_id');
      $query->leftjoin('node__field_bfcatregion_loggedinuserid', 'nfbfcat_uid', 'nfbfcat_uid.entity_id = nfbfcat_bfid.entity_id');
      $query->leftjoin('node__field_bfcatregion_page_number', 'nfbfcat_pno', 'nfbfcat_pno.entity_id = nfbfcat_bfid.entity_id');
      $query->leftjoin('node__field_bfcatregion_region_id', 'nfbfcat_regid', 'nfbfcat_regid.entity_id = nfbfcat_bfid.entity_id');
      $query->leftjoin('node__field_bfcatregion_region_name', 'nfbfcat_regname', 'nfbfcat_regname.entity_id = nfbfcat_bfid.entity_id');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcat_bfid.entity_id');
      $query->addField('nfbfcat_bfid', 'entity_id', 'entity_id');
      $query->addField('nfbfcat_bfid', 'field_bfcatregion_bf_id_target_id', 'field_bfcatregion_bf_id');
      $query->addField('nfbfcat_catid', 'field_bfcatregion_catalogue_id_target_id', 'field_bfcatregion_catalogue_id');
      $query->addField('nfbfcat_clientid', 'field_bfcatregion_client_id_value', 'field_bfcatregion_client_id');
      $query->addField('nfbfcat_clientnotes', 'field_bfcatregion_client_notes_value', 'field_bfcatregion_client_notes');
      $query->addField('nfbfcat_uid', 'field_bfcatregion_loggedinuserid_target_id', 'field_bfcatregion_loggedinuserid');
      $query->addField('nfbfcat_pno', 'field_bfcatregion_page_number_value', 'field_bfcatregion_page_number');
      $query->addField('nfbfcat_regid', 'field_bfcatregion_region_id_target_id', 'field_bfcatregion_region_id');
      $query->addField('nfbfcat_regname', 'field_bfcatregion_region_name_value', 'field_bfcatregion_region_name');
      $query->condition('nfbfcat_bfid.field_bfcatregion_bf_id_target_id', $briefingformID);
      $query->condition('nfbfcat_catid.field_bfcatregion_catalogue_id_target_id', $catalogueID);
      $query->condition('nfbfcat_pno.field_bfcatregion_page_number_value', $range, 'IN');
      $result = $query->execute()->fetchAll();
      if(!empty( $result )){
        foreach($result as $res) {
          $arrData[] = array(
            'field_bfcatregion_node_id'         => $res->entity_id,
            'field_bfcatregion_bf_id'           => $res->field_bfcatregion_bf_id,
            'field_bfcatregion_catalogue_id'    => $res->field_bfcatregion_catalogue_id,
            'field_bfcatregion_client_id'       => $res->field_bfcatregion_client_id,
            'field_bfcatregion_client_notes'    => $res->field_bfcatregion_client_notes,
            'field_bfcatregion_loggedinuserid'  => $res->field_bfcatregion_loggedinuserid,
            'field_bfcatregion_page_number'     => $res->field_bfcatregion_page_number,
            'field_bfcatregion_region_id'       => $res->field_bfcatregion_region_id,
            'field_bfcatregion_region_name'     => $res->field_bfcatregion_region_name,
          );
        }
        return $arrData;
      } else {
        $results = ['status' => 'error', 'status_message' => 'No Record Found.'];   
      }
    } catch(\Exception $e){
      $results = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
    }
    return $results;
  }

  /**
  * Function for get catalogue reference based on catalogue id and regions with page number.
  */
  public function getCatalogueAllRegionClientEditCountAllPagesHandler($briefingformID, $catalogueID, $userID){

    if(!empty($briefingformID) && !empty($catalogueID)) {
      $GetCataloguePageNo = $this->GetCataloguePageNosByParam($catalogueID);
      try{
        foreach($GetCataloguePageNo as $key => $pageres) {
          $page_number  = $pageres['catalogue_page_value'];
          $catalogue_id = $pageres['catalogue_id'];
          $query = \Drupal::database()->select('node__field_bfcatregion_bf_id', 'nfbfcat_bfid');
          $query->leftjoin('node__field_bfcatregion_catalogue_id', 'nfbfcat_catid', 'nfbfcat_catid.entity_id = nfbfcat_bfid.entity_id');
          $query->leftjoin('node__field_bfcatregion_client_id', 'nfbfcat_clientid', 'nfbfcat_clientid.entity_id= nfbfcat_bfid.entity_id');
          $query->leftjoin('node__field_bfcatregion_page_number', 'nfbfcat_pno', 'nfbfcat_pno.entity_id = nfbfcat_bfid.entity_id');
          //$query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcat_bfid.entity_id');
          $query->addField('nfbfcat_bfid', 'field_bfcatregion_bf_id_target_id', 'field_bfcatregion_bf_id');
          $query->addField('nfbfcat_catid', 'field_bfcatregion_catalogue_id_target_id', 'field_bfcatregion_catalogue_id');
          $query->addField('nfbfcat_clientid', 'field_bfcatregion_client_id_value', 'field_bfcatregion_client_id');
          $query->addField('nfbfcat_pno', 'field_bfcatregion_page_number_value', 'field_bfcatregion_page_number');
          $query->condition('nfbfcat_bfid.field_bfcatregion_bf_id_target_id', $briefingformID);
          $query->condition('nfbfcat_catid.field_bfcatregion_catalogue_id_target_id', $catalogue_id);
          $query->condition('nfbfcat_pno.field_bfcatregion_page_number_value', $page_number);
          $query->orderBy('nfbfcat_pno.field_bfcatregion_page_number_value', 'ASC');
          $query->allowRowCount = TRUE;
          $result = $query->execute()->fetchAll();
          if(!empty( $result )){
            $numRows = 0;
            foreach($result as $res) {
              $numRows++;
            }
          } else {
            $numRows = 0;
          }
          $arrData[] = array(
            'page_number'   => $page_number,
            'catalogue_id'  => $catalogue_id,
            'pageeditcount' => $numRows,
          );
        }
        if(!empty($arrData)) {
          return $arrData;
        } else {
          $arrData = array();
          return $arrData;
        }
      } catch(\Exception $e){
        $results = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      }
    } else {
      $results = ['status' => 'error', 'status_message' => 'Bad request!.'];   
    }
    return $results;
  }

  /**
  * Function :: Get catalogue all page numbers by catalogue id.
  */
  public function GetCataloguePageNosByParam($catalogueID) {
    try{
      $query = \Drupal::database()->select('node__field_catalogue_reference', 'nfcr');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfcr.entity_id');
      $query->leftjoin('node__field_catalogue_page', 'nfcp', 'nfcp.entity_id = nfcr.entity_id');
      $query->addField('nfcr', 'field_catalogue_reference_target_id', 'catalogue_id');
      $query->addField('nfd', 'type', 'nodetype');
      $query->addField('nfcp', 'field_catalogue_page_value', 'catalogue_page_value');
      $query->condition('nfd.type', 'catapage');
      $query->condition('nfcr.field_catalogue_reference_target_id', $catalogueID);
      $query->condition('nfcp.field_catalogue_page_value', '0', '>');
      $query->orderBy('nfcp.field_catalogue_page_value', 'ASC');
      $result = $query->execute()->fetchAll();
      if(!empty( $result )){
        foreach($result as $res) {
          $arrData[] = array(
            'catalogue_id'          => $res->catalogue_id,
            'nodetype'              => $res->nodetype,
            'catalogue_page_value'  => $res->catalogue_page_value,
          );
        }
        return $arrData;
      } else {
        return false;
      }
    } catch(\Exception $e){
      return false;
    }
  }

  /**
   * FUnction :: Check assigned page number already exists or not.
   */
  public function CheckAssignedPageNumberAlreadyExistsOrNot($pageno, $catalogueId, $field_bf_catasur_assign_userrole) {
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'cataupage_node_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catau_page_number');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catau_page_status');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcpn.field_bf_catau_page_number_value', $pageno);
    $query->condition('nfbfcpur.field_bf_catau_assigng_user_role_value', $field_bf_catasur_assign_userrole);
    //$query->allowRowCount = TRUE;
    $result = $query->execute()->fetchAssoc();
    if(!empty($result)) {
      $nodeId = $result['cataupage_node_id'];
    } else {
      $nodeId = '';
    }
    return $nodeId;
  }

  /** 
  * Function :: 27 a) Save briefing form catalogue assigning user details.
  */
  public function SaveBFCatalogueAssigningUserDetails($jsondata) {

    $field_bf_catasur_assigning_notes = isset($jsondata['field_bf_catasur_assigning_notes']) && !empty($jsondata['field_bf_catasur_assigning_notes'])?$jsondata['field_bf_catasur_assigning_notes']:null;
    $field_bf_catasur_assigninguserid = isset($jsondata['field_bf_catasur_assigninguserid']) && !empty($jsondata['field_bf_catasur_assigninguserid'])?$jsondata['field_bf_catasur_assigninguserid']:null;
    $field_bf_catasur_briefingform_id = isset($jsondata['field_bf_catasur_briefingform_id']) && !empty($jsondata['field_bf_catasur_briefingform_id'])?$jsondata['field_bf_catasur_briefingform_id']:null;
    $field_bf_catasur_catalogue_id    = isset($jsondata['field_bf_catasur_catalogue_id']) && !empty($jsondata['field_bf_catasur_catalogue_id'])?$jsondata['field_bf_catasur_catalogue_id']:null;
    $field_bf_catasur_client_id       = isset($jsondata['field_bf_catasur_client_id']) && !empty($jsondata['field_bf_catasur_client_id'])?$jsondata['field_bf_catasur_client_id']:null;
    $field_bf_catasur_due_date        = isset($jsondata['field_bf_catasur_due_date']) && !empty($jsondata['field_bf_catasur_due_date'])?$jsondata['field_bf_catasur_due_date']:null;
    $field_bf_catasur_loggedin_userid = isset($jsondata['field_bf_catasur_loggedin_userid']) && !empty($jsondata['field_bf_catasur_loggedin_userid'])?$jsondata['field_bf_catasur_loggedin_userid']:null;
    $field_bf_catasur_pageno_range    = isset($jsondata['field_bf_catasur_pageno_range']) && !empty($jsondata['field_bf_catasur_pageno_range'])?$jsondata['field_bf_catasur_pageno_range']:null;
    $field_bf_catasur_assign_userrole = isset($jsondata['field_bf_catasur_assign_userrole']) && !empty($jsondata['field_bf_catasur_assign_userrole'])?$jsondata['field_bf_catasur_assign_userrole']:null;
    $node_type                        = 'bf_catalogue_assigning_user';
    //$node_title                     = 'BF Catalogue Assigning User';
    $userID                           = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
    //$userID = $this->GetBFDetailsByBFID($field_bf_catasur_briefingform_id);
    $BFNode     = Node::load($field_bf_catasur_briefingform_id);
    $nodeTitle  = $BFNode->field_briefing_catalogue_title->value;
    $catasur_due_date  = date('Y-m-d\TH:i:s', strtotime($field_bf_catasur_due_date));
    $getCatalogueWorkflow = $this->GetCatalogueWorkflowStatusDetailsByCatId($field_bf_catasur_catalogue_id);
    try{
      $BFCatAuCreatedData = array(
        'type'                              => $node_type,
        'title'                             => $nodeTitle,
        'field_bf_catasur_assigning_notes'  => $field_bf_catasur_assigning_notes,
        'field_bf_catasur_assigninguserid'  => $field_bf_catasur_assigninguserid,
        'field_bf_catasur_briefingform_id'  => $field_bf_catasur_briefingform_id,
        'field_bf_catasur_catalogue_id'     => $field_bf_catasur_catalogue_id,
        'field_bf_catasur_client_id'        => $field_bf_catasur_client_id,
        'field_bf_catasur_due_date'         => $catasur_due_date,
        'field_bf_catasur_loggedin_userid'  => $field_bf_catasur_loggedin_userid,
        'field_bf_catasur_pageno_range'     => $field_bf_catasur_pageno_range,
        'field_bf_catasur_assign_userrole'  => $field_bf_catasur_assign_userrole
      );
      // Inserting new node.
      $node = Node::create($BFCatAuCreatedData);
      $Save = $node->save();
      $saved_nid = $node->id();
      if($Save) {
        $BFCatAuCreatedData['bf_catasur_nid'] = $saved_nid;
        // Save the POST request in BF Catalogue Assigning User History content type.
        $jsondata = json_encode($BFCatAuCreatedData, TRUE);
        // Inserting new node in BF Catalogue Assigning User History.
        $BFCatAuHCreatedData = array(
          'type'                          => 'bf_cat_assigning_user_history',
          'title'                         => $nodeTitle,
          'field_bf_catasurhis_json'      => $jsondata,
          'field_bf_catasurhis_nid'       => $saved_nid,
          'field_bf_catasurhis_date_time' => REQUEST_TIME
        );
        $node1 = Node::create($BFCatAuHCreatedData);
        $Save1 = $node1->save();
        // Get last insert node id.
        $saved_nid1 = $node1->id();
        $BFCatAuHCreatedData['bf_catasurhis_nid'] = $saved_nid1;
        if(empty($saved_nid1)) {
          $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not saved successfully (Catalogue Assigning User History).'];
          return $result;
        }
        $pageNoArray = array();
        /**
        * Adding the new node in assigning the users page.
        */
        if(!empty($field_bf_catasur_pageno_range)) {
          $pagerange = explode('-', $field_bf_catasur_pageno_range);
          // Check the page number exploded array values.
          if($pagerange[0] == $pagerange[1]) {
           $page_number = $pagerange[0];
            $pageNoArray[] = $page_number;
            if(!empty($page_number) || ($page_number==0)) {
              // Check if the page number is already inserted or not with catalogue id, page assigning user node id.
              $checkPageNumberExists = $this->CheckAssignedPageNumberAlreadyExistsOrNot($page_number, $field_bf_catasur_catalogue_id, $field_bf_catasur_assign_userrole);
              if($checkPageNumberExists) {
                $catassnodeId = $checkPageNumberExists;
                $node = Node::load($catassnodeId);
                $node->set('field_bf_catau_page_date', $catasur_due_date);
                $node->set('field_bf_catau_page_status', 'catalogue_created');
                $node->set('field_bf_catau_page_userid', $field_bf_catasur_assigninguserid);
                $node->set('field_bf_catau_assigng_user_role', $field_bf_catasur_assign_userrole);
                $node->set('field_bf_catau_page_catalogue', $field_bf_catasur_catalogue_id);
                $node->set('field_bfcatalogue_assigning_user', $saved_nid);
                $node->set('field_bf_catau_page_number', $page_number);
                $updateCatAss = $node->save();
                if($updateCatAss) {
                  // Update data's to history.field_bf_pageno
                  $arrData = array(
                    "type"                              => "bf_cat_assigning_user_assignees",
                    "title"                             => $nodeTitle,
                    "field_bf_catau_page_catalogue"     => $field_bf_catasur_catalogue_id,
                    "field_bfcatalogue_assigning_user"  => $saved_nid,
                    "field_bf_catau_page_userid"        => $field_bf_catasur_assigninguserid,
                    "field_bf_catau_page_number"        => $page_number,
                    "field_bf_catau_page_date"          => $catasur_due_date,
                    "field_bf_catau_page_status"        => 'catalogue_created',
                    "field_bf_catau_assigng_user_role"  => $field_bf_catasur_assign_userrole
                  );
                  $BFCatApageArray[] = $arrData;
                  $encodedata = json_encode($arrData);
                  $node_data = array(
                    "type"                              => "bf_cat_assuser_assignees_history",
                    "title"                             => $nodeTitle,
                    'field_bf_cataupageassignee_date'   => REQUEST_TIME,
                    'field_bf_cataupageassignee_json'   => $encodedata,
                    'field_bf_cataupageassignee_nid'    => $catassnodeId,
                    'field_bf_cataupageassigne_status'  => 'catalogue_created',
                    'uid'                               => $field_bf_catasur_loggedin_userid
                  );
                  $node1 = Node::create($node_data);
                  $node1->save();
                }
              } else {
                $BFCatApage = array(
                  'type'                              => 'bf_cat_assigning_user_assignees',
                  'title'                             => $nodeTitle,
                  'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                  'field_bfcatalogue_assigning_user'  => $saved_nid,
                  'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                  'field_bf_catau_page_number'        => $page_number,
                  'field_bf_catau_page_date'          => $catasur_due_date,
                  'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole,
                  'field_bf_catau_page_status'        => 'catalogue_created'
                );
                // Save the POST request in BF Catalogue Assigning User Page Assignee's content type.
                $node2 = Node::create($BFCatApage);
                $Save2 = $node2->save();
                $saved2_nid = $node2->id();
                if($Save2) {
                  // Check the workflow status.
                  if(empty($getCatalogueWorkflow)) {
                    $datawf = array(
                      'field_briefingform_id'   => $field_bf_catasur_briefingform_id,
                      'field_catalogue_id'      => $field_bf_catasur_catalogue_id,
                      'field_workflow_from_sid' => 'catalogue_creation',
                      'field_workflow_to_sid'   => 'catalogue_assign',
                      'field_user_id'           => $field_bf_catasur_loggedin_userid
                    );
                   $insertWorkFlow = $this->InsertCatalogueWorkflowDetails($datawf);
                  }
                  $BFCatApageArray[] = $BFCatApage;
                  // Save the POST request in BF Catalogue Assigning User Page Assignee's History content type.
                  $jsonAssigneesHistoryData = json_encode($BFCatApage, TRUE);
                  // Inserting new node in BF Catalogue Assigning User Page Assignee's History.
                  $node3 = Node::create(array(
                    'type'                             => 'bf_cat_assuser_assignees_history',
                    'title'                            => $nodeTitle,
                    'field_bf_cataupageassignee_json'  => $jsonAssigneesHistoryData,
                    'field_bf_cataupageassignee_nid'   => $saved2_nid,
                    'field_bf_cataupageassignee_date'  => REQUEST_TIME,
                    'field_bf_cataupageassigne_status' => 'catalogue_created'
                  ));
                  $Save3 = $node3->save();
                  $saved_nid3 = $node3->id();
                  if(!$Save3) {
                    $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not saved successfully.'];    
                  }
                } else {
                  $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not saved successfully(Catalogue Assigning User Page Assignees).'];    
                }
              }
            }
          } else {
            for($i=$pagerange[0]; $i<=$pagerange[1]; $i++) {
              $page_number = $i;
              $pageNoArray[] = $page_number;
              // Check if the page number is already inserted or not with catalogue id, page assigning user node id.
              $checkPageNumberExists = $this->CheckAssignedPageNumberAlreadyExistsOrNot($page_number, $field_bf_catasur_catalogue_id,$field_bf_catasur_assign_userrole);
              if($checkPageNumberExists) {
                $catassnodeId = $checkPageNumberExists;
                $node = Node::load($catassnodeId);
                $node->set('field_bf_catau_page_date', $catasur_due_date);
                $node->set('field_bf_catau_page_status', 'catalogue_created');
                $node->set('field_bf_catau_page_userid', $field_bf_catasur_assigninguserid);
                $node->set('field_bf_catau_assigng_user_role', $field_bf_catasur_assign_userrole);
                $node->set('field_bf_catau_page_catalogue', $field_bf_catasur_catalogue_id);
                $node->set('field_bfcatalogue_assigning_user', $saved_nid);
                $node->set('field_bf_catau_page_number', $page_number);
                $updateCatAss = $node->save();
                if($updateCatAss) {
                  // Update data's to history.field_bf_pageno
                  $arrData = array(
                    "type"                              => "bf_cat_assigning_user_assignees",
                    "title"                             => $nodeTitle,
                    "field_bf_catau_page_catalogue"     => $field_bf_catasur_catalogue_id,
                    "field_bfcatalogue_assigning_user"  => $saved_nid,
                    "field_bf_catau_page_userid"        => $field_bf_catasur_assigninguserid,
                    "field_bf_catau_page_number"        => $page_number,
                    "field_bf_catau_page_date"          => $catasur_due_date,
                    "field_bf_catau_page_status"        => 'catalogue_created',
                    "field_bf_catau_assigng_user_role"  => $field_bf_catasur_assign_userrole
                  );
                  $BFCatApageArray[] = $arrData;
                  $encodedata = json_encode($arrData);
                  $node_data = array(
                    "type"                              => "bf_cat_assuser_assignees_history",
                    "title"                             => $nodeTitle,
                    'field_bf_cataupageassignee_date'   => REQUEST_TIME,
                    'field_bf_cataupageassignee_json'   => $encodedata,
                    'field_bf_cataupageassignee_nid'    => $catassnodeId,
                    'field_bf_cataupageassigne_status'  => 'catalogue_created',
                    'uid'                               => $field_bf_catasur_loggedin_userid
                  );
                  $node1 = Node::create($node_data);
                  $node1->save();
                }
              } else {
                $BFCatApage = array(
                  'type'                              => 'bf_cat_assigning_user_assignees',
                  'title'                             => $nodeTitle,
                  'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                  'field_bfcatalogue_assigning_user'  => $saved_nid,
                  'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                  'field_bf_catau_page_number'        => $page_number,
                  'field_bf_catau_page_date'          => $catasur_due_date,
                  'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole,
                  'field_bf_catau_page_status'        => 'catalogue_created'
                );
                // Save the POST request in BF Catalogue Assigning User Page Assignee's content type.
                $node2 = Node::create($BFCatApage);
                $Save2 = $node2->save();
                $saved2_nid = $node2->id();
                if($Save2) {
                  if(empty($getCatalogueWorkflow)) {
                    $datawf = array(
                      'field_briefingform_id'   => $field_bf_catasur_briefingform_id,
                      'field_catalogue_id'      => $field_bf_catasur_catalogue_id,
                      'field_workflow_from_sid' => 'catalogue_creation',
                      'field_workflow_to_sid'   => 'catalogue_assign',
                      'field_user_id'           => $field_bf_catasur_loggedin_userid
                    );
                   $insertWorkFlow = $this->InsertCatalogueWorkflowDetails($datawf);
                  }
                  $BFCatApageArray[] = $BFCatApage;
                  // Save the POST request in BF Catalogue Assigning User Page Assignee's History content type.
                  $jsonAssigneesHistoryData = json_encode($BFCatApage, TRUE);
                  // Inserting new node in BF Catalogue Assigning User Page Assignee's History.
                  $node3 = Node::create(array(
                    'type'                             => 'bf_cat_assuser_assignees_history',
                    'title'                            => $nodeTitle,
                    'field_bf_cataupageassignee_json'  => $jsonAssigneesHistoryData,
                    'field_bf_cataupageassignee_nid'   => $saved2_nid,
                    'field_bf_cataupageassignee_date'  => REQUEST_TIME,
                    'field_bf_cataupageassigne_status' => 'catalogue_created'
                  ));
                  $Save3 = $node3->save();
                  $saved_nid3 = $node3->id();
                  if(!$Save3) {
                    $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not saved successfully.'];    
                  }
                } else {
                  $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not saved successfully(Catalogue Assigning User Page Assignees).'];    
                }
              }
            }
          }
        }
        // Send mail to assignee for assigned page details.
        $sendMailToAssignee = $this->SendMailToAssigneeByParams($BFCatAuCreatedData, $pageNoArray, $field_bf_catasur_assign_userrole);
        $result = ['status' => 'success', 'status_message' => 'Catalogue assigning user details saved successfully.'];
        $BFCatAuCreatedData['bf_catau_page'] = $BFCatApageArray;
        $responseData = $BFCatAuCreatedData;
      } else {
        $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not saved successfully.'];
        $responseData = $jsondata;
      }
    } catch (Exception $e) {
      $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      $responseData = $jsondata;
    }
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'POST', $node_type, $responseData, $userID, $result);
    return $result;
  }

  /** 
  * Function :: 27 b) patch briefing form catalogue assigning user details.
  */
  public function PatchBFCatalogueAssigningUserDetails($jsondata) {

    $field_bf_catasur_node_id         = isset($jsondata['field_bf_catasur_node_id']) && !empty($jsondata['field_bf_catasur_node_id'])?$jsondata['field_bf_catasur_node_id']:null;
    $field_bf_catasur_assigning_notes = isset($jsondata['field_bf_catasur_assigning_notes']) && !empty($jsondata['field_bf_catasur_assigning_notes'])?$jsondata['field_bf_catasur_assigning_notes']:null;
    $field_bf_catasur_assigninguserid = isset($jsondata['field_bf_catasur_assigninguserid']) && !empty($jsondata['field_bf_catasur_assigninguserid'])?$jsondata['field_bf_catasur_assigninguserid']:null;
    $field_bf_catasur_briefingform_id = isset($jsondata['field_bf_catasur_briefingform_id']) && !empty($jsondata['field_bf_catasur_briefingform_id'])?$jsondata['field_bf_catasur_briefingform_id']:null;
    $field_bf_catasur_catalogue_id    = isset($jsondata['field_bf_catasur_catalogue_id']) && !empty($jsondata['field_bf_catasur_catalogue_id'])?$jsondata['field_bf_catasur_catalogue_id']:null;
    $field_bf_catasur_client_id       = isset($jsondata['field_bf_catasur_client_id']) && !empty($jsondata['field_bf_catasur_client_id'])?$jsondata['field_bf_catasur_client_id']:null;
    $field_bf_catasur_due_date        = isset($jsondata['field_bf_catasur_due_date']) && !empty($jsondata['field_bf_catasur_due_date'])?$jsondata['field_bf_catasur_due_date']:null;
    $field_bf_catasur_loggedin_userid = isset($jsondata['field_bf_catasur_loggedin_userid']) && !empty($jsondata['field_bf_catasur_loggedin_userid'])?$jsondata['field_bf_catasur_loggedin_userid']:null;
    $field_bf_catasur_pageno_range    = isset($jsondata['field_bf_catasur_pageno_range']) && !empty($jsondata['field_bf_catasur_pageno_range'])?$jsondata['field_bf_catasur_pageno_range']:null;
    $field_bf_catasur_assign_userrole = isset($jsondata['field_bf_catasur_assign_userrole']) && !empty($jsondata['field_bf_catasur_assign_userrole'])?$jsondata['field_bf_catasur_assign_userrole']:null;
    //$field_bf_catpage_assign        = isset($jsondata['field_bf_catpage_assign']) && !empty($jsondata['field_bf_catpage_assign'])?$jsondata['field_bf_catpage_assign']:null;
    $node_type                        = 'bf_catalogue_assigning_user';
    //$node_title                     = 'BF Catalogue Assigning User';
    $userID                           = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
    $catnode                          = Node::load($field_bf_catasur_briefingform_id);
    $nodeTitle                        = $catnode->field_briefing_catalogue_title->value;
    $jsondata['nodeTitle']            = $nodeTitle;
    $AssigningUserRole                = $field_bf_catasur_assign_userrole;
    $catasur_due_date                 = date('Y-m-d\TH:i:s', strtotime($field_bf_catasur_due_date));
    $pageNoArray                      = array();
    if($field_bf_catasur_node_id!=null) {
      // Load the node data of catalogue assign page details by using node id.
      $LoadNode = Node::load($field_bf_catasur_node_id);
      $Exists_pageRange       = $LoadNode->field_bf_catasur_pageno_range->value;
      $Exists_catalogueId     = $LoadNode->field_bf_catasur_catalogue_id->target_id;
      $Exists_assigning_notes = $LoadNode->field_bf_catasur_assigning_notes->value;

      // Get existing - page range value in array format.
      $GetExistsPageRangeArray = $this->GetCatAssignPageArray($Exists_pageRange);
      // Get patch - page range value in array format.
      $GetGivenPageRange  = $this->GetCatAssignPageArray($field_bf_catasur_pageno_range);
      // Check the new page range and existing page range is not equal to same.
      if($field_bf_catasur_pageno_range != $Exists_pageRange) {

        // Update catalogue assigning user content ["Briefing Form Catalogue Assigning User"].
        $updateCatAssignUser = $this->UpdateBFCatalogueAssigningUser($LoadNode, $jsondata);
        if(isset($updateCatAssignUser['status'])) {
          // Return error response.
          return $updateCatAssignUser;
        } else {
          // Insert the new record in content ["BF Catalogue Assigning User History"].
          $InsertCatAssignUserHistory = $this->InsertCatAssignUserHistory($jsondata);
          if(isset($InsertCatAssignUserHistory['status'])) {
            // Return error response.
            return $InsertCatAssignUserHistory;
          }
          // Check the page range is numeric or not.
          if(is_numeric($field_bf_catasur_pageno_range)) {
            $page_number    = $field_bf_catasur_pageno_range;
            $pageNoArray[]  = $page_number;
            // Get the catalogue page assigned details by ctalogue id and page number.
            $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '0');
            // Check the result set is empty or not.
            if(!empty($getpagedetails)) {
              // Get page status.
              $getpagestatus  = $getpagedetails['page_status'];
              // Get page user id.
              $getpageuserId  = $getpagedetails['page_userid'];
              // Get page due date.
              $getPageDate    = isset($getpagedetails['page_date']) && $getpagedetails['page_date']!='0000-00-00' && $getpagedetails['page_date']!=null?$getpagedetails['page_date']:'0000-00-00';

              if($getpageuserId == $field_bf_catasur_assigninguserid) {
                // Patch user id and existing user id is same.
                // Check the page status is in in-progress or completed.
                if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                  /**
                  * Return response - This page is already assigned to the users and the page status is in-progress or completed.
                  **/
                  $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to the users and page status is '.$getpagestatus.'.'];
                  return $responseData;
                } else {
                  // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                  $updatePageDetails = array(
                    'node_id'                           => $getpagedetails['page_node_id'],
                    'field_bf_catau_page_status'        => $getpagestatus,
                    'field_bf_catau_page_date'          => $catasur_due_date,
                    'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                    'field_bf_catau_page_number'        => $page_number,
                    'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                    'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                    'field_bf_catasur_assign_userrole'  => $field_bf_catasur_assign_userrole
                  );
                  $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                  if(isset($updatePageDet['status'])) {
                    // Return error response.
                    return $updatePageDet;
                  } else {
                    // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                    $InsertPageHistoryDetails = array(
                      'type'                              => 'bf_cat_assigning_user_assignees',
                      'title'                             => $nodeTitle,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_status'        => $getpagestatus,
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                    if(isset($InsertPageHistory['status'])) {
                      // Return error response.
                      return $InsertPageHistory;
                    }
                    // Send mail to assignee for assigned page details.
                    $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                    // Return success message
                    $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                    return $responseData;
                  }
                }
              } else {
                // Patch user id and existing user id is different.
                // Check the page status is in in-progress or completed.
                if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                  /**
                  * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                  **/
                  $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to some other users and page status is '.$getpagestatus.'.'];
                  return $responseData;
                } else {
                  // update the page details and insert new record in history content.
                  // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                  $updatePageDetails = array(
                    'node_id'                           => $getpagedetails['page_node_id'],
                    'field_bf_catau_page_status'        => $getpagestatus,
                    'field_bf_catau_page_date'          => $catasur_due_date,
                    'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                    'field_bf_catau_page_number'        => $page_number,
                    'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                    'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                    'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                  );
                  $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                  if(isset($updatePageDet['status'])) {
                    // Return error response.
                    return $updatePageDet;
                  } else {
                    // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                    $InsertPageHistoryDetails = array(
                      'type'                              => 'bf_cat_assigning_user_assignees',
                      'title'                             => $nodeTitle,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_status'        => $getpagestatus,
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                    if(isset($InsertPageHistory['status'])) {
                      // Return error response.
                      return $InsertPageHistory;
                    }
                    // Send mail to assignee for assigned page details.
                    $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                    // Return success message
                    $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                    return $responseData;
                  }
                }
              }
            } else {
              // Get the catalogue page assigned details by ctalogue id and page number.
              $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
              if(!empty($getpagedetails)) {
                // Get page status.
                $getpagestatus = $getpagedetails['page_status'];
                // Check the patch assign user id with result assigned user id.
                if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                  // Checking the page status.
                  if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                    /**
                    * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                    **/
                    $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                    return $responseData;
                  } else {
                    /* 
                    * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                    */
                    try {
                      $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                      $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                      $updatepage = $pageUpdateNode->save();
                      if($updatepage) {
                        // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                        $InsertPageHistoryDetails = array(
                          'type'                              => 'bf_cat_assigning_user_assignees',
                          'title'                             => $nodeTitle,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                        if(isset($InsertPageHistory['status'])) {
                          // Return error response.
                          return $InsertPageHistory;
                        }
                      }
                    } catch (Exception $e) {
                      $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                      return $responseData;
                    }
                    // Send mail to assignee for assigned page details.
                    $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                    // Return success message
                    $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                    return $responseData;
                  }
                } else {
                  // Checking the page status.
                  if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                    /**
                    * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                    **/
                    $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                    return $responseData;
                  } else {
                    /* 
                    * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                    * result page assign user id to patch page assign user id.
                    */
                    try {
                      $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                      $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                      $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                      $updatepage = $pageUpdateNode->save();
                      if($updatepage) {
                        // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                        $InsertPageHistoryDetails = array(
                          'type'                              => 'bf_cat_assigning_user_assignees',
                          'title'                             => $nodeTitle,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                        if(isset($InsertPageHistory['status'])) {
                          // Return error response.
                          return $InsertPageHistory;
                        }
                      }
                    } catch (Exception $e) {
                      $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                      return $responseData;
                    }
                    // Send mail to assignee for assigned page details.
                    $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                    // Return success message
                    $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                    return $responseData;
                  }
                }
              } else {
                // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                $data = array(
                  'type'                              => 'bf_cat_assigning_user_assignees',
                  'title'                             => $nodeTitle,
                  'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                  'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                  'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                  'field_bf_catau_page_number'        => $page_number,
                  'field_bf_catau_page_date'          => $catasur_due_date,
                  'field_bf_catau_page_status'        => 'catalogue_created',
                  'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                );
                $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                if(isset($InsertPageDetails['status'])) {
                  // Return error response.
                  return $InsertPageDetails;
                }
                // Send mail to assignee for assigned page details.
                $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                // Return success message
                $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                return $responseData;
              }
            }
          } else {
            // Check the given page range is using hyphen
            $pageRangeHyphen = explode('-', $field_bf_catasur_pageno_range);
            // Assign existing page number to array variable.
            $existpagearray = $GetExistsPageRangeArray;
            // Check page range array values are same.
            if(!empty($pageRangeHyphen) && ($pageRangeHyphen[0] == $pageRangeHyphen[1]) || ($pageRangeHyphen[0]==0)) {
              $page_number = $pageRangeHyphen[0];
              $pageNoArray[] = $page_number;
              //$NewPageNumber[] = $page_number;
              if (in_array($page_number, $GetExistsPageRangeArray)) {
                // Get the catalogue page assigned details by ctalogue id and page number.
                $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '0');
                // Check the result set is empty or not.
                if(!empty($getpagedetails)) {
                  // Get page status.
                  $getpagestatus  = $getpagedetails['page_status'];
                  // Get page user id.
                  $getpageuserId  = $getpagedetails['page_userid'];
                  // Get page due date.
                  $getPageDate    = isset($getpagedetails['page_date']) && $getpagedetails['page_date']!='0000-00-00' && $getpagedetails['page_date']!=null?$getpagedetails['page_date']:'0000-00-00';
                  if($getpageuserId == $field_bf_catasur_assigninguserid) {
                    // Patch user id and existing user id is same.
                    // Check the page status is in in-progress or completed.
                    if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                      /**
                      * Return response - This page is already assigned to the users and the page status is in-progress or completed.
                      **/
                      $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to the users and page status is '.$getpagestatus.'.'];
                      return $responseData;
                    } else {
                      // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                      $updatePageDetails = array(
                        'node_id'                           => $getpagedetails['page_node_id'],
                        'field_bf_catau_page_status'        => $getpagestatus,
                        'field_bf_catau_page_date'          => $catasur_due_date,
                        'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                        'field_bf_catau_page_number'        => $page_number,
                        'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                        'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                        'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                      );
                      $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                      if(isset($updatePageDet['status'])) {
                        // Return error response.
                        return $updatePageDet;
                      } else {
                        // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                        $InsertPageHistoryDetails = array(
                          'type'                              => 'bf_cat_assigning_user_assignees',
                          'title'                             => $nodeTitle,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_status'        => $getpagestatus,
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                        if(isset($InsertPageHistory['status'])) {
                          // Return error response.
                          return $InsertPageHistory;
                        }
                      }
                    }
                  } else {
                    // Patch user id and existing user id is different.
                    // Check the page status is in in-progress or completed.
                    if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                      /**
                      * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                      **/
                      $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to some other users and page status is '.$getpagestatus.'.'];
                      return $responseData;
                    } else {
                      // update the page details and insert new record in history content.
                      // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                      $updatePageDetails = array(
                        'node_id'                           => $getpagedetails['page_node_id'],
                        'field_bf_catau_page_status'        => $getpagestatus,
                        'field_bf_catau_page_date'          => $catasur_due_date,
                        'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                        'field_bf_catau_page_number'        => $page_number,
                        'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                        'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                        'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                      );
                      $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                      if(isset($updatePageDet['status'])) {
                        // Return error response.
                        return $updatePageDet;
                      } else {
                        // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                        $InsertPageHistoryDetails = array(
                          'type'                              => 'bf_cat_assigning_user_assignees',
                          'title'                             => $nodeTitle,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_status'        => $getpagestatus,
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                        if(isset($InsertPageHistory['status'])) {
                          // Return error response.
                          return $InsertPageHistory;
                        }
                      }
                    }
                  }
                } else {
                  // Get the catalogue page assigned details by ctalogue id and page number.
                  $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
                  if(!empty($getpagedetails)) {
                    // Get page status.
                    $getpagestatus = $getpagedetails['page_status'];
                    // Check the patch assign user id with result assigned user id.
                    if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                      // Checking the page status.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        /* 
                        * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                        */
                        try {
                          $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                          $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                          $updatepage = $pageUpdateNode->save();
                          if($updatepage) {
                            // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                            $InsertPageHistoryDetails = array(
                              'type'                              => 'bf_cat_assigning_user_assignees',
                              'title'                             => $nodeTitle,
                              'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                              'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                              'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                              'field_bf_catau_page_number'        => $page_number,
                              'field_bf_catau_page_date'          => $catasur_due_date,
                              'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                              'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                            );
                            $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                            if(isset($InsertPageHistory['status'])) {
                              // Return error response.
                              return $InsertPageHistory;
                            }
                          }
                        } catch (Exception $e) {
                          $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                          return $responseData;
                        }
                      }
                    } else {
                      // Checking the page status.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        /* 
                        * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                        * result page assign user id to patch page assign user id.
                        */
                        try {
                          $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                          $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                          $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                          $updatepage = $pageUpdateNode->save();
                          if($updatepage) {
                            // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                            $InsertPageHistoryDetails = array(
                              'type'                              => 'bf_cat_assigning_user_assignees',
                              'title'                             => $nodeTitle,
                              'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                              'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                              'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                              'field_bf_catau_page_number'        => $page_number,
                              'field_bf_catau_page_date'          => $catasur_due_date,
                              'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                              'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                            );
                            $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                            if(isset($InsertPageHistory['status'])) {
                              // Return error response.
                              return $InsertPageHistory;
                            }
                          }
                        } catch (Exception $e) {
                          $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                          return $responseData;
                        }
                      }
                    }
                  } else {
                    // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                    $data = array(
                      'type'                              => 'bf_cat_assigning_user_assignees',
                      'title'                             => $nodeTitle,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_status'        => 'catalogue_yet_to_start',
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                    if(isset($InsertPageDetails['status'])) {
                      // Return error response.
                      return $InsertPageDetails;
                    }
                  }
                }
                // Unset the looped array value.
                if (($key = array_search($page_number, $existpagearray)) !== false) {
                  unset($existpagearray[$key]);
                }
              } else {
                // Get the catalogue page assigned details by ctalogue id and page number.
                $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
                if(!empty($getpagedetails)) {
                  // Get page status.
                  $getpagestatus = $getpagedetails['page_status'];
                  // Check the patch assign user id with result assigned user id.
                  if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                    // Checking the page status.
                    if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                      /**
                      * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                      **/
                      $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                      return $responseData;
                    } else {
                      /* 
                      * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                      */
                      try {
                        $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                        $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                        $updatepage = $pageUpdateNode->save();
                        if($updatepage) {
                          // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                          $InsertPageHistoryDetails = array(
                            'type'                              => 'bf_cat_assigning_user_assignees',
                            'title'                             => $nodeTitle,
                            'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                            'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                            'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                            'field_bf_catau_page_number'        => $page_number,
                            'field_bf_catau_page_date'          => $catasur_due_date,
                            'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                            'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                          );
                          $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                          if(isset($InsertPageHistory['status'])) {
                            // Return error response.
                            return $InsertPageHistory;
                          }
                        }
                      } catch (Exception $e) {
                        $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                        return $responseData;
                      }
                    }
                  } else {
                    // Checking the page status.
                    if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                      /**
                      * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                      **/
                      $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                      return $responseData;
                    } else {
                      /* 
                      * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                      * result page assign user id to patch page assign user id.
                      */
                      try {
                        $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                        $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                        $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                        $updatepage = $pageUpdateNode->save();
                        if($updatepage) {
                          // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                          $InsertPageHistoryDetails = array(
                            'type'                              => 'bf_cat_assigning_user_assignees',
                            'title'                             => $nodeTitle,
                            'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                            'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                            'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                            'field_bf_catau_page_number'        => $page_number,
                            'field_bf_catau_page_date'          => $catasur_due_date,
                            'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                            'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                          );
                          $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                          if(isset($InsertPageHistory['status'])) {
                            // Return error response.
                            return $InsertPageHistory;
                          }
                        }
                      } catch (Exception $e) {
                        $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                        return $responseData;
                      }
                    }
                  }
                } else {
                  // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                  $data = array(
                    'type'                              => 'bf_cat_assigning_user_assignees',
                    'title'                             => $nodeTitle,
                    'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                    'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                    'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                    'field_bf_catau_page_number'        => $page_number,
                    'field_bf_catau_page_date'          => $catasur_due_date,
                    'field_bf_catau_page_status'        => 'catalogue_created',
                    'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                  );
                  $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                  if(isset($InsertPageDetails['status'])) {
                    // Return error response.
                    return $InsertPageDetails;
                  }
                }
              }
            } else {
              // Execute the loop for page number.
              for($i=$pageRangeHyphen[0]; $i<=$pageRangeHyphen[1]; $i++) {
                $page_number = $i;
                $pageNoArray[] = $page_number;
                //$NewPageNumber[] = $page_number;
                if (in_array($page_number, $GetExistsPageRangeArray)) {
                  // Get the catalogue page assigned details by ctalogue id and page number.
                  $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '0');
                  // Check the result set is empty or not.
                  if(!empty($getpagedetails)) {
                    // Get page status.
                    $getpagestatus  = $getpagedetails['page_status'];
                    // Get page user id.
                    $getpageuserId  = $getpagedetails['page_userid'];
                    // Get page due date.
                    $getPageDate    = isset($getpagedetails['page_date']) && $getpagedetails['page_date']!='0000-00-00' && $getpagedetails['page_date']!=null?$getpagedetails['page_date']:'0000-00-00';
                    if($getpageuserId == $field_bf_catasur_assigninguserid) {
                      // Patch user id and existing user id is same.
                      // Check the page status is in in-progress or completed.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to the users and the page status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to the users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                        $updatePageDetails = array(
                          'node_id'                           => $getpagedetails['page_node_id'],
                          'field_bf_catau_page_status'        => $getpagestatus,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                        if(isset($updatePageDet['status'])) {
                          // Return error response.
                          return $updatePageDet;
                        } else {
                          // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                          $InsertPageHistoryDetails = array(
                            'type'                              => 'bf_cat_assigning_user_assignees',
                            'title'                             => $nodeTitle,
                            'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                            'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                            'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                            'field_bf_catau_page_number'        => $page_number,
                            'field_bf_catau_page_date'          => $catasur_due_date,
                            'field_bf_catau_page_status'        => $getpagestatus,
                            'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                          );
                          $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                          if(isset($InsertPageHistory['status'])) {
                            // Return error response.
                            return $InsertPageHistory;
                          }
                        }
                      }
                    } else {
                      // Patch user id and existing user id is different.
                      // Check the page status is in in-progress or completed.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to some other users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        // update the page details and insert new record in history content.
                        // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                        $updatePageDetails = array(
                          'node_id'                           => $getpagedetails['page_node_id'],
                          'field_bf_catau_page_status'        => $getpagestatus,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                        if(isset($updatePageDet['status'])) {
                          // Return error response.
                          return $updatePageDet;
                        } else {
                          // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                          $InsertPageHistoryDetails = array(
                            'type'                              => 'bf_cat_assigning_user_assignees',
                            'title'                             => $nodeTitle,
                            'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                            'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                            'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                            'field_bf_catau_page_number'        => $page_number,
                            'field_bf_catau_page_date'          => $catasur_due_date,
                            'field_bf_catau_page_status'        => $getpagestatus,
                            'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                          );
                          $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                          if(isset($InsertPageHistory['status'])) {
                            // Return error response.
                            return $InsertPageHistory;
                          }
                        }
                      }
                    }
                  } else {
                    // Get the catalogue page assigned details by ctalogue id and page number.
                    $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
                    if(!empty($getpagedetails)) {
                      // Get page status.
                      $getpagestatus = $getpagedetails['page_status'];
                      // Check the patch assign user id with result assigned user id.
                      if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                        // Checking the page status.
                        if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                          /**
                          * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                          **/
                          $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                          return $responseData;
                        } else {
                          /* 
                          * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                          */
                          try {
                            $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                            $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                            $updatepage = $pageUpdateNode->save();
                            if($updatepage) {
                              // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                              $InsertPageHistoryDetails = array(
                                'type'                              => 'bf_cat_assigning_user_assignees',
                                'title'                             => $nodeTitle,
                                'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                                'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                                'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                                'field_bf_catau_page_number'        => $page_number,
                                'field_bf_catau_page_date'          => $catasur_due_date,
                                'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                                'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                              );
                              $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                              if(isset($InsertPageHistory['status'])) {
                                // Return error response.
                                return $InsertPageHistory;
                              }
                            }
                          } catch (Exception $e) {
                            $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                            return $responseData;
                          }
                        }
                      } else {
                        // Checking the page status.
                        if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                          /**
                          * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                          **/
                          $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                          return $responseData;
                        } else {
                          /* 
                          * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                          * result page assign user id to patch page assign user id.
                          */
                          try {
                            $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                            $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                            $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                            $updatepage = $pageUpdateNode->save();
                            if($updatepage) {
                              // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                              $InsertPageHistoryDetails = array(
                                'type'                              => 'bf_cat_assigning_user_assignees',
                                'title'                             => $nodeTitle,
                                'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                                'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                                'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                                'field_bf_catau_page_number'        => $page_number,
                                'field_bf_catau_page_date'          => $catasur_due_date,
                                'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                                'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                              );
                              $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                              if(isset($InsertPageHistory['status'])) {
                                // Return error response.
                                return $InsertPageHistory;
                              }
                            }
                          } catch (Exception $e) {
                            $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                            return $responseData;
                          }
                        }
                      }
                    } else {
                      // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                      $data = array(
                        'type'                              => 'bf_cat_assigning_user_assignees',
                        'title'                             => $nodeTitle,
                        'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                        'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                        'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                        'field_bf_catau_page_number'        => $page_number,
                        'field_bf_catau_page_date'          => $catasur_due_date,
                        'field_bf_catau_page_status'        => 'catalogue_yet_to_start',
                        'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                      );
                      $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                      if(isset($InsertPageDetails['status'])) {
                        // Return error response.
                        return $InsertPageDetails;
                      }
                    }
                  }
                  // Unset the looped array value.
                  if (($key = array_search($page_number, $existpagearray)) !== false) {
                    unset($existpagearray[$key]);
                  }
                } else {
                  // Get the catalogue page assigned details by ctalogue id and page number.
                  $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
                  if(!empty($getpagedetails)) {
                    // Get page status.
                    $getpagestatus = $getpagedetails['page_status'];
                    // Check the patch assign user id with result assigned user id.
                    if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                      // Checking the page status.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        /* 
                        * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                        */
                        try {
                          $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                          $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                          $updatepage = $pageUpdateNode->save();
                          if($updatepage) {
                            // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                            $InsertPageHistoryDetails = array(
                              'type'                              => 'bf_cat_assigning_user_assignees',
                              'title'                             => $nodeTitle,
                              'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                              'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                              'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                              'field_bf_catau_page_number'        => $page_number,
                              'field_bf_catau_page_date'          => $catasur_due_date,
                              'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                              'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                            );
                            $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                            if(isset($InsertPageHistory['status'])) {
                              // Return error response.
                              return $InsertPageHistory;
                            }
                          }
                        } catch (Exception $e) {
                          $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                          return $responseData;
                        }
                      }
                    } else {
                      // Checking the page status.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        /* 
                        * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                        * result page assign user id to patch page assign user id.
                        */
                        try {
                          $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                          $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                          $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                          $updatepage = $pageUpdateNode->save();
                          if($updatepage) {
                            // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                            $InsertPageHistoryDetails = array(
                              'type'                              => 'bf_cat_assigning_user_assignees',
                              'title'                             => $nodeTitle,
                              'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                              'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                              'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                              'field_bf_catau_page_number'        => $page_number,
                              'field_bf_catau_page_date'          => $catasur_due_date,
                              'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                              'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                            );
                            $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                            if(isset($InsertPageHistory['status'])) {
                              // Return error response.
                              return $InsertPageHistory;
                            }
                          }
                        } catch (Exception $e) {
                          $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                          return $responseData;
                        }
                      }
                    }
                  } else {
                    // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                    $data = array(
                      'type'                              => 'bf_cat_assigning_user_assignees',
                      'title'                             => $nodeTitle,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_status'        => 'catalogue_created',
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                    if(isset($InsertPageDetails['status'])) {
                      // Return error response.
                      return $InsertPageDetails;
                    }
                  }
                }
              }
            }
            if(!empty($existpagearray)) {
              foreach($existpagearray as $ex_pagenumber) {
                // Get the catalogue page assigned details by ctalogue id and page number.
                $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $ex_pagenumber, $AssigningUserRole, $check = '0');
                if(!empty($getpagedetails)) {
                  // Delete the not in array record except in-progress and completed status.
                  // Get page status.
                  $getpagestatus = $getpagedetails['page_status'];
                  // Checking the page status.
                  if(isset($getpagestatus) && !empty($getpagedetails['page_node_id']) && ($getpagestatus != 'catalogue_assign' || $getpagestatus != 'catalogue_start_job' || $getpagestatus != 'catalogue_completed' || $getpagestatus != 'catalogue_pause_job' || $getpagestatus != 'catalogue_stop_job' || $getpagestatus != 'catalogue_clipping')) {
                    $node = \Drupal::entityTypeManager()->getStorage('node')->load($getpagedetails['page_node_id']);
                    // Check if node exists with the given nid.
                    if ($node) {
                      $node->delete();
                    }
                  }
                }
              }
            }
            // Send mail to assignee for assigned page details.
            $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
            // Return success message
            $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
            return $responseData;
          }
        }
      } else {
        // Update catalogue assigning user content ["Briefing Form Catalogue Assigning User"].
        $updateCatAssignUser = $this->UpdateBFCatalogueAssigningUser($LoadNode, $jsondata);
        if(isset($updateCatAssignUser['status'])) {
          // Return error response.
          return $updateCatAssignUser;
        } else { 
          /*******************************************************/
          /** Patch page range is equal to existing page range. **/
          /*******************************************************/
          // Check the page range is numeric or not.
          if(is_numeric($field_bf_catasur_pageno_range)) {
            $page_number = $field_bf_catasur_pageno_range;
            $pageNoArray[] = $page_number;
            // Get the catalogue page assigned details by ctalogue id and page number.
            $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '0');
            // Check the result set is empty or not.
            if(!empty($getpagedetails)) {
              // Get page status.
              $getpagestatus  = $getpagedetails['page_status'];
              // Get page user id.
              $getpageuserId  = $getpagedetails['page_userid'];
              // Get page due date.
              $getPageDate    = isset($getpagedetails['page_date']) && $getpagedetails['page_date']!='0000-00-00' && $getpagedetails['page_date']!=null?$getpagedetails['page_date']:'0000-00-00';

              if($getpageuserId == $field_bf_catasur_assigninguserid) {
                // Patch user id and existing user id is same.
                // Check the page status is in in-progress or completed.
                if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                  /**
                  * Return response - This page is already assigned to the users and the page status is in-progress or completed.
                  **/
                  $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to the users and page status is '.$getpagestatus.'.'];
                  return $responseData;
                } else {

                  // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                  $updatePageDetails = array(
                    'node_id'                           => $getpagedetails['page_node_id'],
                    'field_bf_catau_page_status'        => $getpagestatus,
                    'field_bf_catau_page_date'          => $catasur_due_date,
                    'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                    'field_bf_catau_page_number'        => $page_number,
                    'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                    'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                    'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                  );
                  $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                  if(isset($updatePageDet['status'])) {
                    // Return error response.
                    return $updatePageDet;
                  } else {
                    // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                    $InsertPageHistoryDetails = array(
                      'type'                              => 'bf_cat_assigning_user_assignees',
                      'title'                             => $nodeTitle,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_status'        => $getpagestatus,
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                    if(isset($InsertPageHistory['status'])) {
                      // Return error response.
                      return $InsertPageHistory;
                    }
                    // Send mail to assignee for assigned page details.
                    $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                    // Return success message
                    $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                    return $responseData;
                  }
                }
              } else {
                // Patch user id and existing user id is different.
                // Check the page status is in in-progress or completed.
                if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                  /**
                  * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                  **/
                  $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to some other users and page status is '.$getpagestatus.'.'];
                  return $responseData;
                } else {
                  // update the page details and insert new record in history content.
                  // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                  $updatePageDetails = array(
                    'node_id'                           => $getpagedetails['page_node_id'],
                    'field_bf_catau_page_status'        => $getpagestatus,
                    'field_bf_catau_page_date'          => $catasur_due_date,
                    'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                    'field_bf_catau_page_number'        => $page_number,
                    'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                    'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                    'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                  );
                  $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                  if(isset($updatePageDet['status'])) {
                    // Return error response.
                    return $updatePageDet;
                  } else {
                    // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                    $InsertPageHistoryDetails = array(
                      'type'                              => 'bf_cat_assigning_user_assignees',
                      'title'                             => $nodeTitle,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_status'        => $getpagestatus,
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                    if(isset($InsertPageHistory['status'])) {
                      // Return error response.
                      return $InsertPageHistory;
                    }
                    // Send mail to assignee for assigned page details.
                    $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                    // Return success message
                    $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                    return $responseData;
                  }
                }
              }
            } else {
              // Get the catalogue page assigned details by ctalogue id and page number.
              $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
              if(!empty($getpagedetails)) {
                // Get page status.
                $getpagestatus = $getpagedetails['page_status'];
                // Check the patch assign user id with result assigned user id.
                if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                  // Checking the page status.
                  if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                    /**
                    * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                    **/
                    $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                    return $responseData;
                  } else {
                    /* 
                    * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                    */
                    try {
                      $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                      $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                      $updatepage = $pageUpdateNode->save();
                      if($updatepage) {
                        // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                        $InsertPageHistoryDetails = array(
                          'type'                              => 'bf_cat_assigning_user_assignees',
                          'title'                             => $nodeTitle,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                        if(isset($InsertPageHistory['status'])) {
                          // Return error response.
                          return $InsertPageHistory;
                        }
                      }
                    } catch (Exception $e) {
                      $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                      return $responseData;
                    }
                    // Send mail to assignee for assigned page details.
                    $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                    // Return success message
                    $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                    return $responseData;
                  }
                } else {
                  // Checking the page status.
                  if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                    /**
                    * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                    **/
                    $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                    return $responseData;
                  } else {
                    /* 
                    * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                    * result page assign user id to patch page assign user id.
                    */
                    try {
                      $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                      $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                      $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                      $updatepage = $pageUpdateNode->save();
                      if($updatepage) {
                        // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                        $InsertPageHistoryDetails = array(
                          'type'                              => 'bf_cat_assigning_user_assignees',
                          'title'                             => $nodeTitle,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                        if(isset($InsertPageHistory['status'])) {
                          // Return error response.
                          return $InsertPageHistory;
                        }
                      }
                    } catch (Exception $e) {
                      $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                      return $responseData;
                    }
                    // Send mail to assignee for assigned page details.
                    $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                    // Return success message
                    $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                    return $responseData;
                  }
                }
              } else {
                // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                $data = array(
                  'type'                              => 'bf_cat_assigning_user_assignees',
                  'title'                             => $nodeTitle,
                  'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                  'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                  'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                  'field_bf_catau_page_number'        => $page_number,
                  'field_bf_catau_page_date'          => $catasur_due_date,
                  'field_bf_catau_page_status'        => 'catalogue_created',
                  'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                );
                $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                if(isset($InsertPageDetails['status'])) {
                  // Return error response.
                  return $InsertPageDetails;
                }
                // Return success message
                $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                return $responseData;
              }
            }
          } else {
            // Check the given page range is using hyphen
            $pageRangeHyphen = explode('-', $field_bf_catasur_pageno_range);
            // Assign existing page number to array variable.
            $existpagearray = $GetExistsPageRangeArray;
            // Check the given page range bot are equal.
            if(!empty($pageRangeHyphen) && ($pageRangeHyphen[0] == $pageRangeHyphen[1])) {
              $page_number = $pageRangeHyphen[0];
              $pageNoArray[] = $page_number;
              // Get the catalogue page assigned details by ctalogue id and page number.
              $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '0');
              // Check the result set is empty or not.
              if(!empty($getpagedetails)) {
                // Get page status.
                $getpagestatus  = $getpagedetails['page_status'];
                // Get page user id.
                $getpageuserId  = $getpagedetails['page_userid'];
                // Get page due date.
                $getPageDate    = isset($getpagedetails['page_date']) && $getpagedetails['page_date']!='0000-00-00' && $getpagedetails['page_date']!=null?$getpagedetails['page_date']:'0000-00-00';

                if($getpageuserId == $field_bf_catasur_assigninguserid) {
                  // Patch user id and existing user id is same.
                  // Check the page status is in in-progress or completed.
                  if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                    /**
                    * Return response - This page is already assigned to the users and the page status is in-progress or completed.
                    **/
                    $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to the users and page status is '.$getpagestatus.'.'];
                    return $responseData;
                  } else {
                    // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                    $updatePageDetails = array(
                      'node_id'                           => $getpagedetails['page_node_id'],
                      'field_bf_catau_page_status'        => $getpagestatus,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                    if(isset($updatePageDet['status'])) {
                      // Return error response.
                      return $updatePageDet;
                    } else {
                      // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                      $InsertPageHistoryDetails = array(
                        'type'                              => 'bf_cat_assigning_user_assignees',
                        'title'                             => $nodeTitle,
                        'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                        'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                        'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                        'field_bf_catau_page_number'        => $page_number,
                        'field_bf_catau_page_date'          => $catasur_due_date,
                        'field_bf_catau_page_status'        => $getpagestatus,
                        'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                      );
                      $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                      if(isset($InsertPageHistory['status'])) {
                        // Return error response.
                        return $InsertPageHistory;
                      }
                      // Send mail to assignee for assigned page details.
                      $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                      // Return success message
                      $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                      return $responseData;
                    }
                  }
                } else {
                  // Patch user id and existing user id is different.
                  // Check the page status is in in-progress or completed.
                  if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                    /**
                    * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                    **/
                    $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to some other users and page status is '.$getpagestatus.'.'];
                    return $responseData;
                  } else {
                    // update the page details and insert new record in history content.
                    // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                    $updatePageDetails = array(
                      'node_id'                           => $getpagedetails['page_node_id'],
                      'field_bf_catau_page_status'        => $getpagestatus,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                    if(isset($updatePageDet['status'])) {
                      // Return error response.
                      return $updatePageDet;
                    } else {
                      // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                      $InsertPageHistoryDetails = array(
                      'type'                              => 'bf_cat_assigning_user_assignees',
                      'title'                             => $nodeTitle,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_status'        => $getpagestatus,
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                      );
                      $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                      if(isset($InsertPageHistory['status'])) {
                        // Return error response.
                        return $InsertPageHistory;
                      }
                      // Send mail to assignee for assigned page details.
                      $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                      // Return success message
                      $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                      return $responseData;
                    }
                  }
                }
              } else {
                // Get the catalogue page assigned details by ctalogue id and page number.
                $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
                if(!empty($getpagedetails)) {
                  // Get page status.
                  $getpagestatus = $getpagedetails['page_status'];
                  // Check the patch assign user id with result assigned user id.
                  if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                    // Checking the page status.
                    if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                      /**
                      * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                      **/
                      $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                      return $responseData;
                    } else {
                      /* 
                      * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                      */
                      try {
                        $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                        $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                        $updatepage = $pageUpdateNode->save();
                        if($updatepage) {
                          // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                          $InsertPageHistoryDetails = array(
                          'type'                              => 'bf_cat_assigning_user_assignees',
                          'title'                             => $nodeTitle,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                          );
                          $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                          if(isset($InsertPageHistory['status'])) {
                          // Return error response.
                          return $InsertPageHistory;
                          }
                        }
                      } catch (Exception $e) {
                        $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                        return $responseData;
                      }
                      // Send mail to assignee for assigned page details.
                      $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                      // Return success message
                      $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                      return $responseData;
                    }
                  } else {
                    // Checking the page status.
                    if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                      /**
                      * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                      **/
                      $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                      return $responseData;
                    } else {
                      /* 
                      * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                      * result page assign user id to patch page assign user id.
                      */
                      try {
                        $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                        $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                        $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                        $updatepage = $pageUpdateNode->save();
                        if($updatepage) {
                          // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                          $InsertPageHistoryDetails = array(
                          'type'                              => 'bf_cat_assigning_user_assignees',
                          'title'                             => $nodeTitle,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                          );
                          $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                          if(isset($InsertPageHistory['status'])) {
                            // Return error response.
                            return $InsertPageHistory;
                          }
                        }
                      } catch (Exception $e) {
                        $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                        return $responseData;
                      }
                      // Send mail to assignee for assigned page details.
                      $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                      // Return success message
                      $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                      return $responseData;
                    }
                  }
                } else {
                  // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                  $data = array(
                  'type'                              => 'bf_cat_assigning_user_assignees',
                  'title'                             => $nodeTitle,
                  'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                  'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                  'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                  'field_bf_catau_page_number'        => $page_number,
                  'field_bf_catau_page_date'          => $catasur_due_date,
                  'field_bf_catau_page_status'        => 'catalogue_created',
                  'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                  );
                  $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                  if(isset($InsertPageDetails['status'])) {
                    // Return error response.
                    return $InsertPageDetails;
                  }
                  // Send mail to assignee for assigned page details.
                  $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
                  // Return success message
                  $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
                  return $responseData;
                }
              }
            } else { // Check the given page range not are not equal.
              for($i=$pageRangeHyphen[0]; $i<=$pageRangeHyphen[1]; $i++) {
                $page_number   = $i;
                $pageNoArray[] = $page_number;
                if (in_array($page_number, $GetExistsPageRangeArray)) {
                  // Get the catalogue page assigned details by ctalogue id and page number.
                  $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '0');
                  // Check the result set is empty or not.
                  if(!empty($getpagedetails)) {
                    // Get page status.
                    $getpagestatus  = $getpagedetails['page_status'];
                    // Get page user id.
                    $getpageuserId  = $getpagedetails['page_userid'];
                    // Get page due date.
                    $getPageDate    = isset($getpagedetails['page_date']) && $getpagedetails['page_date']!='0000-00-00' && $getpagedetails['page_date']!=null?$getpagedetails['page_date']:'0000-00-00';
                    if($getpageuserId == $field_bf_catasur_assigninguserid) {
                      // Patch user id and existing user id is same.
                      // Check the page status is in in-progress or completed.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to the users and the page status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to the users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                        $updatePageDetails = array(
                          'node_id'                           => $getpagedetails['page_node_id'],
                          'field_bf_catau_page_status'        => $getpagestatus,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                        if(isset($updatePageDet['status'])) {
                          // Return error response.
                          return $updatePageDet;
                        } else {
                          // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                          $InsertPageHistoryDetails = array(
                            'type'                              => 'bf_cat_assigning_user_assignees',
                            'title'                             => $nodeTitle,
                            'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                            'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                            'field_bf_catau_page_userid'        => $getpagedetails['page_userid'],
                            'field_bf_catau_page_number'        => $page_number,
                            'field_bf_catau_page_date'          => $catasur_due_date,
                            'field_bf_catau_page_status'        => $getpagestatus,
                            'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                          );
                          $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                          if(isset($InsertPageHistory['status'])) {
                            // Return error response.
                            return $InsertPageHistory;
                          }
                        }
                      }
                    } else {
                      // Patch user id and existing user id is different.
                      // Check the page status is in in-progress or completed.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'The page is already assigned to some other users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        // update the page details and insert new record in history content.
                        // Update the page details ["BF Catalogue Assigning User Page Assignees"].
                        $updatePageDetails = array(
                          'node_id'                           => $getpagedetails['page_node_id'],
                          'field_bf_catau_page_status'        => $getpagestatus,
                          'field_bf_catau_page_date'          => $catasur_due_date,
                          'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                          'field_bf_catau_page_number'        => $page_number,
                          'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                          'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                          'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                        );
                        $updatePageDet = $this->UpdateBFCatalogueAssigningUserPages($updatePageDetails);
                        if(isset($updatePageDet['status'])) {
                          // Return error response.
                          return $updatePageDet;
                        } else {
                          // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                          $InsertPageHistoryDetails = array(
                            'type'                              => 'bf_cat_assigning_user_assignees',
                            'title'                             => $nodeTitle,
                            'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                            'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                            'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                            'field_bf_catau_page_number'        => $page_number,
                            'field_bf_catau_page_date'          => $catasur_due_date,
                            'field_bf_catau_page_status'        => $getpagestatus,
                            'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                          );
                          $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                          if(isset($InsertPageHistory['status'])) {
                            // Return error response.
                            return $InsertPageHistory;
                          }
                        }
                      }
                    }
                  } else {
                    // Get the catalogue page assigned details by ctalogue id and page number.
                    $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
                    if(!empty($getpagedetails)) {
                      // Get page status.
                      $getpagestatus = $getpagedetails['page_status'];
                      // Check the patch assign user id with result assigned user id.
                      if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                        // Checking the page status.
                        if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                          /**
                          * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                          **/
                          $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                          return $responseData;
                        } else {
                          /* 
                          * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                          */
                          try {
                            $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                            $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                            $updatepage = $pageUpdateNode->save();
                            if($updatepage) {
                              // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                              $InsertPageHistoryDetails = array(
                                'type'                              => 'bf_cat_assigning_user_assignees',
                                'title'                             => $nodeTitle,
                                'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                                'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                                'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                                'field_bf_catau_page_number'        => $page_number,
                                'field_bf_catau_page_date'          => $catasur_due_date,
                                'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                                'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                              );
                              $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                              if(isset($InsertPageHistory['status'])) {
                                // Return error response.
                                return $InsertPageHistory;
                              }
                            }
                          } catch (Exception $e) {
                            $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                            return $responseData;
                          }
                        }
                      } else {
                        // Checking the page status.
                        if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                          /**
                          * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                          **/
                          $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                          return $responseData;
                        } else {
                          /* 
                          * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                          * result page assign user id to patch page assign user id.
                          */
                          try {
                            $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                            $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                            $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                            $updatepage = $pageUpdateNode->save();
                            if($updatepage) {
                              // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                              $InsertPageHistoryDetails = array(
                                'type'                              => 'bf_cat_assigning_user_assignees',
                                'title'                             => $nodeTitle,
                                'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                                'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                                'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                                'field_bf_catau_page_number'        => $page_number,
                                'field_bf_catau_page_date'          => $catasur_due_date,
                                'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                                'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                              );
                              $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                              if(isset($InsertPageHistory['status'])) {
                                // Return error response.
                                return $InsertPageHistory;
                              }
                            }
                          } catch (Exception $e) {
                            $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                            return $responseData;
                          }
                        }
                      }
                    } else {
                      // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                      $data = array(
                        'type'                              => 'bf_cat_assigning_user_assignees',
                        'title'                             => $nodeTitle,
                        'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                        'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                        'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                        'field_bf_catau_page_number'        => $page_number,
                        'field_bf_catau_page_date'          => $catasur_due_date,
                        'field_bf_catau_page_status'        => 'catalogue_created',
                        'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                      );
                      $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                      if(isset($InsertPageDetails['status'])) {
                        // Return error response.
                        return $InsertPageDetails;
                      }
                    }
                  }
                  // Unset the looped array value.
                  if (($key = array_search($page_number, $existpagearray)) !== false) {
                    unset($existpagearray[$key]);
                  }
                } else {
                  // Get the catalogue page assigned details by ctalogue id and page number.
                  $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $page_number, $AssigningUserRole, $check = '1');
                  if(!empty($getpagedetails)) {
                    // Get page status.
                    $getpagestatus = $getpagedetails['page_status'];
                    // Check the patch assign user id with result assigned user id.
                    if($getpagedetails['page_userid'] == $field_bf_catasur_assigninguserid) {
                      // Checking the page status.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to the users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        /* 
                        * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id.
                        */
                        try {
                          $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                          $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                          $updatepage = $pageUpdateNode->save();
                          if($updatepage) {
                            // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                            $InsertPageHistoryDetails = array(
                              'type'                              => 'bf_cat_assigning_user_assignees',
                              'title'                             => $nodeTitle,
                              'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                              'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                              'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                              'field_bf_catau_page_number'        => $page_number,
                              'field_bf_catau_page_date'          => $catasur_due_date,
                              'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                              'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                            );
                            $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                            if(isset($InsertPageHistory['status'])) {
                              // Return error response.
                              return $InsertPageHistory;
                            }
                          }
                        } catch (Exception $e) {
                          $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                          return $responseData;
                        }
                      }
                    } else {
                      // Checking the page status.
                      if(isset($getpagestatus) && ($getpagestatus == 'catalogue_assign' || $getpagestatus == 'catalogue_start_job' || $getpagestatus == 'catalogue_completed' || $getpagestatus == 'catalogue_pause_job' || $getpagestatus == 'catalogue_stop_job' || $getpagestatus == 'catalogue_clipping')) {
                        /**
                        * Return response - This page is already assigned to some other users and its status is in-progress or completed.
                        **/
                        $responseData = ['status' => 'error', 'status_message' => 'This page already assigned to some other users and page status is '.$getpagestatus.'.'];
                        return $responseData;
                      } else {
                        /* 
                        * Change the result BF catalogue assigning user node id to patch BF catalogue assigning user node id and 
                        * result page assign user id to patch page assign user id.
                        */
                        try {
                          $pageUpdateNode = Node::load($getpagedetails['page_node_id']);
                          $pageUpdateNode->set('field_bfcatalogue_assigning_user', $field_bf_catasur_node_id);
                          $pageUpdateNode->set('field_bf_catasur_assigninguserid', $field_bf_catasur_assigninguserid);
                          $updatepage = $pageUpdateNode->save();
                          if($updatepage) {
                            // Insert page details in page history content -["BF Catalogue Assigning User Page Assignee's History"].
                            $InsertPageHistoryDetails = array(
                              'type'                              => 'bf_cat_assigning_user_assignees',
                              'title'                             => $nodeTitle,
                              'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                              'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                              'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                              'field_bf_catau_page_number'        => $page_number,
                              'field_bf_catau_page_date'          => $catasur_due_date,
                              'field_bf_catau_page_status'        => $getpagedetails['page_status'],
                              'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                            );
                            $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($getpagedetails['page_node_id'], $InsertPageHistoryDetails);
                            if(isset($InsertPageHistory['status'])) {
                              // Return error response.
                              return $InsertPageHistory;
                            }
                          }
                        } catch (Exception $e) {
                          $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                          return $responseData;
                        }
                      }
                    }
                  } else {
                    // Insert the page details ["BF Catalogue Assigning User Page Assignees"].
                    $data = array(
                      'type'                              => 'bf_cat_assigning_user_assignees',
                      'title'                             => $nodeTitle,
                      'field_bf_catau_page_catalogue'     => $field_bf_catasur_catalogue_id,
                      'field_bfcatalogue_assigning_user'  => $field_bf_catasur_node_id,
                      'field_bf_catau_page_userid'        => $field_bf_catasur_assigninguserid,
                      'field_bf_catau_page_number'        => $page_number,
                      'field_bf_catau_page_date'          => $catasur_due_date,
                      'field_bf_catau_page_status'        => 'catalogue_created',
                      'field_bf_catau_assigng_user_role'  => $field_bf_catasur_assign_userrole
                    );
                    $InsertPageDetails = $this->InsertBFCatalogueAssigningUserPages($data);
                    if(isset($InsertPageDetails['status'])) {
                      // Return error response.
                      return $InsertPageDetails;
                    }
                  }

                }
                if(!empty($existpagearray)) {
                  foreach($existpagearray as $ex_pagenumber) {
                    // Get the catalogue page assigned details by ctalogue id and page number.
                    $getpagedetails = $this->GetPageDetailsBycatId($field_bf_catasur_node_id,$field_bf_catasur_catalogue_id, $ex_pagenumber, $AssigningUserRole, $check = '0');
                    if(!empty($getpagedetails)) {
                      // Delete the not in array record except in-progress and completed status.
                      // Get page status.
                      $getpagestatus = $getpagedetails['page_status'];
                      // Checking the page status.
                      if(isset($getpagestatus) && !empty($getpagedetails['page_node_id']) && ($getpagestatus != 'catalogue_assign' || $getpagestatus != 'catalogue_start_job' || $getpagestatus != 'catalogue_completed' || $getpagestatus != 'catalogue_pause_job' || $getpagestatus != 'catalogue_stop_job' || $getpagestatus != 'catalogue_clipping')) {
                        $node = \Drupal::entityTypeManager()->getStorage('node')->load($getpagedetails['page_node_id']);
                        // Check if node exists with the given nid.
                        if ($node) {
                          $node->delete();
                        }
                      }
                    }
                  }
                }
              }
              // Send mail to assignee for assigned page details.
              $sendMailToAssignee = $this->SendMailToAssigneeByParams($jsondata, $pageNoArray, $field_bf_catasur_assign_userrole);
              // Return success message
              $responseData = ['status' => 'success', 'status_message' => 'Catalogue assigning user details updated successfully.'];
              return $responseData;
            }
          }
        }
      }
    } else {
      $responseData = ['status' => 'error', 'status_message' => 'Catalogue page assigning user not updated successfully.'];
      return $responseData;
    }
  }

  /**
  * Function :: Send mail to assignee for assigned pages details.
  */
  public function SendMailToAssigneeByParams($BFCatAuCreatedData, $pageNoArray, $field_bf_catasur_assign_userrole) {
    // Mail type for "Briefing form email notification sent to designer for assigned pages details."
    $mailType = '8';
    // Briefing form id.
    $briefingFormId = $BFCatAuCreatedData['field_bf_catasur_briefingform_id'];
    $catalogue_id   = $BFCatAuCreatedData['field_bf_catasur_catalogue_id'];
    // Page number array to string converion.
    if($pageNoArray) {
      $pageNumberString = implode(',', $pageNoArray);
    } else {
      $pageNumberString = NULl;
    }
    /**********************************************************/
    /******* Sending Mail using CURL Function - Start *********/
    /**********************************************************/
    header("Content-Type: text/json;");
    $host = \Drupal::request()->getSchemeAndHttpHost();
    // Curl function.
    $url = $host.'/briefingform/bfpostmail';
    $GetBriefingForm  = $this->GetBriefingFormByNodeId($briefingFormId);
    $bf_client_id     = (isset($GetBriefingForm->field_briefing_form_client_id->target_id) && !empty($GetBriefingForm->field_briefing_form_client_id->target_id))?$GetBriefingForm->field_briefing_form_client_id->target_id:null;
    $data = array(
      "briefingform_id"       => $briefingFormId,
      "catalogue_id"          => $catalogue_id,
      "field_client_id"       => $bf_client_id,
      "field_mail_type"       => $mailType,
      "bf_catassign_data"     => $BFCatAuCreatedData,
      "assigned_page_numbers" => $pageNumberString,
      "assigned_user_role"    => $field_bf_catasur_assign_userrole
    );
    $data_string = json_encode($data);
    $header = array("Content-Type: application/json");
    $curl   = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data_string
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    /**********************************************************/
    /******** Sending Mail using CURL Function - End **********/
    /**********************************************************/
    return $response;
  }

  /**
  * Function :: Update BF catalogue assigning user.
  */
  public function UpdateBFCatalogueAssigningUser($LoadNode, $upData) {
    try {
      $node_type  = 'bf_catalogue_assigning_user';
      $node_title = $upData['nodeTitle'];
      $field_bf_catasur_due_date = date('Y-m-d\TH:i:s', strtotime($upData['field_bf_catasur_due_date']));
      // Update catalogue assigning user.
      $node = $LoadNode;
      $node->set('type',$node_type);
      $node->set('title', $node_title);
      $node->set('field_bf_catasur_assigning_notes', $upData['field_bf_catasur_assigning_notes']);
      $node->set('field_bf_catasur_assigninguserid', $upData['field_bf_catasur_assigninguserid']);
      $node->set('field_bf_catasur_briefingform_id', $upData['field_bf_catasur_briefingform_id']);
      $node->set('field_bf_catasur_catalogue_id', $upData['field_bf_catasur_catalogue_id']);
      $node->set('field_bf_catasur_client_id', $upData['field_bf_catasur_client_id']);
      $node->set('field_bf_catasur_due_date', $field_bf_catasur_due_date);
      $node->set('field_bf_catasur_loggedin_userid', $upData['field_bf_catasur_loggedin_userid']);
      $node->set('field_bf_catasur_pageno_range', $upData['field_bf_catasur_pageno_range']);
      $update = $node->save();
      return $update;
    } catch (Exception $e) {
      $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
    }
  }

  /**
  *  Function :: Insert BF catalogue assigning user history.
  */
  public function InsertCatAssignUserHistory($data) {
    try {
      $node_type  = 'bf_catalogue_assigning_user';
      $node_title = $data['nodeTitle'];
      $field_bf_catasur_due_date = date('Y-m-d\TH:i:s', strtotime($data['field_bf_catasur_due_date']));
      $request_array = array(
        'type'                              => $node_type,
        'title'                             => $data['nodeTitle'],
        'field_bf_catasur_assigning_notes'  => $data['field_bf_catasur_assigning_notes'],
        'field_bf_catasur_assigninguserid'  => $data['field_bf_catasur_assigninguserid'],
        'field_bf_catasur_briefingform_id'  => $data['field_bf_catasur_briefingform_id'],
        'field_bf_catasur_catalogue_id'     => $data['field_bf_catasur_catalogue_id'],
        'field_bf_catasur_client_id'        => $data['field_bf_catasur_client_id'],
        'field_bf_catasur_due_date'         => $field_bf_catasur_due_date,
        'field_bf_catasur_loggedin_userid'  => $data['field_bf_catasur_loggedin_userid'],
        'field_bf_catasur_pageno_range'     => $data['field_bf_catasur_pageno_range'],
        'field_bf_catasur_assign_userrole'  => $data['field_bf_catasur_assign_userrole']
      );
      // Save the POST request in BF catalogue assigning user history content type.
      $jsondata = json_encode($request_array, TRUE);
      // Inserting new node in BF catalogue assigning user history.
      $node = Node::create(array(
        'type'                          => 'bf_cat_assigning_user_history',
        'title'                         => $data['nodeTitle'],
        'field_bf_catasurhis_json'      => $jsondata,
        'field_bf_catasurhis_nid'       => $data['field_bf_catasur_node_id'],
        'field_bf_catasurhis_date_time' => REQUEST_TIME
      ));
      $Save = $node->save();
      return $Save;
    } catch (Exception $e) {
      $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
    }
  }

  /**
  * Function :: Insert BF catalogue assigning user pages.
  */
  public function InsertBFCatalogueAssigningUserPages($data) {
    // Insert the catalogue assigning user page assignees.
    try {
      // Save the POST request in BF Catalogue Assigning User Page Assignee's content type.
      $node1 = Node::create($data);
      $Save1 = $node1->save();
      $saved1_nid = $node1->id();
      $field_bf_catau_page_date = date('Y-m-d\TH:i:s', strtotime($data['field_bf_catau_page_date']));
      if($Save1) {
        // Generate the history table JSON data.
        $historyCatAssign = array(
          'type'                              => 'bf_cat_assigning_user_assignees',
          'title'                             => $data['title'],
          'field_bfcatalogue_assigning_user'  => $data['field_bfcatalogue_assigning_user'],
          'field_bf_catau_page_catalogue'     => $data['field_bf_catau_page_catalogue'],
          'field_bf_catau_page_userid'        => $data['field_bf_catau_page_userid'],
          'field_bf_catau_page_number'        => $data['field_bf_catau_page_number'],
          'field_bf_catau_page_date'          => $field_bf_catau_page_date,
          'field_bf_catau_page_status'        => 'catalogue_created',
          'field_bf_catau_assigng_user_role'  => $data['field_bf_catau_assigng_user_role']
        );
        $InsertPageHistory = $this->InsertBFCatalogueAssigningUserPageHistory($saved1_nid, $data);
        if(isset($InsertPageHistory['status'])) {
          // Return error response.
          return $InsertPageHistory;
        }
        return $Save1;
      } else {
        $responseData = ['status' => 'error', 'status_message' => 'Catalogue page assigning user not updated successfully.'];
        return $responseData;
      }
    } catch (Exception $e) {
      $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      return $responseData;
    }
  }

  /**
  * Function :: Update BF catalogue assigning user pages.
  */
  public function UpdateBFCatalogueAssigningUserPages($data) {
    // Update the catalogue assigning user page assignees.
    if($data['node_id']) {
      $field_bf_catau_page_date = date('Y-m-d\TH:i:s', strtotime($data['field_bf_catau_page_date']));
      try {
        $pageNode = Node::load($data['node_id']);
        $pageNode->set('field_bf_catau_page_status', $data['field_bf_catau_page_status']);
        $pageNode->set('field_bf_catau_page_date', $field_bf_catau_page_date);
        $pageNode->set('field_bf_catau_page_userid', $data['field_bf_catau_page_userid']);
        $pageNode->set('field_bf_catau_page_number', $data['field_bf_catau_page_number']);
        $pageNode->set('field_bfcatalogue_assigning_user', $data['field_bfcatalogue_assigning_user']);
        $pageNode->set('field_bf_catau_page_catalogue', $data['field_bf_catau_page_catalogue']);
        $pageNode->set('field_bf_catau_assigng_user_role', $data['field_bf_catau_assigng_user_role']);
        $updatepage = $pageNode->save();
        return $updatepage;
      } catch (Exception $e) {
        $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
        return $responseData;
      }
    } else {
      return false;
    }
  }

  /**
  * Function :: Insert BF catalogue assigning user page history.
  */
  public function InsertBFCatalogueAssigningUserPageHistory($page_node_id, $data) {
    try {
      $jsonData = json_encode($data, TRUE);
      // Inserting new node in BF Catalogue Assigning User Page Assignee's History.
      $nodeHistory = Node::create(array(
        'type'                             => 'bf_cat_assuser_assignees_history',
        'title'                            => $data['title'],
        'field_bf_cataupageassignee_json'  => $jsonData,
        'field_bf_cataupageassignee_nid'   => $page_node_id,
        'field_bf_cataupageassignee_date'  => REQUEST_TIME,
        'field_bf_cataupageassigne_status' => 'catalogue_created'
      ));
      $SaveHistory = $nodeHistory->save();
      return $SaveHistory;
    } catch (Exception $e) {
      $responseData = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      return $responseData;
    }
  }

  /**
  * Function :: Get page range value in array format.
  */
  public function GetCatAssignPageArray($pagerange) {
    if($pagerange) {
      if(is_numeric($pagerange)) {
        $arrData = array($pagerange);
      } else {
        // Check the given page range is using hyphen
        $pageRangeHyphen = explode('-', $pagerange);
        if(!empty($pageRangeHyphen)) {
          for($i=$pageRangeHyphen[0]; $i<=$pageRangeHyphen[1]; $i++) {
            $arrData[] = $i;
          }
        }
      }
    } else {
      $arrData = array();
    }
    return $arrData;
  }

  /**
  * Function :: Get catalogue page details by catalogue id.
  */
  public function GetPageDetailsBycatId($field_bf_catasur_node_id, $catalogueId, $page_number, $AssigningUserRole, $check) {
    // Initialize array.
    $arrData = array();
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'entity_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcau', 'field_bfcatalogue_assigning_user_target_id', 'catasur_node_id');
    $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'catalogue_page_date');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catalogue_page_number');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catalogue_page_status');
    $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'catalogue_page_userid');
    $query->addField('nfbfcaur', 'field_bf_catau_assigng_user_role_value', 'catalogue_page_user_role');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    if($check=='0') {
      $query->condition('nfbfcau.field_bfcatalogue_assigning_user_target_id', $field_bf_catasur_node_id, '=');
    } else {
      $query->condition('nfbfcau.field_bfcatalogue_assigning_user_target_id', $field_bf_catasur_node_id, '!=');
    }
    $query->condition('nfbfcpn.field_bf_catau_page_number_value', $page_number);
    $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $AssigningUserRole);
    $query->condition('nfbfcps.field_bf_catau_page_status_value', 'catalogue_created', '=');
    $query->allowRowCount = TRUE;
    $result = $query->execute()->fetchAssoc();
    if(!empty($result)){
      if(!empty($result['catalogue_page_date']) && $result['catalogue_page_date'] != '0000-00-00') {
        $pageDate = date('d-m-Y', strtotime($result['catalogue_page_date']));
      } else {
        $pageDate = null;
      }
      $arrData['page_node_id']    = $result['entity_id'];
      $arrData['catalogue_id']    = $result['catalogue_id'];
      $arrData['catasur_node_id'] = $result['catasur_node_id'];
      $arrData['page_date']       = $pageDate;
      $arrData['page_number']     = $result['catalogue_page_number'];
      $arrData['page_status']     = $result['catalogue_page_status'];
      $arrData['page_userid']     = $result['catalogue_page_userid'];
      $arrData['page_user_role']  = $result['catalogue_page_user_role'];
    }
    return $arrData;
  }

  /** 
  * Function :: Delete briefing form catalogue assigning user details.
  */
  public function DeleteBFCatalogueAssigningUserDetails($jsondata) {
    $field_bf_catasur_node_id = !empty($jsondata['field_bf_catasur_node_id'])?$jsondata['field_bf_catasur_node_id']:null;
    $userID = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
    if($field_bf_catasur_node_id!=null) {
      try{
        // Get node details by node id.
        $nodeData     = Node::load($field_bf_catasur_node_id);
        $catalogueId  = $nodeData->field_bf_catasur_catalogue_id->target_id;
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($field_bf_catasur_node_id);
        // Check if node exists with the given nid.
        if ($node) {
          // Delete pages record.
          $getNodeId = $this->DeletecatalogueAssignPagesByParam($catalogueId, $field_bf_catasur_node_id);
          if($getNodeId) {
            $delete = $node->delete();
          }
          $result = ['status' => 'success', 'status_message' => 'Catalogue assigning user details deleted successfully.'];
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not deleted successfully.'];    
        }
      } catch (Exception $e) {
        $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      }
    } else {
      $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not deleted successfully.'];
    }
    $responseData = $jsondata;
    $node_type = 'bf_catalogue_assigning_user';
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'Delete', $node_type, $responseData, $userID, $result);
    return $result;
  }

  /**
  * Function :: Delete catalogue page node id by catalogue id.
  */
  public function DeletecatalogueAssignPagesByParam($catalogueId, $field_bf_catasur_node_id) {

    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcpc', 'entity_id', 'entity_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catalogue_page_number');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catalogue_page_status');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcau.field_bfcatalogue_assigning_user_target_id', $field_bf_catasur_node_id);
    $query->condition('nfbfcps.field_bf_catau_page_status_value', 'catalogue_created', '=');
    $query->orderBy('nfbfcpn.field_bf_catau_page_number_value', 'ASC');
    $query->allowRowCount = TRUE;
    $result = $query->execute()->fetchAll();
    if(!empty( $result )){
      foreach($result as $res) {
        $node_id = $res->entity_id;
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($node_id);
        if($node){
          $delete = $node->delete();
        }
      }
      return true;
    } else {
      return false;
    }
  }

  /** 
  * Function :: #27 c) - Get briefing form catalogue assigning user details.
  */
  public function GetBFCatalogueAssigningUserDetails($catalogueID, $userType, $userID) {
    if($catalogueID!=null) {
      try{
        $query = \Drupal::database()->select('node__field_bf_catasur_catalogue_id', 'nfbf_catid');
        $query->leftjoin('node__field_bf_catasur_due_date', 'nfbf_dd', 'nfbf_dd.entity_id = nfbf_catid.entity_id');
        $query->leftjoin('node__field_bf_catasur_loggedin_userid', 'nfbf_luid', 'nfbf_luid.entity_id = nfbf_catid.entity_id');
        $query->leftjoin('node__field_bf_catasur_pageno_range', 'nfbf_pr', 'nfbf_pr.entity_id = nfbf_catid.entity_id');
        $query->leftjoin('node__field_bf_catasur_client_id', 'nfbf_cid', 'nfbf_cid.entity_id = nfbf_catid.entity_id');
        $query->leftjoin('node__field_bf_catasur_briefingform_id', 'nfbf_bid', 'nfbf_bid.entity_id = nfbf_catid.entity_id');
        $query->leftjoin('node__field_bf_catasur_assigning_notes', 'nfbf_an', 'nfbf_an.entity_id = nfbf_catid.entity_id');
        $query->leftjoin('node__field_bf_catasur_assigninguserid', 'nfbf_aid', 'nfbf_aid.entity_id = nfbf_catid.entity_id');
        $query->leftjoin('node__field_bf_catasur_assign_userrole', 'nfbf_aur', 'nfbf_aur.entity_id = nfbf_catid.entity_id');
        $query->addField('nfbf_catid', 'field_bf_catasur_catalogue_id_target_id', 'catalogue_id');
        $query->addField('nfbf_catid', 'entity_id', 'entity_id');
        $query->addField('nfbf_dd', 'field_bf_catasur_due_date_value', 'due_date');
        $query->addField('nfbf_luid', 'field_bf_catasur_loggedin_userid_target_id', 'loggedin_userid');
        $query->addField('nfbf_pr', 'field_bf_catasur_pageno_range_value', 'pageno_range');
        $query->addField('nfbf_cid', 'field_bf_catasur_client_id_value', 'client_id');
        $query->addField('nfbf_bid', 'field_bf_catasur_briefingform_id_target_id', 'briefingform_id');
        $query->addField('nfbf_an', 'field_bf_catasur_assigning_notes_value', 'assigning_notes');
        $query->addField('nfbf_aid', 'field_bf_catasur_assigninguserid_target_id', 'assigninguserid');
        $query->addField('nfbf_aur', 'field_bf_catasur_assign_userrole_value', 'assigninguserrole');
        $query->condition('nfbf_catid.field_bf_catasur_catalogue_id_target_id', $catalogueID);
        if(!empty($userType) && ($userType =='operator' || $userType =='supervisor')) {
          $query->condition('nfbf_aid.field_bf_catasur_assigninguserid_target_id', $userID);
        }
        $query->allowRowCount = TRUE;
        $result = $query->execute()->fetchAll();
        \Drupal::logger('API-27-c-1')->notice('@result],', [
          '@result' => json_encode($result),
        ]);
        if(!empty( $result )){
          foreach($result as $res) {
            // Catalogue Id.
            $catalogueId  = $res->catalogue_id;
            // Page range.
            $pagerange    = $res->pageno_range;
            // Get user assigning pages.
            $getPages = $this->GetUserAssigningPagesByCatalogueId($catalogueId, $res->entity_id, $res->pageno_range, $userType, $userID);
            $arrData[] = array(
              'field_bf_catasur_node_id'            => $res->entity_id,
              'field_bf_catasur_assigning_notes'    => $res->assigning_notes,
              'field_bf_catasur_assigninguserid'    => $res->assigninguserid,
              'field_bf_catasur_assign_userrole'    => $res->assigninguserrole,
              'field_bf_catasur_briefingform_id'    => $res->briefingform_id,
              'field_bf_catasur_catalogue_id'       => $catalogueId,
              'field_bf_catasur_client_id'          => $res->client_id,
              'field_bf_catasur_due_date'           => $res->due_date,
              'field_bf_catasur_loggedin_userid'    => $res->loggedin_userid,
              'field_bf_catasur_pageno_range'       => $res->pageno_range,
              'field_bf_catasur_pageno_range_pages' => $getPages,
            );
          }
          return $arrData;
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not found.'];
        }
      } catch (Exception $e) {
        $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      }
    } else {
      $result = ['status' => 'error', 'status_message' => 'Catalogue assigning user details not found.'];
    }
    return $result;
  }

  /**
  *  Function :: Get briefing form catalogue assigning pages details by catalogue id.
  */
  public function GetUserAssigningPagesByCatalogueId($catalogueId, $BFCatAssUserID, $pageno_range, $userType, $userID) {

    /*$GetCatWorkflowStatus = $this->GetCatalogueWorkflowStatusByParams($catalogueId);
    $array_keys   = array_keys($GetCatWorkflowStatus);
    $array_values = array_values($GetCatWorkflowStatus);
    $CatalogueWorkflowStatus = $array_keys[0];
    $ToCheck = $this->ToCheckAssigndUserPagesNotInOperatorStatus($catalogueId, $BFCatAssUserID);*/
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'node_id');
    $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'catalogue_page_date');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catalogue_page_number');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catalogue_page_status');
    $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'catalogue_assign_userid');
    $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'catalogue_assign_userrole');
    $query->condition('nfbfcau.field_bfcatalogue_assigning_user_target_id', $BFCatAssUserID);
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    
    if(!empty($userType) && ($userType =='operator' || $userType =='supervisor')) {
      $query->condition('nfbfcpu.field_bf_catau_page_userid_target_id', $userID);
    }
    $query->orderBy('nfbfcpn.field_bf_catau_page_number_value', 'ASC');
    $query->allowRowCount = TRUE;
    $result = $query->execute()->fetchAll();
    \Drupal::logger('API-27-c-2')->notice('@result],', [
      '@result' => json_encode($result),
    ]);
    if(!empty( $result )){
      foreach($result as $res) {
        if(!empty($res->catalogue_page_date) && $res->catalogue_page_date != '0000-00-00T00:00:00') {
          $pageDate = date('Y-m-d\TH:i:s', strtotime($res->catalogue_page_date));
        } else {
          $pageDate = null;
        }
        $pageNumber = $res->catalogue_page_number;
        $arrData[$pageNumber] = array(
          'status'      => $res->catalogue_page_status,
          'date'        => $pageDate,
          'node_id'     => $res->node_id,
          'page_number' => $pageNumber,
          'user_id'     => $res->catalogue_assign_userid,
          'user_role'   => $res->catalogue_assign_userrole
         );
      }
    } else {
      $arrData = array();
    }
    return $arrData;
  }

  /**
   * Function :: To Check assigned pages are not in operator status.
   */
  public function ToCheckAssigndUserPagesNotInOperatorStatus($catalogueId, $BFCatAssUserID) {
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfcau', 'nfbfcau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcpur', 'nfbfcpur.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'node_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catalogue_page_number');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catalogue_page_status');
    $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'catalogue_assign_userid');
    $query->addField('nfbfcpur', 'field_bf_catau_assigng_user_role_value', 'catalogue_assign_userrole');
    $query->condition('nfbfcau.field_bfcatalogue_assigning_user_target_id', $BFCatAssUserID);
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcpur.field_bf_catau_assigng_user_role_value', 'operator', '!=');
    $result = $query->execute()->fetchAll();
    if($result) {
      return true;
    } else {
      return false;
    }
  }

  /**
  * Function :: Get All Workflow Status.
  */
  public function GetWorkflowAllStatus() {
    $arrData = array();
    $states = WorkflowState::loadMultiple();
    //$states = Workflow::load('catalogue');
    foreach ($states as $state) {
      // Check the active status state and get the active status values only.
      if($state->status) {
        $arrData[] = array(
          $state->id() => $state->label,
        );
      }
    }
    return $arrData;
  }

  /**
  * Function :: Get current workflow status of catalogue by id.
  */
  public function GetCatalogueWorkflowStatusByParams($catalogueID) {

    try {
      $AllWorkflowStatus = WorkflowState::loadMultiple();
      $Workflow_array    = array();
      foreach ($AllWorkflowStatus as $state) {
        $Workflow_array[$state->id()] = $state->label;
      }
      $result = array();
      # Select Query.
			$query 	= \Drupal::database()->select('node__field_catalogue_workflow', 'm')->condition('entity_id', $catalogueID)->fields('m');
			$record = $query->execute()->fetchAssoc();
      if(isset($record) && !empty($record['entity_id'])) {
        $catalogueworkflow = $record['field_catalogue_workflow_value'];      
        foreach($Workflow_array as $key=> $value) {
          if($catalogueworkflow == $key) {
            $result[$key] = $value;
          }
        }
      } else {
        $result = ['status' => 'error', 'status_message' => 'No data found.'];
      }
      return $result;
    } catch (Exception $e) {
      $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      return $result;
    }
  }

  /** 
  * Function :: Briefing form Save post Catalogue workflow status.
  */
  public function SaveBFAPICatalogueWorkflowStatus($jsondata) {
    # Database Connection.
		$db = \Drupal::database();
    # Get language code.
    $GetlanguageCode = \Drupal::languageManager()->getCurrentLanguage()->getId();
    # Get language name.
    $GetlanguageName =  \Drupal::languageManager()->getCurrentLanguage()->getName();
    $briefingFormID  = $jsondata['field_briefingform_id'];
    $catalogueID     = $jsondata['field_catalogue_id'];
    $workflowStatus  = $jsondata['field_workflow_status'];
    $userID          = $jsondata['field_user_id'];
    $workflow_to_sid = $workflowStatus;
    $field_name      = 'field_catalogue_workflow';
    $user_acct       = User::load($userID);
    // Get Catalogue workflow status in catalogue content type.
    $GetCatWorkflowStatus = $this->GetCatalogueWorkflowStatusDetailsByCatId($catalogueID);
    $vids = \Drupal::entityManager()->getStorage('node')->revisionIds(node_load($catalogueID));
    $GetLastWFSRecord     = $this->GetLastWFSRecordByCatalogueId($catalogueID);
    $existWFS_revisionId  = (isset($GetLastWFSRecord['revision_id']) && !empty($GetLastWFSRecord['revision_id']) && $GetLastWFSRecord['revision_id']!=null) ?$GetLastWFSRecord['revision_id']:$vids[0];
    $existWFS_status      = !empty($GetLastWFSRecord['to_sid'])?$GetLastWFSRecord['to_sid']:null;
    $existWFS_entityType  = !empty($GetLastWFSRecord['entity_type'])?$GetLastWFSRecord['to_sid']:null;
    $workflow_curr_sid    = $existWFS_status;
    // Check and get workflow details by catalogue id.
    $CheckCatWorkflow = $this->CheckAndGetCatalogueWorkflowDetailsByCatId($catalogueID);
    if(!empty($CheckCatWorkflow)) {
      $workflow             = Workflow::load('catalogue');
      $workflow_curr_state  = $workflow->getState($workflow_curr_sid);
      $workflow_new_state   = $workflow->getState($workflow_to_sid);
      $workflow_state_id    = $workflow_new_state->id();
      $workflow_state_label = $workflow_new_state->label();
      // Update workflow details in catalogue workflow table and insert new record workflow history table.
      if($GetCatWorkflowStatus) {
        $updArray = array('field_catalogue_workflow_value' => $workflowStatus);
			  # Update Query.
        try{
			    $updateQry  = $db->update('node__field_catalogue_workflow')->fields($updArray)->condition('entity_id', $catalogueID)->execute();
          $statusMSG1 = 'catalogue workflow status update successfully : '.$catalogueID.' | '.$workflow_state_id.' - '.$workflow_state_label;
          $response1  = ['status' => 'success', 'status_message' => $statusMSG1];
        } catch (Exception $e) {
          $response1  = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
        }
        \Drupal::logger('catalogue-workflow-status-update')->notice('@jsondata ||  %updArray ||  %response1],', [
          '@jsondata' => json_encode($jsondata),
          '%updArray' => json_encode($updArray),
          '%response1' => json_encode($response1),
        ]);
      } else {
        // Insert new record in catalogue workflow table.
        $arrData = array(
          'bundle' => 'catalogue',
          'deleted' => '0',
          'entity_id' => $catalogueID,
          'revision_id' => $existWFS_revisionId,
          'langcode' => $GetlanguageCode,
          'delta' => '0',
          'field_catalogue_workflow_value' => $workflowStatus
        );
        try{
          $InsertQry  = $db->insert('node__field_catalogue_workflow')->fields($arrData)->execute();
          $statusMSG2 = 'catalogue workflow status inserted successfully : '.$catalogueID.' | '.$workflow_state_id.' - '.$workflow_state_label;
          $response2  = ['status' => 'success', 'status_message' => $statusMSG2];
        } catch (Exception $e) {
          $response2  = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
        }
        \Drupal::logger('catalogue-workflow-status-save')->notice('@jsondata ||  %arrData ||  %response2],', [
          '@jsondata' => json_encode($jsondata),
          '%arrData' => json_encode($arrData),
          '%response2' => json_encode($response2),
        ]);
      }
      $workflow_comment = t('Worklow status changed from @from to @tosid by @user on @now', [
        '@from' => $workflow_curr_state->label(),
        '@tosid'=> $workflow_new_state->label(),
        '@user' => $user_acct->getAccountName(),
        '@now'  => date('d-m-Y H:i'),
      ]);
      $updArray = array(
        'wid'         => 'catalogue',
        'langcode'    => $GetlanguageCode,
        'entity_type' => 'node',
        'entity_id'   => $catalogueID,
        'revision_id' => $existWFS_revisionId,
        'field_name'  => $field_name,
        'delta'       => '0',
        'from_sid'    => $existWFS_status,
        'to_sid'      => $workflowStatus,
        'uid'         => $userID,
        'timestamp'   => REQUEST_TIME,
        'comment'     => $workflow_comment
      );
      try{
			  # Update Query.
        $InsertQuery = $db->insert('workflow_transition_history')->fields($updArray)->execute();
        $status_message = 'catalogue workflow status saved successfully : '.$catalogueID.' | '.$workflow_state_id.' - '.$workflow_state_label;
        $result       = ['status' => 'success', 'status_message' => $status_message];
      } catch (Exception $e) {
        $result       = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      }
      \Drupal::logger('workflow-status-save')->notice('@jsondata ||  %result],', [
        '@jsondata' => json_encode($jsondata),
        '%result' => json_encode($result),
      ]);
      return true;
    } else {
      $workflow_curr_sid    = 'catalogue_client_submit';
      $workflow_to_sid      = 'catalogue_creation';
      $workflow             = Workflow::load('catalogue');
      $workflow_curr_state  = $workflow->getState($workflow_curr_sid);
      $workflow_new_state   = $workflow->getState($workflow_to_sid);
      $workflow_state_id    = $workflow_new_state->id();
      $workflow_state_label = $workflow_new_state->label();
      if($GetCatWorkflowStatus) {
        $updArray = array('field_catalogue_workflow_value' => $workflowStatus);
			  # Update Query.
        try{
			    $updateQry  = $db->update('node__field_catalogue_workflow')->fields($updArray)->condition('entity_id', $catalogueID)->execute();
          $statusMSG1 = 'catalogue workflow status update successfully : '.$catalogueID.' | '.$workflow_state_id.' - '.$workflow_state_label;
          $response1  = ['status' => 'success', 'status_message' => $statusMSG1];
        } catch (Exception $e) {
          $response1  = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
        }
        \Drupal::logger('catalogue-workflow-status-update')->notice('@jsondata ||  %updArray ||  %response1],', [
          '@jsondata' => json_encode($jsondata),
          '%updArray' => json_encode($updArray),
          '%response1' => json_encode($response1),
        ]);
      } else {
        // Insert new record in catalogue workflow table.
        $arrData = array(
          'bundle' => 'catalogue',
          'deleted' => '0',
          'entity_id' => $catalogueID,
          'revision_id' => $existWFS_revisionId,
          'langcode' => $GetlanguageCode,
          'delta' => '0',
          'field_catalogue_workflow_value' => $workflowStatus
        );
        try{
          $InsertQry  = $db->insert('node__field_catalogue_workflow')->fields($arrData)->execute();
          $statusMSG2 = 'catalogue workflow status inserted successfully : '.$catalogueID.' | '.$workflow_state_id.' - '.$workflow_state_label;
          $response2  = ['status' => 'success', 'status_message' => $statusMSG2];
        } catch (Exception $e) {
          $response2  = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
        }
        \Drupal::logger('catalogue-workflow-status-save')->notice('@jsondata ||  %arrData ||  %response2],', [
          '@jsondata' => json_encode($jsondata),
          '%arrData' => json_encode($arrData),
          '%response2' => json_encode($response2),
        ]);
      }
      $workflow_comment = t('Worklow status changed from @from to @tosid by @user on @now', [
        '@from' => $workflow_curr_state->label(),
        '@tosid'=> $workflow_new_state->label(),
        '@user' => $user_acct->getAccountName(),
        '@now'  => date('d-m-Y H:i'),
      ]);
      $updArray = array(
        'wid'         => 'catalogue',
        'langcode'    => $GetlanguageCode,
        'entity_type' => 'node',
        'entity_id'   => $catalogueID,
        'revision_id' => $existWFS_revisionId,
        'field_name'  => $field_name,
        'delta'       => '0',
        'from_sid'    => 'catalogue_client_submit',
        'to_sid'      => 'catalogue_creation',
        'uid'         => $userID,
        'timestamp'   => REQUEST_TIME,
        'comment'     => $workflow_comment
      );
      try{
			  # Update Query.
        $InsertQuery = $db->insert('workflow_transition_history')->fields($updArray)->execute();
        $status_message = 'catalogue workflow status saved successfully : '.$catalogueID.' | '.$workflow_state_id.' - '.$workflow_state_label;
        $result       = ['status' => 'success', 'status_message' => $status_message];
      } catch (Exception $e) {
        $result       = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      }
      \Drupal::logger('workflow-status-save')->notice('@jsondata ||  %result],', [
        '@jsondata' => json_encode($jsondata),
        '%result' => json_encode($result),
      ]);
      return true;
    }
  }

  /**
   * Funtion :: Get catalogue workflow status details By catalogue id.
   */
  public function GetCatalogueWorkflowStatusDetailsByCatId($catalogueID) {
    $query 	= \Drupal::database()->select('node__field_catalogue_workflow', 'm')->condition('entity_id', $catalogueID)->fields('m');
		$record = $query->execute()->fetchAssoc();
    return $record;
  }

  /**
   * Funtion :: Check and get catalogue workflow details By catalogue id.
   */
  public function CheckAndGetCatalogueWorkflowDetailsByCatId($catalogueID) {
    $query = \Drupal::database()->select('workflow_transition_history', 'm')->condition('entity_id', $catalogueID)->fields('m');
    $query->orderBy('m.hid', 'DESC');
    $results = $query->execute()->fetchAll();
    return $results;
  }

  /**
   * Function :: Get Last workflow status record in workflow history.
   */
  public function GetLastWFSRecordByCatalogueId($catalogueID) {
    $query = \Drupal::database()->select('workflow_transition_history', 'm')->condition('entity_id', $catalogueID)->fields('m');
    $query->orderBy('m.hid', 'DESC');
    $query->range(0, 1);
    $results = $query->execute()->fetchAssoc();
    return $results;
  }

  /**
   * Function :: Insert catalogue workflow details.
   */
  public function InsertCatalogueWorkflowDetails($data) {

    $briefingFormId           = $data['field_briefingform_id'];
    $briefingFormCatalogueId  = $data['field_catalogue_id'];
    $field_workflow_from_sid  = $data['field_workflow_from_sid'];
    $field_workflow_to_sid    = $data['field_workflow_to_sid'];
    $userID                   = $data['field_user_id'];
    $field_name               = 'field_catalogue_workflow';
    # Database Connection.
		$db = \Drupal::database();
    # Get language code.
    $GetlanguageCode = \Drupal::languageManager()->getCurrentLanguage()->getId();
    # Get language name.
    $GetlanguageName =  \Drupal::languageManager()->getCurrentLanguage()->getName();
    // Get User details.
    $user_acct = User::load($userID);
    // Get catalogue revision details.
    $GetRevision = $this->GetRevisionIdByNodeId($briefingFormCatalogueId);
    $vid = $GetRevision['vid'];
    // Load catalogue workflow.
    $workflow = Workflow::load('catalogue');
    $workflow_curr_state  = $workflow->getState($field_workflow_from_sid);
    $workflow_new_state   = $workflow->getState($field_workflow_to_sid);
    $workflow_state_id    = $workflow_new_state->id();
    $workflow_state_label = $workflow_new_state->label();
    $workflow_comment = t('Worklow status changed from @from to @tosid by @user on @now', [
      '@from' => $workflow_curr_state->label(),
      '@tosid'=> $workflow_new_state->label(),
      '@user' => $user_acct->getAccountName(),
      '@now'  => date('d-m-Y H:i'),
    ]);
    $updArray = array(
      'wid'         => 'catalogue',
      'langcode'    => $GetlanguageCode,
      'entity_type' => 'node',
      'entity_id'   => $briefingFormCatalogueId,
      'revision_id' => $vid,
      'field_name'  => $field_name,
      'delta'       => '0',
      'from_sid'    => $field_workflow_from_sid,
      'to_sid'      => $field_workflow_to_sid,
      'uid'         => $userID,
      'timestamp'   => REQUEST_TIME,
      'comment'     => $workflow_comment
    );
    try{
      # Update Query.
      $InsertQuery    = $db->insert('workflow_transition_history')->fields($updArray)->execute();
      $status_message = 'catalogue workflow status saved successfully : '.$briefingFormCatalogueId.' | '.$workflow_state_id.' - '.$workflow_state_label;
      $result         = ['status' => 'success', 'status_message' => $status_message];
    } catch (Exception $e) {
      $result         = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
    }
    \Drupal::logger('catalogue-workflow-status-save')->notice('@data ||  %result],', [
      '@data' => json_encode($data),
      '%result' => json_encode($result),
    ]);
    return true;
  }

  /**
   * Function :: Get revision id by node id details.
   */
  public function GetRevisionIdByNodeId($catalogueID) {
    $query 	= \Drupal::database()->select('node_field_revision', 'm')->condition('nid', $catalogueID)->fields('m');
		$record = $query->execute()->fetchAssoc();
    return $record;
  }

  /** 
  * Function :: Briefing form Save post Catalogue workflow status.
  */
  public function SaveBFCatalogueWorkflow_Status($jsondata) {

    $briefingFormID  = $jsondata['field_briefingform_id'];
    $catalogueID     = $jsondata['field_catalogue_id'];
    $workflowStatus  = $jsondata['field_workflow_status'];
    $userID          = $jsondata['field_user_id'];
    $workflow_to_sid = $workflowStatus;
    $field_name      = 'field_catalogue_workflow';
    $catalogue = \Drupal::entityTypeManager()->getStorage('node')->load($catalogueID);
    // Get briefing form user account by briefing form.
    //$BFUserId = $this->GetBFDetailsByBFID($briefingFormID);
    $user_acct = User::load($userID);
    // Get the current workflow state for this catalogue.
    $workflow_curr_sid = WorkflowManager::getCurrentStateId($catalogue);
    // Get the workflow transitions specified for the current state.
    $workflow = Workflow::load('catalogue');
    $workflow_curr_state = $workflow->getState($workflow_curr_sid);
    $workflow_transitions = $workflow_curr_state->getTransitions($catalogue);
    foreach ($workflow_transitions as $transition) {
      if (!empty($workflow_to_sid) && !empty($transition->getToSid()) && $transition->getToSid() == $workflow_to_sid) { 
        /** @var \Drupal\workflow\Entity\WorkflowState $workflow_new_state */
        $workflow_new_state = $workflow->getState($workflow_to_sid);
        $workflow_transition = WorkflowTransition::create([$workflow_curr_state, 'field_name' => $field_name]);
        $workflow_transition->setTargetEntity($catalogue);
        $workflow_comment = t('Worklow status changed from @from to @tosid by @user on @now', [
          '@from' => $workflow_curr_state->label(),
          '@tosid'=> $workflow_new_state->label(),
          '@user' => $user_acct->getAccountName(),
          '@now'  => date('d-m-Y H:i'),
        ]);
        $workflow_transition->setValues($workflow_new_state, $user_acct->id(), REQUEST_TIME, $workflow_comment);
        $workflow_transition->execute(TRUE);
        $workflow_state_id = $workflow_new_state->id();
        $workflow_state_label = $workflow_new_state->label();
        if ($tid = $workflow_transition->id()) {
          // Set the new value of the workflow field
          $catalogue->set($field_name, $workflow_new_state->id());
          $workflow_node = $catalogue->save();
          $workflow_node_id = $catalogue->id();
          // Invalidate cached copes of the catalogue node.
          Cache::invalidateTags(['node:' . $catalogue->id()]);
          if($workflow_node) {
            \Drupal::logger('catalogue-workflow-status-save')->notice('@status || %catalogueID || %workflow_states ||  %workflow_node],', [
              '@status' => 'catalogue workflow status saved successfully',
              '%catalogueID' => $catalogueID,
              '%workflow_states' => $workflow_state_id.' - '.$workflow_state_label,
              '%workflow_node' => $workflow_node,
            ]);
          } else {
            \Drupal::logger('catalogue-workflow-status-save')->notice('@status || %catalogueID ||  %workflow_states ||  %workflow_node],', [
              '@status' => 'catalogue workflow status not saved successfully',
              '%catalogueID' => $catalogueID,
              '%workflow_states' => $workflow_state_id.' - '.$workflow_state_label,
              '%workflow_node' => $workflow_node,
            ]);
          }
          return true;
        } else {
          \Drupal::logger('catalogue-workflow-status-save')->notice('@status || %catalogueID ||  %workflow_states ||  %workflow_node],', [
            '@status' => 'catalogue workflow status not saved successfully',
            '%catalogueID' => $catalogueID,
            '%workflow_states' => $workflow_state_id.' - '.$workflow_state_label,
            '%workflow_node' => $workflow_node,
          ]);
          return false;
        }
      }
    }
  }

  /**
  * Function :: Get Briefing form details by id. 
  */
  public function GetBFDetailsByBFID($id) {
    # Select query.
    $query  = \Drupal::database()->select('node__field_briefing_form_author', 'm')->condition('entity_id', $id)->fields('m');
    $record = $query->execute()->fetchAssoc();
    return $record['field_briefing_form_author_target_id'];
  }

  /**
  * Function :: Updating the catalogue page (clipping) working status.
  */
  public function UpdatingBFCatProductionWorkingStatus_old($jsondata) {
    $catalogueId    = $jsondata['field_bf_catalogue_id'];
    $pageStatus     = $jsondata['field_bf_page_status'];
    $pageDate       = $jsondata['field_bf_page_date'];
    $pageNo         = $jsondata['field_bf_pageno'];
    $userId         = $jsondata['field_bf_user_id'];
    $briefingFormID = $jsondata['field_briefingform_id'];
    $userType       = $jsondata['field_user_type']; // eg. client/team_leader/designer
    // Get Node id for updating catalogue assign page.
    $nodeId = $this->GetNodeIdOfCatalogueAssignPage($catalogueId, $pageNo);
    if($nodeId) {
      try {
        // Change the date format from d-m-Y to Y-m-d.
        $page_date = date('Y-m-d\TH:i:s', strtotime($pageDate));
        // Updating catalogue assign page working production status.
        $node = Node::load($nodeId);
        $node->set('field_bf_catau_page_date', $page_date);
        $node->set('field_bf_catau_page_status', $pageStatus);
        $node->set('field_bf_catau_page_userid', $userId);
        $update = $node->save();
        if($update) {
          if(!empty($userType) && $userType == 'operator') { // Designer.
            $ChangeStatus = $this->UpdateBriefingFormStatusByDesigner($jsondata);
            if(isset($ChangeStatus['status'])) {
              return $ChangeStatus;
            }
          } else if(!empty($userType) && $userType != 'operator') { // Designer.
            $ChangeStatus = $this->UpdateBriefingFormStatusByOtherUserType($jsondata);
            if(isset($ChangeStatus['status'])) {
              return $ChangeStatus;
            }
          }
          $result = ['status' => 'success', 'status_message' => 'Catalogue working details updated successfully.'];
        } else {
          $result = ['status' => 'error', 'status_message' => 'Catalogue working details not updated successfully.'];
        }
      } catch (Exception $e) {
        $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      }
    } else {
      $result = ['status' => 'error', 'status_message' => 'Catalogue details not found.'];
    }
    $responseData = $jsondata;
    $node_Type    = 'bf_catalogue_assigning_user';
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'PATCH', $node_Type, $responseData, $userId, $result);
    return $result;
  }

  /**
   * Function :: Check and Change the status by other user login like client, team leader.
   */
  public function UpdateBriefingFormStatusByOtherUserType($jsondata) {
    $catalogueId    = $jsondata['field_bf_catalogue_id'];
    $pageStatus     = $jsondata['field_bf_page_status'];
    $pageDate       = $jsondata['field_bf_page_date'];
    $pageNo         = $jsondata['field_bf_pageno'];
    $userId         = $jsondata['field_bf_user_id'];
    $briefingFormID = $jsondata['field_briefingform_id'];
    /**
     * Check and update the status in bf catalogue assigning user page assignees by using catalogue id.
     */
    $GetCatAssignUserNodeId = $this->GetCatAssignUserNodeIdByParam($catalogueId, $pageStatus, $briefingFormID);
    if(isset($GetCatAssignUserNodeId['status'])) {
      return $GetCatAssignUserNodeId;
    } else {
      // Load node by node id.
      $BFNode = Node::load($briefingFormID);
      // update post status.
      $BFNode->set('field_briefing_form_status', $pageStatus);
      $BFNodeUpdate = $BFNode->save();
      if($BFNodeUpdate){
        return true;
      } else {
        return false;
      }
    }
  }

  /**
   * Function :: Check and update the status in bf catalogue assigning user page assignees by using catalogue id.
   */
  public function GetCatAssignUserNodeIdByParam($catalogueId, $pageStatus, $briefingFormID) {
    try{
      $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcpc.entity_id');
      $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'field_bf_catau_page_catalogue');
      $query->addField('nfd', 'nid', 'node_nid');
      $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
      $result = $query->execute()->fetchAll();
      if($result) {
        foreach($result as $res) {
          $bfcatasurNodeId = (isset($res->node_nid) &&!empty($res->node_nid))?$res->node_nid:null;
          if($bfcatasurNodeId) {
            // Load node by node id.
            $BFNode = Node::load($briefingFormID);
            $nodeTitle = $BFNode->field_briefing_catalogue_title->value;
            $node   = Node::load($bfcatasurNodeId);
            // Update post status.
            $node->set('field_bf_catau_page_status', $pageStatus);
            $update = $node->save();
            if($update) {
              $arrData = array(
                'type'                              => 'bf_cat_assigning_user_assignees',
                'title'                             => $nodeTitle,
                'field_bf_catau_page_catalogue'     => $catalogueId,
                'field_bfcatalogue_assigning_user'  => $node->field_bfcatalogue_assigning_user->target_id,
                'field_bf_catau_page_userid'        => $node->field_bf_catau_page_userid->target_id,
                'field_bf_catau_page_number'        => $node->field_bf_catau_page_number->value,
                'field_bf_catau_page_date'          => $node->field_bf_catau_page_date->value,
                'field_bf_catau_page_status'        => $pageStatus
              );
              // Save the POST request in BF Catalogue Assigning User Page Assignee's History content type.
              $jsonAssigneesHistoryData = json_encode($arrData, TRUE);
              // Inserting new node in BF Catalogue Assigning User Page Assignee's History.
              try{
                $nodeCreate = Node::create(array(
                  'type'                            => 'bf_cat_assuser_assignees_history',
                  'title'                           => $nodeTitle,
                  'field_bf_cataupageassignee_json' => $jsonAssigneesHistoryData,
                  'field_bf_cataupageassignee_nid'  => $bfcatasurNodeId
                ));
                $SaveNode = $nodeCreate->save();
                //$createNodeId = $SaveNode->id();
                if($SaveNode) {
                  return true;
                } else {
                  return false;
                }
              } catch (Exception $e) {
                $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                return $result;
              }
            }
          }
        }
        return true;
      } else {
        return false;
      }
    } catch (Exception $e) {
      $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
      return $result;
    }
  }

  /**
   * Function :: Check and Change the status by designer login.
   */
  public function UpdateBriefingFormStatusByDesigner($jsondata) {
    $catalogueId    = $jsondata['field_bf_catalogue_id'];
    $pageStatus     = $jsondata['field_bf_page_status'];
    $pageDate       = $jsondata['field_bf_page_date'];
    $pageNo         = $jsondata['field_bf_pageno'];
    $userId         = $jsondata['field_bf_user_id'];
    $briefingFormID = $jsondata['field_briefingform_id'];
    if(!empty($pageStatus) && ($pageStatus == '' && $pageStatus == '' && $pageStatus == ''))
    /**
     * Check the catalogue assigned page status by using catalogue id and user id for this designer.
     */
    $GetCatPageStatus = $this->CheckBFCatalogueAllAssignedPageStatus($catalogueId, $userId);
    if(!isset($GetCatPageStatus['status'])) {
      /** If the response is getting empty means all the pages are updated completed status.
      * Then have to check all the pages in given catalogue status is completed or not for other designer.
      */
      $GetAllCatPageStatus = $this->CheckBFCatalogueAllAssignedPageStatus($catalogueId, $user_id='');
      if(!isset($GetAllCatPageStatus['status'])) {
        /**
         * Check the catalogue all page status if completed means have to check the Briefingform Assets and Assets Communication content type.
         * And have to update the status to assets and communication content type.
         */
        //$updatestatus = $this->UpdateCatalogueAssetsStatusByParam($briefingFormID, $catalogueId);
        /**
         * Check briefing form dependent all catalogue pages are completed or not by using catalogue id and briefing form id.
         */
        $CheckAllBFCatPageStatus = $this->CheckAllBFCatPageStatusByParam($briefingFormID);
        if(!isset($CheckAllBFCatPageStatus['status'])) {
          /**
           * Check if the briefing form all catalogue pages are completed or not. 
           * If the all the catalogue pages is completed means, have to check the briefing form status is already has not in completed and the update the briefing form status as completed.
           */
          foreach($CheckAllBFCatPageStatus as $record){
            try {
              // Update the status.
              $assetEntityId = $record->node_nid;
              $node = Node::load($assetEntityId);
              /*if($pageStatus =='completed') {
                $node->set('field_briefing_form_status','completed');
              } else {
                $node->set('field_briefing_form_status','completed');
              }*/
              $node->set('field_briefing_form_status',$pageStatus);
              $update = $node->save();
              if($update) {
                $result = ['status' => 'success', 'status_message' => 'Catalogue page status updated successfully.'];
                return $result;
              } else {
                $result = ['status' => 'error', 'status_message' => 'Catalogue page status not updated successfully.'];
                return $result;
              }
            } catch (Exception $e) {
              $result = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
              return $result;
            }
          }
        } else if(isset($CheckAllBFCatPageStatus['status'])) {
          return $CheckAllBFCatPageStatus;
        } else {
          return true;
        }
      } else if(isset($GetAllCatPageStatus['status'])) {
        return $GetAllCatPageStatus;
      } else {
        return true;
      }
    } else if(isset($GetCatPageStatus['status'])) {
      return $GetCatPageStatus;
    } else {
      return true;
    }
  }

  /**
   * Function :: Get Current User Details.
   */
  public function GetCurrentUserDetails($loggedinUser) {
    $user = User::load($loggedinUser);
    return $user;
  }

  /**
  * Function :: Get node id of catalogue assign page.
  */
  public function GetNodeIdOfCatalogueAssignPage_old($catalogueId, $pageno) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'entity_id', 'cat_node_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcpn', 'entity_id', 'num_node_id');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'page_number');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
    $query->condition('nfbfcpn.field_bf_catau_page_number_value', $pageno);
    //$query->allowRowCount = TRUE;
    $result = $query->execute()->fetchAssoc();
    if(!empty($result)) {
      $nodeId = $result['cat_node_id'];
    } else {
      $nodeId = '';
    }
    return $nodeId;
  }

  /**
   * Function :: Check briefing form catalogue all assigned page status by param.
   */
  public function CheckBFCatalogueAllAssignedPageStatus_old($catalogueId, $userId) {
    try {
      // Select query.
      $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
      if(!empty($userId)) {
        $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
      }
      $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
      $query->addField('nfbfcpc', 'entity_id', 'node_id');
      $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'field_bf_catau_page_catalogue');
      if(!empty($userId)) {
        $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'field_bf_catau_page_userid');
      }
      $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'field_bf_catau_page_status');
      $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
      if(!empty($userId)) {
        $query->condition('nfbfcpu.field_bf_catau_page_userid_target_id', $userId);
      }
      $query->condition('nfbfcps.field_bf_catau_page_status_value', 'catalogue_completed', '!=');
      $query->allowRowCount = TRUE;
      $result = $query->execute()->fetchAll();
      if($result) {
        return $result;
      } else {
        return false;
      }
    } catch(\Exception $e){
      $result = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $result;
    }
  }

  /**
   * Function :: Update Briefing form assets and assets communication status by briefing id and catalogue id.
   */
  public function UpdateCatalogueAssetsStatusByParam($briefingFormID, $catalogueId) {
    try {
      // Select query.
      $query = \Drupal::database()->select('node__field_asset_briefingform_id', 'nfabfid');
      $query->leftjoin('node__field_bf_asset_catalogue_id', 'nfbfacid', 'nfbfacid.entity_id = nfabfid.entity_id');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfabfid.entity_id');
      $query->addField('nfabfid', 'field_asset_briefingform_id_target_id', 'field_asset_briefingform_id');
      $query->addField('nfbfacid', 'field_bf_asset_catalogue_id_target_id', 'field_bf_asset_catalogue_id');
      $query->addField('nfd', 'nid', 'node_nid');
      $query->condition('nfabfid.field_asset_briefingform_id_target_id', $briefingFormID);
      $query->condition('nfbfacid.field_bf_asset_catalogue_id_target_id', $catalogueId);
      $query->orderBy('nfbfcaid.entity_id', 'DESC');
      $query->range(0, 1);
      $query->allowRowCount = TRUE;
      $result = $query->execute()->fetchAssoc();
      if($result) {
        // Update the status.
        $assetEntityId = $result['node_nid'];
        $node = Node::load($assetEntityId);
        $node->set('type',$node1_type);
      } else {

      }
    } catch(\Exception $e){
      $result = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $result;
    }
  }

  /**
   * Function :: Check the all catalogue page status dependent to the briefing form id.
   */
  public function CheckAllBFCatPageStatusByParam($briefingFormID) {
    try {
      // Select query.
      $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->leftjoin('node__field_briefing_form_status', 'nfbfs', 'nfbfs.entity_id = nfd.nid');
      $query->addField('nfd', 'nid', 'node_nid');
      $query->addField('nfbfs', 'field_briefing_form_status_value', 'field_briefing_form_status');
      $query->condition('nfd.nid', $briefingFormID);
      $query->condition('nfbfs.field_briefing_form_status_value', 'completed', '!=');
      //$query->allowRowCount = TRUE;
      $result = $query->execute()->fetchAll();
      if($result) {
        return $result;
      } else {
        return false;
      }
    } catch(\Exception $e){
      $result = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $result;
    }
  }

  /**
  * Function :: #26 API for getting all the assigned users list (Designer, Team Leader, QC, To Proof) with full data for a catalogue.
  */
  public function GetFullCatalogueDetailsWithAssignedUserLists($catalogueId, $userID) {
    try{
      // Get Catalogue Data Using Client Id and Status.
      $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->leftjoin('group_content_field_data', 'gcfd', 'gcfd.entity_id = nfd.nid');
      $query->leftjoin('groups_field_data', 'gfd', 'gfd.id = gcfd.gid');
      $query->leftjoin('node__field_catalogue_active', 'nfcact', 'nfcact.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_client_email', 'nfccmail', 'nfccmail.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_client_name', 'nfccname', 'nfccname.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_image', 'nfcimg', 'nfcimg.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_start_date', 'nfcsd', 'nfcsd.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_finish_date', 'nfcfd', 'nfcfd.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_completion_date', 'nfccd', 'nfccd.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_prod_due_date', 'nfcpdd', 'nfcpdd.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_ref_name', 'nfcrf', 'nfcrf.entity_id = nfd.nid');
      $query->leftjoin('node__field_active_catalogue_title', 'nfact', 'nfact.entity_id = nfd.nid');
      //$query->leftjoin('node__field_catalogue_image_link', 'nfcil', 'nfcil.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_queue_count', 'nfcqc', 'nfcqc.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_carousel_image', 'nfcci', 'nfcci.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_portal', 'nfcp', 'nfcp.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_pagecount', 'nfcpc', 'nfcpc.entity_id = nfd.nid');
      $query->leftjoin('node__field_catalogue_status', 'nfcstatus', 'nfcstatus.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_reference_id', 'nfbfid', 'nfbfid.entity_id = nfd.nid');
      $query->leftjoin('group__field_background_color', 'gfbgc', 'gfbgc.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_text_color', 'gftc', 'gftc.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_carousel_type', 'gfctype', 'gfctype.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_client_override_css', 'gfcocss', 'gfcocss.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_catalogue_theme', 'gfct', 'gfct.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_thumbnail_position', 'gftp', 'gftp.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_client_ga', 'gfecga', 'gfecga.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_geo_location', 'gfegl', 'gfegl.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_title_color', 'gftcolor', 'gftcolor.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_quick_view_lightbox', 'gfqvl', 'gfqvl.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_full_view_icon', 'gfefvi', 'gfefvi.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_category_list', 'gfecl', 'gfecl.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_user_login_help_text', 'gfulht', 'gfulht.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_retailer_id', 'gfretid', 'gfretid.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_enable_geolocation_mapview', 'gfegmv', 'gfegmv.entity_id = gcfd.entity_id');
      $query->leftjoin('group__field_client_email', 'gfce', 'gfce.entity_id = gfd.id');
      $query->leftjoin('group__field_client_logo', 'gfclogo', 'gfclogo.entity_id = gfd.id');
      $query->addField('gcfd', 'id', 'gcfd_id');
      $query->addField('gcfd', 'gid', 'gcfd_group_id');
      $query->addField('gcfd', 'type', 'gcfd_type');
      $query->addField('gcfd', 'label', 'gcfd_label_username');
      $query->addField('gcfd', 'entity_id', 'gcfd_entity_userId');
      $query->addField('gfd', 'id', 'gfd_client_id');
      $query->addField('gfd', 'label', 'gfd_client_name');
      $query->addField('nfcact', 'field_catalogue_active_value', 'field_catalogue_active');
      $query->addField('nfccmail', 'field_catalogue_client_email_value', 'catalogue_client_email');
      $query->addField('nfccname', 'field_catalogue_client_name_value', 'catalogue_client_name');
      $query->addField('nfd', 'nid', 'nfd_catalogueID');
      $query->addField('nfd', 'type', 'nfd_type');
      $query->addField('nfd', 'title', 'nfd_catalogueName');
      $query->addField('nfd', 'uid', 'nfd_uid');
      $query->fields('nfcimg', array('field_catalogue_image_target_id', 'field_catalogue_image_alt', 'field_catalogue_image_title'));
      $query->addField('nfcsd', 'field_catalogue_start_date_value', 'field_catalogue_start_date');
      $query->addField('nfcfd', 'field_catalogue_finish_date_value', 'field_catalogue_finish_date');
      $query->addField('nfccd', 'field_catalogue_completion_date_value', 'field_catalogue_completion_date');
      $query->addField('nfcpdd', 'field_catalogue_prod_due_date_value', 'field_catalogue_production_due_date');
      $query->addField('nfcrf', 'field_catalogue_ref_name_value', 'field_catalogue_ref_name');
      $query->addField('nfact', 'field_active_catalogue_title_value', 'field_active_catalogue_title');
      //$query->fields('nfcil', array('field_catalogue_image_link_uri', 'field_catalogue_image_link_title'));
      $query->addField('nfcqc', 'field_catalogue_queue_count_value', 'field_catalogue_queue_count');
      $query->fields('nfcci', array('field_catalogue_carousel_image_uri', 'field_catalogue_carousel_image_title'));
      $query->addField('nfcp', 'field_catalogue_portal_value', 'field_catalogue_portal');
      $query->addField('nfbfid', 'field_briefing_form_reference_id_target_id', 'field_briefing_form_id');
      $query->addField('gfbgc', 'field_background_color_value', 'field_background_color');
      $query->addField('gftc', 'field_text_color_value', 'field_text_color');
      $query->addField('gfctype', 'field_carousel_type_value', 'field_carousel_type');
      $query->addField('gfcocss', 'field_client_override_css_value', 'field_client_override_css');
      $query->fields('gfct', array('field_catalogue_theme_value', 'field_catalogue_theme_format'));
      $query->addField('gftp', 'field_thumbnail_position_value', 'field_thumbnail_position');
      $query->addField('gfecga', 'field_enable_client_ga_value', 'field_enable_client_ga');
      $query->addField('gfegl', 'field_enable_geo_location_value', 'field_enable_geo_location');
      $query->addField('gftcolor', 'field_title_color_value', 'field_title_color');
      $query->fields('gfqvl', array('field_quick_view_lightbox_target_id', 'field_quick_view_lightbox_target_revision_id'));
      $query->addField('gfefvi', 'field_enable_full_view_icon_value', 'field_enable_full_view_icon');
      $query->addField('gfecl', 'field_enable_category_list_value', 'field_enable_category_list');
      $query->addField('gfulht', 'field_user_login_help_text_value', 'field_user_login_help_text');
      $query->addField('gfretid', 'field_retailer_id_value', 'field_retailer_id');
      $query->addField('gfegmv', 'field_enable_geolocation_mapview_value', 'field_enable_geolocation_mapview');
      $query->addField('nfcpc', 'field_catalogue_pagecount_value', 'field_catalogue_pagecount');
      $query->addField('nfcstatus', 'field_catalogue_status_value', 'field_catalogue_status');
      $query->addField('gfce', 'field_client_email_value', 'field_client_email');
      $query->addField('gfclogo', 'field_client_logo_target_id', 'field_client_logo_target_id');
      $query->condition('nfd.type', 'catalogue', '=');
      $query->condition('nfd.nid', $catalogueId, '=');
      $results = $query->execute()->fetchAssoc(); 
      $num_results = count($results);
      if(!empty($results)) {
        // Get quick view lightbox details by gid.
        $imagePath = '';
        $getQuickViewLightbox = $this->getQuickViewLightboxBygid($results['gcfd_group_id']);
        $image_path = $this->GetFileURLByFID($results['field_catalogue_image_target_id']);
        if(isset($image_path) && $image_path!='') {
          $imagePath = $image_path;
        } // !empty($field_bfcatregion_bf_id)?$field_bfcatregion_bf_id:null,
        $catId = !empty($results['nfd_catalogueID'])?$results['nfd_catalogueID']:null;
        // Get Client Logo.
        if(!empty($result['field_client_logo_target_id'])) {
          $logo_file  = File::load($result['field_client_logo_target_id']);
          $logouri    = $logo_file->getFileUri();
          $logo_uri   = file_create_url($logouri);
        } else {
          $logo_uri   = '';
        }
        // Get catalogue all pages in assigned user.
        $GetPages = $this->GetCatalogueAllPagesAssignedUserDetails($catId, $userID, $usertype ='');
        $arrData[] = array(
          'briefingform_id'                     => !empty($results['field_briefing_form_id'])?$results['field_briefing_form_id']:null,
          'title'                               => !empty($results['nfd_catalogueName'])?$results['nfd_catalogueName']:null,
          'field_catalogue_image'               => 'false',
          'image'                               => $imagePath,
          'field_catalogue_start_date'          => !empty($results['field_catalogue_start_date'])?$results['field_catalogue_start_date']:null,
          'field_catalogue_finish_date'         => !empty($results['field_catalogue_finish_date'])?$results['field_catalogue_finish_date']:null,
          'field_catalogue_completion_date'     => !empty($results['field_catalogue_completion_date'])?$results['field_catalogue_completion_date']:null,
          'field_catalogue_production_due_date' => !empty($results['field_catalogue_production_due_date'])?$results['field_catalogue_production_due_date']:null,
          'nid_1'                               => !empty($results['nfd_catalogueID'])?$results['nfd_catalogueID']:null,
          'share'                               => !empty($results['field_catalogue_ref_name'])?$results['field_catalogue_ref_name']:null,
          'field_catalogue_queue_count'         => !empty($results['field_catalogue_queue_count'])?$results['field_catalogue_queue_count']:null,
          'field_active_catalogue_title'        => !empty($results['field_active_catalogue_title'])?$results['field_active_catalogue_title']:null,
          'field_text_color'                    => !empty($results['field_text_color'])?$results['field_text_color']:null,
          'field_carousel_type'                 => !empty($results['field_carousel_type'])?$results['field_carousel_type']:null,
          'field_client_override_css'           => !empty($results['field_client_override_css'])?$results['field_client_override_css']:null,
          'field_catalogue_theme'               => !empty($results['field_catalogue_theme_value'])?$results['field_catalogue_theme_value']:null,
          'field_thumbnail_position'            => !empty($results['field_thumbnail_position'])?$results['field_thumbnail_position']:null,
          'field_enable_client_ga'              => !empty($results['field_enable_client_ga'])?$results['field_enable_client_ga']:null,
          'field_background_color'              => !empty($results['field_background_color'])?$results['field_background_color']:null,
          'field_background_color_1'            => !empty($results['field_background_color'])?$results['field_background_color']:null,
          'field_enable_geo_location'           => !empty($results['field_enable_geo_location'])?$results['field_enable_geo_location']:null,
          'field_title_color'                   => !empty($results['field_title_color'])?$results['field_title_color']:null,
          'field_catalogue_carousel_image'      => !empty($results['field_catalogue_carousel_image_uri'])?$results['field_catalogue_carousel_image_uri']:null,
          'field_enable_full_view_icon'         => !empty($results['field_enable_full_view_icon'])?$results['field_enable_full_view_icon']:null,
          'field_enable_category_list'          => !empty($results['field_enable_category_list'])?$results['field_enable_category_list']:null,
          'field_user_login_help_text'          => !empty($results['field_user_login_help_text'])?$results['field_user_login_help_text']:null,
          'field_retailer_id'                   => !empty($results['field_retailer_id'])?$results['field_retailer_id']:null,
          'domain'                              => null,
          'field_quick_view_lightbox'           => $getQuickViewLightbox,
          'field_enable_geolocation_mapview'    => !empty($results['field_enable_geolocation_mapview'])?$results['field_enable_geolocation_mapview']:null,
          'field_catalogue_portal'              => !empty($results['field_catalogue_portal'])?$results['field_catalogue_portal']:null,
          'field_catalogue_page'                => !empty($results['field_catalogue_pagecount'])?$results['field_catalogue_pagecount']:null,
          'field_catalogue_status'              => !empty($results['field_catalogue_status'])?$results['field_catalogue_status']:null,
          'field_catalogue_client_id'           => !empty($results['gfd_client_id'])?$results['gfd_client_id']:null,
          'field_catalogue_client_logo'         => $logo_uri,
          'field_catalogue_client_name'         => !empty($results['gfd_client_name'])?$results['gfd_client_name']:null,
          'field_catalogue_client_email'        => !empty($results['field_client_email'])?$results['field_client_email']:null,
          'field_page_assignees'                => $GetPages,
        );
        return $arrData;
      } else {
        $result = ['status' => 'error', 'status_message' => 'Catalogue details not found.'];
        return $result;
      }
    } catch(\Exception $e){
      $result = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $result;
    }
  }

  /**
  * Function :: Get catalogue all pages with assigned user details by using catalogue id.
  */
  public function GetCatalogueAllPagesAssignedUserDetails($catalogueId, $userID, $usertype) {
    try{
      // Select query.
      $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
      $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
      $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfbfcpu.field_bf_catau_page_userid_target_id');
      $query->addField('nfbfcpc', 'entity_id', 'entity_id');
      $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
      $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'catalogue_page_date');
      $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catalogue_page_number');
      $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catalogue_page_status');
      $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'catalogue_page_userid');
      $query->addField('nfbfcaur', 'field_bf_catau_assigng_user_role_value', 'catalogue_page_assigng_user_role');
      $query->addField('ufd', 'name', 'username');
      $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueId);
      if(isset($usertype) && !empty($usertype) && ($usertype=='client' || $usertype=='operator') && !empty($userID)) { // Designer.
        $query->condition('nfbfcpu.field_bf_catau_page_userid_target_id', $userID);
      }
      if(isset($usertype) && !empty($usertype) && ($usertype=='operator') && !empty($userID)) { // Designer.
        $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', 'operator'); // Designer.
      } else if(isset($usertype) && !empty($usertype) && ($usertype=='supervisor') && !empty($userID)) { // Quality Assurance.
        $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', 'supervisor'); // Quality Assurance.
      } else if(isset($usertype) && !empty($usertype) && ($usertype=='leader') && !empty($userID)) { // Quality Assurance.
        $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', 'poc_user', '!='); // Quality Assurance.
      }
      $query->orderBy('nfbfcpn.field_bf_catau_page_number_value', 'ASC');
      $query->allowRowCount = TRUE;
      $result = $query->execute()->fetchAll();
      if(!empty($result)){
        foreach($result as $res) {
          if(!empty($res->catalogue_page_date) && ($res->catalogue_page_date != '0000-00-00' || $res->catalogue_page_date != '0000-00-00T00:00:00')) {
            //$pageDate = date('d-m-Y', strtotime($res->catalogue_page_date));
            $pageDate = date('Y-m-d\TH:i:s', strtotime($res->catalogue_page_date));
          } else {
            $pageDate = null;
          }
          $arrData[]  = array(
            'catalogue_assigng_user_role' => $res->catalogue_page_assigng_user_role,
            'catalogue_page_status'       => $res->catalogue_page_status,
            'catalogue_page_number'       => $res->catalogue_page_number,
            'catalogue_page_date'         => $pageDate,
            'catalogue_page_entityid'     => $res->entity_id,
            'catalogue_id'                => $res->catalogue_id,
            'assigned_userid'             => $res->catalogue_page_userid,
            'assigned_user_fullname'      => $res->username,
            'assigned_user_shortname'     => $this->GetAssignedUserName($res->username)
          );
        }
      } else {
        $arrData = array();  
      }
    } catch(\Exception $e){
      $arrData = array();
    }
    return $arrData;
  }

  public function GetAssignedUserName($username){
    if(!empty($username)){
      $SpaceUsername 	    = explode(' ', trim($username));
      $UnderscoreUsername = explode('_', trim($username));
      $HyphenUsername 	  = explode('-', trim($username));
      $user_Name          = '';
      // Space seperated.
      if(count($SpaceUsername)>1){
        $fname      = substr($SpaceUsername[0], 0, 1);
        $lname      = substr($SpaceUsername[1], 0, 1);
        $user_Name  = strtoupper($fname.$lname);
      }
      // underscore seperated.
      if(count($UnderscoreUsername)>1){
        $fname      = substr($UnderscoreUsername[0], 0, 1);
        $lname      = substr($UnderscoreUsername[1], 0, 1);
        $user_Name  = strtoupper($fname.$lname);
      }
      // Hyphen seperated.
      if(count($HyphenUsername)>1){
        $fname      = substr($HyphenUsername[0], 0, 1);
        $lname      = substr($HyphenUsername[1], 0, 1);
        $user_Name  = strtoupper($fname.$lname);
      }
      // Check Space, Underscore, Hyphen is empty. Given name is single word.
      if((count($SpaceUsername)==1) && (count($UnderscoreUsername)==1) && (count($HyphenUsername)==1)){
        $user_Name  = strtoupper(substr($username, 0, 2));
      }
      return $user_Name;
    } else {
      return null;
    }
  }

  /**
  * Function :: 31 API for updating the catalogue completion date and production due date using briefing form id and catalogue id.
  */
  /*public function PatchBFCatalogueCompletionDateProductionDueDate($jsondata) {

    $briefingformID    = !empty($jsondata['field_briefingform_id'])?$jsondata['field_briefingform_id']:null;
    $catalogueID       = !empty($jsondata['field_catalogue_id'])?$jsondata['field_catalogue_id']:null;
    $completionDate    = !empty($jsondata['field_catalogue_completion_date'])?$jsondata['field_catalogue_completion_date']:null;
    $productionDueDate = !empty($jsondata['field_catalogue_prod_due_date'])?$jsondata['field_catalogue_prod_due_date']:null;
    // Catalogue completion date.
    $completionDates = date('Y-m-d', strtotime($completionDate));
    $completion_Date = $completionDates.'T00:00:00';
    // Catalogue production due date.
    $productionDueDates = date('Y-m-d', strtotime($productionDueDate));
    $production_DueDate = $productionDueDates.'T00:00:00';
    // Load catalogue by node id
    $node = Node::load($catalogueID);
    $node->set('field_catalogue_completion_date', $completion_Date);
    $node->set('field_catalogue_prod_due_date', $production_DueDate);
    $update = $node->save();
    if($update) {
      $result = ['status' => 'success', 'status_message' => 'Briefing form catalogue completion date and production due date details updated successfully.'];
    } else {
      $result = ['status' => 'error', 'status_message' => 'Briefing form catalogue completion date and production due date details not updated successfully. Please try after some times.'];
    }
    return $result;
  }*/

  /**
  * Function :: 32 API for getting all the briefing form full details with assets using briefing form id.
  */
  public function GetBFFullDetailsByParam($briefingformID, $userID, $userType) {
    $nodeType = 'briefingform';
    try{
      $query = \Drupal::database()->select('node_field_data', 'nfd');
      $query->leftjoin('node__field_briefing_form_animation_re', 'nfear', 'nfear.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_author', 'nfbfa', 'nfbfa.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_status', 'nfbfs', 'nfbfs.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_catalogue_title', 'nfct', 'nfct.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_ecommerce_re', 'nfecc', 'nfecc.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_final_catalogue_output', 'nffco', 'nffco.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_live_from_date', 'nfbflfd', 'nfbflfd.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_live_to_date', 'nfbfltd', 'nfbfltd.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_multiple_ver', 'nfemv', 'nfemv.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_preview_date', 'nfpd', 'nfpd.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_term_and_conditions', 'nftac', 'nftac.entity_id = nfd.nid');
      $query->leftjoin('node__field_briefing_form_client_id', 'nfbfcid', 'nfbfcid.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_catalogue_section', 'nfbfcsec', 'nfbfcsec.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_special_instructions', 'nfbfspin', 'nfbfspin.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_completion_date', 'nfbfcd', 'nfbfcd.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_production_due_date', 'nfbfpdd', 'nfbfpdd.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_qa_date', 'nfbfqad', 'nfbfqad.entity_id = nfd.nid');
      $query->leftjoin('node__field_bf_catalogue_portal', 'nfbfcp', 'nfbfcp.entity_id = nfd.nid');
      $query->leftjoin('users', 'users', 'users.uid = nfd.uid');
      $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfd.uid');
      $query->fields('nfd', array('nid', 'type', 'title', 'uid','created', 'changed'));
      $query->fields('nfear', array('field_briefing_form_animation_re_value'));
      $query->fields('nfbfa', array('field_briefing_form_author_target_id'));
      $query->fields('nfbfs', array('field_briefing_form_status_value'));
      $query->fields('nfct', array('field_briefing_catalogue_title_value'));
      $query->fields('nfecc', array('field_briefing_form_ecommerce_re_value'));
      $query->fields('nffco', array('field_bf_final_catalogue_output_value'));
      $query->fields('nfbflfd', array('field_bf_live_from_date_value'));
      $query->fields('nfbfltd', array('field_bf_live_to_date_value'));
      $query->fields('nfemv', array('field_briefing_form_multiple_ver_value'));
      $query->fields('nfpd', array('field_briefing_form_preview_date_value'));
      $query->fields('nftac', array('field_bf_term_and_conditions_value'));
      $query->fields('nfbfcid', array('field_briefing_form_client_id_target_id'));
      $query->fields('nfbfcsec', array('field_bf_catalogue_section_value'));
      $query->fields('nfbfspin', array('field_bf_special_instructions_value'));
      $query->fields('nfbfcd', array('field_bf_completion_date_value'));
      $query->fields('nfbfpdd', array('field_bf_production_due_date_value'));
      $query->fields('nfbfqad', array('field_bf_qa_date_value'));
      $query->fields('nfbfcp', array('field_bf_catalogue_portal_value'));
      $query->fields('ufd', array('name','uid'));
      $query->condition('nfd.type', $nodeType);
      $query->condition('nfd.nid', $briefingformID);
      //$query->condition('nfd.uid', $userID);
      $GetBFData = $query->execute()->fetchAssoc();
      if($GetBFData) {
        // Briefing form id.
        $bfID                   = $GetBFData['nid'];
        // Client id.
        $clientId               = !empty($GetBFData['field_briefing_form_client_id_target_id']) && !is_null($GetBFData['field_briefing_form_client_id_target_id'])?$GetBFData['field_briefing_form_client_id_target_id']:null;
        // Get BF author name by target id.
        $bf_author              = $this->GetBFAuthorNameById($GetBFData['field_briefing_form_author_target_id']);
        // Merge Live From Date and To Date.
        $liveFromDates          = !is_null($GetBFData['field_bf_live_from_date_value'])?$GetBFData['field_bf_live_from_date_value']:null;
        $liveFromDate           = date('Y-m-d\TH:i:s', strtotime($liveFromDates));
        $liveToDates            = !is_null($GetBFData['field_bf_live_to_date_value'])?$GetBFData['field_bf_live_to_date_value']:null;
        $liveToDate             = date('Y-m-d\TH:i:s', strtotime($liveToDates));
        $liveDate               = $liveFromDate.' - '.$liveToDate;
        // Convert preview date.
        $preview_dates          = !is_null($GetBFData['field_briefing_form_preview_date_value'])?$GetBFData['field_briefing_form_preview_date_value']:null;
        $preview_dates_utc      = new \DateTime($preview_dates, new \DateTimeZone('UTC'));
        $previewDate            = $preview_dates_utc->format('Y-m-d\TH:i:s');
        // Load Group.
        $groups = Group::load($clientId);
        $client_time            = $groups->field_client_time->value;
        $client_timeZone        = ($client_time != Null) ? $client_time : 'UTC';
        // Load User.
        $user_detail            = \Drupal\user\Entity\User::load($GetBFData['uid']);
        $user_timezone          = $user_detail->timezone->value;
        // Node created date & time.
        $created                = date('Y-m-d\TH:i:s', $GetBFData['created']);
        $createdDateTime        = convertDateFromTimezone($created, $user_timezone, $client_timeZone, 'Y-m-d\TH:i:s');
        $arraySet = array(
          'client_time' => $client_time, 
          'client_timeZone' => $client_timeZone, 
          'user_timezone' => $user_timezone, 
          'created' => $created,
          'createdDateTime' => $createdDateTime
        );
        $resultset = json_encode($arraySet);
        // Node udated date & time.
        $changed                = date('Y-m-d\TH:i:s', $GetBFData['changed']);
        $updatedDateTime        = convertDateFromTimezone($changed, $user_timezone, $client_timeZone, 'Y-m-d\TH:i:s');
        $arraySet1 = array(
          'client_time' => $client_time, 
          'client_timeZone' => $client_timeZone, 
          'user_timezone' => $user_timezone, 
          'changed' => $changed,
          'updatedDateTime' => $updatedDateTime
        );
        $resultset1 = json_encode($arraySet1);
        $resultset2 = $resultset.' - '.$resultset1;
        \Drupal::logger('API-32-date&timezone')->notice('@resultset2', [
          '@resultset2' => $resultset2
        ]);
        // Get global assets (briefing form assets - client).
        $GetClientAssets        = $this->GetBriefingFormAssetsByBFID($bfID, $type ='client');
        // Get catalogue assets by briefing form id.
        $GeCatalogueAssets      = $this->GeCatalogueAssetsByBFID($bfID, $type ='catalogue', $userType);
        // Get Client name and email address.
        $GetClientDetails       = $this->GetClientDetailsByParam($GetBFData['field_briefing_form_client_id_target_id']);
        // $query->leftjoin('group__field_client_email', 'gfce', 'gfce.entity_id = gfd.id');
        // catalogue completion date.
        $cataloguecompletedate  = !is_null($GetBFData['field_bf_completion_date_value'])?$GetBFData['field_bf_completion_date_value']:null;
        // Production due date.
        $productionduedate      = !is_null($GetBFData['field_bf_production_due_date_value'])?$GetBFData['field_bf_production_due_date_value']:null;
        // Q A Date.
        $QAdate                 = !is_null($GetBFData['field_bf_qa_date_value'])?$GetBFData['field_bf_qa_date_value']:null;
        $arrData = array(
          'briefingform_id'                   => $bfID,
          'briefingform_title'                => !empty($GetBFData['title']) && !is_null($GetBFData['title'])?$GetBFData['title']:null,
          'field_briefing_form_author'        => $bf_author,
          'field_briefing_form_status'        => !empty($GetBFData['field_briefing_form_status_value']) && !is_null($GetBFData['field_briefing_form_status_value'])?$GetBFData['field_briefing_form_status_value']:null,
          'field_briefing_form_created_date'  => $createdDateTime,
          'field_briefing_form_changed_date'  => $updatedDateTime,
          'field_bf_catalogue_section'        => !empty($GetBFData['field_bf_catalogue_section_value']) && !is_null($GetBFData['field_bf_catalogue_section_value'])?$GetBFData['field_bf_catalogue_section_value']:null,
          'field_catalogue_client_id'         => $clientId,
          'field_catalogue_client_name'       => !empty($GetClientDetails->label()) && !is_null($GetClientDetails->label())?$GetClientDetails->label():null,
          'field_catalogue_client_email'      => !empty($GetClientDetails->field_client_email->value) && !is_null($GetClientDetails->field_client_email->value)?$GetClientDetails->field_client_email->value:null,
          'field_preview_date'                => $previewDate,
          'field_live_dates'                  => $liveDate,
          'field_catalogue_completion_date'   => $cataloguecompletedate,
          'field_catalogue_prod_due_date'     => $productionduedate,
          'field_bf_qa_date'                  => $QAdate,
          //'field_catalogue_submitted_date'  => ,
          'field_enable_catalogue_ecommerce'  => !empty($GetBFData['field_briefing_form_ecommerce_re_value']) && !is_null($GetBFData['field_briefing_form_ecommerce_re_value'])?$GetBFData['field_briefing_form_ecommerce_re_value']:null,
          'field_final_catalogue_output'      => !empty($GetBFData['field_bf_final_catalogue_output_value']) && !is_null($GetBFData['field_bf_final_catalogue_output_value'])?$GetBFData['field_bf_final_catalogue_output_value']:null,
          'field_enable_animation_required'   => !empty($GetBFData['field_briefing_form_animation_re_value']) && !is_null($GetBFData['field_briefing_form_animation_re_value'])?$GetBFData['field_briefing_form_animation_re_value']:null,
          'field_term_and_conditions'         => !empty($GetBFData['field_bf_term_and_conditions_value']) && !is_null($GetBFData['field_bf_term_and_conditions_value'])?$GetBFData['field_bf_term_and_conditions_value']:null,
          'field_special_instructions'        => !empty($GetBFData['field_bf_special_instructions_value']) && !is_null($GetBFData['field_bf_special_instructions_value'])?$GetBFData['field_bf_special_instructions_value']:null,
          'field_briefing_form_multiple_ver'  => !empty($GetBFData['field_briefing_form_multiple_ver_value']) && !is_null($GetBFData['field_briefing_form_multiple_ver_value'])?$GetBFData['field_briefing_form_multiple_ver_value']:null,
          'field_bf_catalogue_portal'         => !empty($GetBFData['field_bf_catalogue_portal_value']) && !is_null($GetBFData['field_bf_catalogue_portal_value'])?$GetBFData['field_bf_catalogue_portal_value']:null,
          'field_global_assets_files'         => $GetClientAssets,
          'field_catalog_assets_files'        => $GeCatalogueAssets,
        );
        return $arrData;
      } else {
        $result = ['status' => 'error', 'status_message' => 'Briefing form details not found. Please check the request details and try.'];
      }
    } catch (Exception $e) {
      $response = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
    }
    // Load Briefing form data from briefing form node id.
    /*$GetBFData = Node::load($briefingformID);
    if($GetBFData) {
      // Briefing form id.
      $bfID = $GetBFData->id();
      // Get BF author name by target id.
      $bf_author = $this->GetBFAuthorNameById($GetBFData->field_briefing_form_author->target_id);
      // Merge Live From Date and To Date.
      $liveFromDates  = !is_null($GetBFData->field_bf_live_from_date->value)?$GetBFData->field_bf_live_from_date->value:null;
      $liveFromDate   = date('d/m/Y', strtotime($liveFromDates));
      $liveToDates    = !is_null($GetBFData->field_bf_live_to_date->value)?$GetBFData->field_bf_live_to_date->value:null;
      $liveToDate     = date('d/m/Y', strtotime($liveToDates));
      $liveDate       = $liveFromDate.' - '.$liveToDate;
      // Convert preview date.
      $preview_dates          = !is_null($GetBFData->field_briefing_form_preview_date->value)?$GetBFData->field_briefing_form_preview_date->value:null;
      $preview_dates_utc      = new \DateTime($preview_dates, new \DateTimeZone('UTC'));
      $previewDate            = $preview_dates_utc->format('d/m/Y');
      // Node created date & time.
      $createdDate            = date('d/m/Y h:i:s', $GetBFData->created->value);
      // Node updated date & time.
      $updatedDate            = date('d/m/Y h:i:s', $GetBFData->changed->value);
      // Get global assets (briefing form assets - client).
      $GetClientAssets        = $this->GetBriefingFormAssetsByBFID($bfID, $type ='client');
      // Get catalogue assets by briefing form id.
      $GeCatalogueAssets      = $this->GeCatalogueAssetsByBFID($bfID, $type ='catalogue');
      // Get Client name and email address.
      $GetClientDetails       = $this->GetClientDetailsByParam($GetBFData->field_briefing_form_client_id->target_id);
      // $query->leftjoin('group__field_client_email', 'gfce', 'gfce.entity_id = gfd.id');
      // catalogue completion date.
      $cataloguecompletedate  = !is_null($GetBFData->field_bf_completion_date->value)?$GetBFData->field_bf_completion_date->value:null;
      // Production due date.
      $productionduedate      = !is_null($GetBFData->field_bf_production_due_date->value)?$GetBFData->field_bf_production_due_date->value:null;
      // 
      $QAdate                 = !is_null($GetBFData->field_bf_qa_date->value)?$GetBFData->field_bf_qa_date->value:null;
      $arrData = array(
        'briefingform_id'                   => $bfID,
        'briefingform_title'                => !empty($GetBFData->field_briefing_form_title->value) && !is_null($GetBFData->field_briefing_form_title->value)?$GetBFData->field_briefing_form_title->value:null,
        'field_briefing_form_author'        => $bf_author,
        'field_briefing_form_status'        => !empty($GetBFData->field_briefing_form_status->value) && !is_null($GetBFData->field_briefing_form_status->value)?$GetBFData->field_briefing_form_status->value:null,
        'field_briefing_form_created_date'  => $GetBFData->created->value,
        'field_briefing_form_changed_date'  => $GetBFData->changed->value,
        'field_bf_catalogue_section'        => !empty($GetBFData->field_bf_catalogue_section->value) && !is_null($GetBFData->field_bf_catalogue_section->value)?$GetBFData->field_bf_catalogue_section->value:null,
        'field_catalogue_client_id'         => !empty($GetBFData->field_briefing_form_client_id->target_id) && !is_null($GetBFData->field_briefing_form_client_id->target_id)?$GetBFData->field_briefing_form_client_id->target_id:null,
        'field_catalogue_client_name'       => !empty($GetClientDetails->label()) && !is_null($GetClientDetails->label())?$GetClientDetails->label():null,
        'field_catalogue_client_email'      => !empty($GetClientDetails->field_client_email->value) && !is_null($GetClientDetails->field_client_email->value)?$GetClientDetails->field_client_email->value:null,
        'field_preview_date'                => $previewDate,
        'field_live_dates'                  => $liveDate,
        'field_catalogue_completion_date'   => $cataloguecompletedate,
        'field_catalogue_prod_due_date'     => $productionduedate,
        'field_bf_qa_date'                  => $QAdate,
        //'field_catalogue_submitted_date'  => ,
        'field_enable_catalogue_ecommerce'  => !empty($GetBFData->field_briefing_form_ecommerce_re->value) && !is_null($GetBFData->field_briefing_form_ecommerce_re->value)?$GetBFData->field_briefing_form_ecommerce_re->value:null,
        'field_final_catalogue_output'      => !empty($GetBFData->field_bf_final_catalogue_output->value) && !is_null($GetBFData->field_bf_final_catalogue_output->value)?$GetBFData->field_bf_final_catalogue_output->value:null,
        'field_enable_animation_required'   => !empty($GetBFData->field_briefing_form_animation_re->value) && !is_null($GetBFData->field_briefing_form_animation_re->value)?$GetBFData->field_briefing_form_animation_re->value:null,
        'field_term_and_conditions'         => !empty($GetBFData->field_bf_term_and_conditions->value) && !is_null($GetBFData->field_bf_term_and_conditions->value)?$GetBFData->field_bf_term_and_conditions->value:null,
        'field_special_instructions'        => !empty($GetBFData->field_bf_special_instructions->value) && !is_null($GetBFData->field_bf_special_instructions->value)?$GetBFData->field_bf_special_instructions->value:null,
        'field_briefing_form_multiple_ver'  => !empty($GetBFData->field_briefing_form_multiple_ver->value) && !is_null($GetBFData->field_briefing_form_multiple_ver->value)?$GetBFData->field_briefing_form_multiple_ver->value:null,
        'field_global_assets_files'         => $GetClientAssets,
        'field_catalog_assets_files'        => $GeCatalogueAssets,
      );
      return $arrData;
    } else {
      return false;
    }*/
  }

  public function GetBFAuthorNameById($userID) {
    $account = \Drupal\user\Entity\User::load($userID); // pass your uid
    return $name = $account->getUsername();
  }

  public function GetClientDetailsByParam($clientID) {
    $Group = \Drupal\group\Entity\Group::load($clientID);
    return $Group;
  }

  /**
  * Function for get all asset data by using asset type and briefing form Id.
  **/
  public function GetBriefingFormAssetsByBFID($BriefingFormID, $type) {
    // S3 Bucket settings.
    $config = \Drupal::config('s3fs.settings');
    $s3config = $config->get();
    $domain = UrlHelper::filterBadProtocol($s3config['domain']);
    $pdf_path = '';
    // Assets Briefing Form Node Name.
    $nodeType = 'briefingform_assets';
    // Select Query.
    $query = \Drupal::database()->select('node__field_asset_briefingform_id', 'nfabfid');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_asset_comments', 'nfbf_ac', 'nfbf_ac.entity_id = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_asset_id', 'nfbf_aid', 'nfbf_aid.entity_id = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_asset_type_id', 'nfbf_atid', 'nfbf_atid.entity_id = nfabfid.entity_id');
    $query->leftjoin('node__field_bf_form_type', 'nfbf_ft', 'nfbf_ft.entity_id = nfabfid.entity_id');
    $query->addField('nfd', 'nid', 'briefingform_asset_nid');
    $query->addField('nfd', 'type', 'node_type');
    $query->addField('nfd', 'title', 'node_title');
    $query->addField('nfd', 'uid', 'briefingform_userid');
    $query->addField('nfabfid', 'field_asset_briefingform_id_target_id', 'field_asset_briefingform_id');
    //$query->addField('nfabfid', 'entity_id', 'nfabfid.entity_id');
    $query->addField('nfbf_ac', 'field_bf_asset_comments_value', 'field_bf_asset_comments');
    $query->addField('nfbf_aid', 'field_bf_asset_id_value', 'field_bf_asset_id');
    $query->addField('nfbf_atid', 'field_bf_asset_type_id_target_id', 'field_bf_asset_type_id');
    $query->addField('nfbf_ft', 'field_bf_form_type_value', 'field_bf_form_type');
    //$query->condition('nfd.type', $nodeType);
    //$query->condition('nfd.uid', $userID);
    $query->condition('nfbf_ft.field_bf_form_type_value', $type);
    $query->condition('nfabfid.field_asset_briefingform_id_target_id', $BriefingFormID);
    $query->orderBy('nfabfid.entity_id', 'ASC');
    $results = $query->execute()->fetchAll();
    if(!empty( $results )){
      foreach($results as $res) {
        $field_assets_fid = $res->field_bf_asset_id;
        $file_path        = ''; 
        $filename         = '';
        $filesize         = '';
        if($field_assets_fid) {
          $file 	        = File::load($field_assets_fid);
          $file_uri 	    = $file->getFileUri();
          $file_path      = file_create_url($file_uri);
          $filename       = $file->getFilename();
          $filesize       = $file->getSize();
          /*$path_explode   = explode("s3:/",$file_uri);
          if(!empty($path_explode) && $path_explode[1] != ""){
            $file_path    = str_replace('s3:/','https://' . $domain, $file_uri);
          }else{
            $file_path    = str_replace('private:/','https://' . $domain, $file_uri);
          }*/
        }
        $arrData[] = array(
          'field_assets_nid'        => $res->briefingform_asset_nid,
          'field_assets_bf_id'      => $res->field_asset_briefingform_id,
          'field_form_type'         => $res->field_bf_form_type,
          'field_assets_fid'        => $res->field_bf_asset_id,
          'field_assets_filename'   => $filename,
          'field_assets_file'       => $file_path,
          'field_assets_filesize'   => $filesize,
          'field_asset_notes'       => $res->field_bf_asset_comments,
        );
      }
      return $arrData;
    } else {
      $arrData = array();
      return $arrData;
    }
  }

  /**
  * Function for get all asset data by using asset type and briefing form Id.
  **/
  public function GeCatalogueAssetsByBFID($BriefingFormID, $type, $userType) {
    // S3 Bucket settings.
    $config   = \Drupal::config('s3fs.settings');
    $s3config = $config->get();
    $domain   = UrlHelper::filterBadProtocol($s3config['domain']);
    $pdf_path = '';
    // Get briefing form assets communication data's by bf id and bf asset id.
    $query1 = \Drupal::database()->select('node__field_asset_briefingform_id', 'nfabfid');
    $query1->leftjoin('node__field_bf_asset_catalogue_id', 'nfbfacid', 'nfbfacid.entity_id = nfabfid.entity_id');
    $query1->leftjoin('node__field_bf_asset_comments', 'nfbfac', 'nfbfac.entity_id = nfabfid.entity_id');
    $query1->leftjoin('node__field_bf_asset_error_pages', 'nfbfaep', 'nfbfaep.entity_id = nfabfid.entity_id');
    $query1->leftjoin('node__field_bf_asset_id', 'nfbfaid', 'nfbfaid.entity_id = nfabfid.entity_id');
    $query1->leftjoin('node__field_bf_asset_status', 'nfbfas', 'nfbfas.entity_id = nfabfid.entity_id');
    $query1->leftjoin('node__field_bf_asset_total_pages', 'nfbfatp', 'nfbfatp.entity_id = nfabfid.entity_id');
    $query1->leftjoin('node__field_bf_asset_type_id', 'nfbfatyid', 'nfbfatyid.entity_id = nfabfid.entity_id');
    $query1->leftjoin('node__field_briefing_form_assets_type', 'nfbfat', 'nfbfat.entity_id = nfbfatyid.field_bf_asset_type_id_target_id');
    $query1->leftjoin('node__field_bf_form_type', 'nfbfty', 'nfbfty.entity_id = nfabfid.entity_id');
    $query1->leftjoin('node_field_data', 'nfd','nfd.nid = nfabfid.entity_id');
    $query1->leftjoin('node_field_data', 'nfd_cat','nfd_cat.nid = nfbfacid.field_bf_asset_catalogue_id_target_id');
    $query1->leftjoin('node__field_catalogue_ref_name', 'nfcrn', 'nfcrn.entity_id = nfbfacid.field_bf_asset_catalogue_id_target_id');
    $query1->leftjoin('node__field_catalogue_pdfhash', 'nfcpdfhash', 'nfcpdfhash.entity_id = nfbfacid.field_bf_asset_catalogue_id_target_id');
    $query1->addField('nfabfid', 'entity_id', 'field_asset_id');
    $query1->addField('nfabfid', 'field_asset_briefingform_id_target_id', 'field_briefringform_id');
    $query1->addField('nfbfacid', 'field_bf_asset_catalogue_id_target_id', 'field_catalogue_id');
    $query1->addField('nfbfac', 'field_bf_asset_comments_value', 'field_bf_asset_comments');
    $query1->addField('nfbfaep', 'field_bf_asset_error_pages_value', 'field_bf_asset_error_pages');
    $query1->addField('nfbfaid', 'field_bf_asset_id_value', 'field_bf_asset_fid');
    $query1->addField('nfbfas', 'field_bf_asset_status_value', 'field_bf_asset_status');
    $query1->addField('nfbfatp', 'field_bf_asset_total_pages_value', 'field_bf_asset_total_pages');
    $query1->addField('nfbfatyid', 'field_bf_asset_type_id_target_id', 'field_bf_asset_type_id');
    $query1->addField('nfbfat', 'field_briefing_form_assets_type_value', 'field_bf_asset_type');
    $query1->addField('nfbfty', 'field_bf_form_type_value', 'field_bf_form_type');
    $query1->addField('nfd', 'type', 'node_type');
    $query1->addField('nfd', 'title', 'node_title');
    $query1->addField('nfd_cat', 'title', 'field_catalogue_name');
    $query1->addField('nfcrn', 'field_catalogue_ref_name_value', 'field_catalogue_ref_name');
    $query1->addField('nfcpdfhash', 'field_catalogue_pdfhash_value', 'field_catalogue_pdfhash');
    $query1->condition('nfabfid.field_asset_briefingform_id_target_id', $BriefingFormID);
    $query1->condition('nfbfty.field_bf_form_type_value', 'catalogue');
    $query1->orderBy('nfabfid.entity_id', 'DEC');
    $query1->allowRowCount = TRUE;
    $getBFAssets = $query1->execute()->fetchAll();
    if($getBFAssets) {
      foreach($getBFAssets as $res) {
        $briefingFormID       = $res->field_briefringform_id;
        $catalogueID          = $res->field_catalogue_id;
        $GetAssetsCom         = $this->GetBFAssetsCommunicationByParam($res->field_briefringform_id, $res->field_asset_id);
        $BFAssetTotalPages    = isset($GetAssetsCom['field_bf_com_assets_total_pages']) && !empty($GetAssetsCom['field_bf_com_assets_total_pages'])?$GetAssetsCom['field_bf_com_assets_total_pages']:null;
        $GetAssignDetails     = $this->GetBFAssetsAssignDetailsByparam($briefingFormID, $catalogueID, $BFAssetTotalPages, $userType);
        $GetAssigningUser     = $this->GetAssigningUserByparam($briefingFormID, $catalogueID);
        $catalogue_due_date   = isset($GetAssigningUser['field_bf_catasur_due_date']) && !empty($GetAssigningUser['field_bf_catasur_due_date'])?$GetAssigningUser['field_bf_catasur_due_date']:null;
        $GetAssetfile         = $this->GetFileDetails($res->field_bf_asset_fid);
        // Get catalogue workflow status by catalogue id.
        $GetCatWorkflowStatus = $this->GetCatalogueWorkflowStatusByParams($catalogueID);
        // Get catalogue status by catalogue id.
        $GetCatalogueDetails  = $this->GetCatalogueDetailsByParams($catalogueID);
        $catalogueStatus      = isset($GetCatalogueDetails->field_catalogue_status->value) && !empty($GetCatalogueDetails->field_catalogue_status->value)?$GetCatalogueDetails->field_catalogue_status->value:null;
        // Get Total assigned pages in operator.
        $GetTotalAssignedOperatorPage   = $this->GetCatalogueTotalPageAssignedCountByParams($catalogueID, $User_Type ='operator', $pageStatus ='');
        // Get Total assigned pages in supervisor.
        $GetTotalAssignedSupervisorPage = $this->GetCatalogueTotalPageAssignedCountByParams($catalogueID, $User_Type ='supervisor', $pageStatus ='');
        // Get Total completed pages in operator.
        $GetTotalCompletedOperatorPage   = $this->GetCatalogueTotalPageAssignedCountByParams($catalogueID, $User_Type ='operator', $pageStatus ='catalogue_completed');
        // Get Total completed pages in supervisor.
        $GetTotalCompletedSupervisorPage = $this->GetCatalogueTotalPageAssignedCountByParams($catalogueID, $User_Type ='supervisor', $pageStatus ='catalogue_completed');
        // Get assigned pages in operator name.
        $GetAssignedOperatorName   = $this->GetCataloguePageAssignedNameByParams($catalogueID, $User_Type ='operator');
        // Get assigned pages in supervisor name.
        $GetAssignedSupervisorName = $this->GetCataloguePageAssignedNameByParams($catalogueID, $User_Type ='supervisor');
        // Get preface details using catalogue preface reference id in catalogue content type.
        $prefaceRefId = isset($GetCatalogueDetails->field_catalogue_preface->target_id) && !empty($GetCatalogueDetails->field_catalogue_preface->target_id)?$GetCatalogueDetails->field_catalogue_preface->target_id:null;
        if($prefaceRefId) {
          $GetPrefaceData = $this->GetCataloguePrefaceDetailsbyPrefaceRefId($prefaceRefId);
        } else {
          $GetPrefaceData = array();
        }
        // Get epilogue details using catalogue epilogue reference id in catalogue content type.
        $epilogueRefId = isset($GetCatalogueDetails->field_catalogue_epilogue->target_id) && !empty($GetCatalogueDetails->field_catalogue_epilogue->target_id)?$GetCatalogueDetails->field_catalogue_epilogue->target_id:null;
        if($epilogueRefId) {
          $GetEpilogueData = $this->GetCatalogueEpilogueDetailsbyEpilogueRefId($epilogueRefId);
        } else {
          $GetEpilogueData = array();
        }
        $arrData[] = array(
          'field_asset_id'                        => !is_null($res->field_asset_id)?$res->field_asset_id:null,
          'field_catalogue_id'                    => !is_null($res->field_catalogue_id)?$res->field_catalogue_id:null,
          'field_catalogue_status'                => $catalogueStatus,
          'field_catalogue_workflow_status'       => $GetCatWorkflowStatus,
          'field_assets_com_nid'                  => isset($GetAssetsCom['field_bf_com_assets_nid']) && !empty($GetAssetsCom['field_bf_com_assets_nid'])?$GetAssetsCom['field_bf_com_assets_nid']:null,
          'field_assets_catalogue_name'           => !is_null($res->field_catalogue_name)?$res->field_catalogue_name:null,
          'field_catalogue_ref_name'              => !is_null($res->field_catalogue_ref_name)?$res->field_catalogue_ref_name:null,
          'field_catalogue_pdfhash'               => !is_null($res->field_catalogue_pdfhash)?$res->field_catalogue_pdfhash:null,
          'field_assets_com_form_type'            => !is_null($res->field_bf_form_type)?$res->field_bf_form_type:null,
          'field_assets_com_fid'                  => !is_null($res->field_bf_asset_fid)?$res->field_bf_asset_fid:null,
          'field_assets_com_filename'             => isset($GetAssetfile['filename']) && !empty($GetAssetfile['filename'])?$GetAssetfile['filename']:null,
          'field_assets_com_file'                 => isset($GetAssetfile['file_uri']) && !empty($GetAssetfile['file_uri'])?$GetAssetfile['file_uri']:null,
          'field_assets_com_new_fid'              => isset($GetAssetsCom['field_bf_com_assets_new_fid']) && !empty($GetAssetsCom['field_bf_com_assets_new_fid'])?$GetAssetsCom['field_bf_com_assets_new_fid']:null,
          'field_assets_com_new_filename'         => isset($GetAssetsCom['field_bf_com_assets_new_filename']) && !empty($GetAssetsCom['field_bf_com_assets_new_filename'])?$GetAssetsCom['field_bf_com_assets_new_filename']:null,
          'field_assets_com_new_file'             => isset($GetAssetsCom['field_bf_com_assets_new_file_uri']) && !empty($GetAssetsCom['field_bf_com_assets_new_file_uri'])?$GetAssetsCom['field_bf_com_assets_new_file_uri']:null,
          'field_assets_com_type_title'           => isset($GetAssetsCom['field_briefing_form_assets_type']) && !empty($GetAssetsCom['field_briefing_form_assets_type'])?$GetAssetsCom['field_briefing_form_assets_type']:null,
          'field_assets_com_comments'             => !is_null($res->field_bf_asset_comments)?$res->field_bf_asset_comments:null,
          'field_assets_com_total_page'           => isset($GetAssetsCom['field_bf_com_assets_total_pages']) && !empty($GetAssetsCom['field_bf_com_assets_total_pages'])?$GetAssetsCom['field_bf_com_assets_total_pages']:null,
          'field_assets_com_assigned_page'        => isset($GetAssignDetails['assigned_pages']) && !empty($GetAssignDetails['assigned_pages'])?$GetAssignDetails['assigned_pages']:null,
          'field_assets_com_completed_page'       => isset($GetAssignDetails['completed_pages']) && !empty($GetAssignDetails['completed_pages'])?$GetAssignDetails['completed_pages']:null,
          'field_assets_com_status'               => !is_null($res->field_bf_asset_status)?$res->field_bf_asset_status:null,
          'field_catalogue_due_date'              => $catalogue_due_date,
          'field_catalogue_assigness'             => isset($GetAssignDetails['assigned_username']) && !empty($GetAssignDetails['assigned_username'])?$GetAssignDetails['assigned_username']:null,
          'field_assigned_operator_total_page'    => isset($GetTotalAssignedOperatorPage) && !empty($GetTotalAssignedOperatorPage)?$GetTotalAssignedOperatorPage:null,
          'field_completed_operator_total_page'   => isset($GetTotalCompletedOperatorPage) && !empty($GetTotalCompletedOperatorPage)?$GetTotalCompletedOperatorPage:null,
          'field_assigned_supervisor_total_page'  => isset($GetTotalAssignedSupervisorPage) && !empty($GetTotalAssignedSupervisorPage)?$GetTotalAssignedSupervisorPage:null,
          'field_completed_supervisor_total_page' => isset($GetTotalCompletedSupervisorPage) && !empty($GetTotalCompletedSupervisorPage)?$GetTotalCompletedSupervisorPage:null,
          'field_catalogue_assigness_operator'    => isset($GetAssignedOperatorName) && !empty($GetAssignedOperatorName)?$GetAssignedOperatorName:null, 
          'field_catalogue_assigness_supervisor'  => isset($GetAssignedSupervisorName) && !empty($GetAssignedSupervisorName)?$GetAssignedSupervisorName:null,
          'field_catalogue_preface'               => $prefaceRefId,
          'field_catalogue_epilogue'              => $epilogueRefId,
          'preface'                               => $GetPrefaceData,
          'epilogue'                              => $GetEpilogueData
        );
      }
    } else {
      $arrData = array();
    }
    return $arrData;
  }

  /**
   * Function :: Get catalogue preface details by preface reference id.
   */
  public function GetCataloguePrefaceDetailsbyPrefaceRefId($prefaceRefId) {
    if($prefaceRefId) {
      $node = Node::load($prefaceRefId);
      $field_preface_image         = $node->field_preface_image->target_id;
      $field_preface_image_width   = $node->field_preface_image_width->value;
      $field_preface_image_height  = $node->field_preface_image_height->value;
      $field_preface_image_title   = $node->field_preface_image->title;
      $field_preface_image_alt     = $node->field_preface_image->alt;
      // Preface Image.
      if($field_preface_image) {
        $file = File::load($field_preface_image);
        if($file) {
          $file_uri     = $file->getFileUri();
          $file_path    = file_create_url($file_uri);
          $filename     = $file->getFilename();
          $filesize     = $file->getSize(); 
        } else {
          $file_path    = ''; 
          $filename     = '';
          $filesize     = '';
        }
        /*$path_explode   = explode("s3:/",$file_uri);
        if(!empty($path_explode) && $path_explode[1] != ""){
          $file_path    = str_replace('s3:/','https://' . $domain, $file_uri);
        }else{
          $file_path    = str_replace('private:/','https://' . $domain, $file_uri);
        }*/
      } else {
        $file_path    = ''; 
        $filename     = '';
        $filesize     = '';
      }
      // Preface PDF.
      $field_preface_pdffile = $node->field_preface_pdffile->target_id;
      if($field_preface_pdffile) {
        $file1  = File::load($field_preface_pdffile);
        if($file1) {
          $file_uri1  = $file1->getFileUri();
          $file_path1 = file_create_url($file_uri1);
          $filename1  = $file1->getFilename();
          $filesize1  = $file1->getSize();
        } else {
          $file_path1 = ''; 
          $filename1  = '';
          $filesize1  = '';
        }
      } else {
        $file_path1   = ''; 
        $filename1    = '';
        $filesize1    = '';
      }
      // Preface PDF S3.
      $field_preface_pdf_s3 = $node->field_preface_pdf_s3->target_id;
      if($field_preface_pdf_s3) {
        $file2  = File::load($field_preface_pdf_s3);
        if($file2) {
          $file_uri2  = $file2->getFileUri();
          $file_path2 = file_create_url($file_uri2);
          $filename2  = $file2->getFilename();
          $filesize2  = $file2->getSize();
        } else {
          $file_path2 = '';
          $filename2  = '';
          $filesize2  = '';
        }
      } else {
        $file_path2   = '';
        $filename2    = '';
        $filesize2    = '';
      }
      $arrData = array(
        /*'field_preface_node_id'          => $node->id(),
        'field_preface_title'            => $node->getTitle(),
        'field_preface_image_fid'        => $field_preface_image,
        'field_preface_image_url'        => $file_path,
        'field_preface_image_width'      => $field_preface_image_width,
        'field_preface_image_height'     => $field_preface_image_height,
        'field_preface_notes'            => !empty($node->field_preface_notes->value)?$node->field_preface_notes->value:null,
        'field_preface_start_date'       => !empty($node->field_preface_start_date->value)?$node->field_preface_start_date->value:null,
        'field_preface_finish_date'      => !empty($node->field_preface_finish_date->value)?$node->field_preface_finish_date->value:null,
        'field_preface_pdffile_fid'      => $field_preface_pdffile,
        'field_preface_pdffile_url'      => $file_path1,
        'field_preface_pdf_s3_fid'       => $field_preface_pdf_s3,
        'field_preface_pdf_s3_url'       => $file_path2,
        'field_preface_image_link_uri'   => !empty($node->field_preface_image_link->uri)?$node->field_preface_image_link->uri:null,
        'field_preface_image_link_title' => !empty($node->field_preface_image_link->title)?$node->field_preface_image_link->title:null,
        */
        'title'     => $node->getTitle(),
        'preface'   => !empty($node->field_preface_image_link->uri)?$node->field_preface_image_link->uri:null,
        'width'     => $field_preface_image_width,
        'height'    => $field_preface_image_height,
        'image'     => $file_path
      );
    }
    return $arrData;
  }  

  /**
   * Function :: Get catalogue epilogue details by epilogue reference id.
   */
  public function GetCatalogueEpilogueDetailsbyEpilogueRefId($epilogueRefId) {
    if($epilogueRefId) {
      $node = Node::load($epilogueRefId);
      $field_epilogue_image         = $node->field_epilogue_image->target_id;
      $field_epilogue_image_width   = $node->field_epilogue_image_width->value;
      $field_epilogue_image_height  = $node->field_epilogue_image_height->value;
      $field_epilogue_image_title   = $node->field_epilogue_image->title;
      $field_epilogue_image_alt     = $node->field_epilogue_image->alt;
      // Epilogue Image.
      if($field_epilogue_image) {
        $file = File::load($field_epilogue_image);
        if($file) {
          $file_uri     = $file->getFileUri();
          $file_path    = file_create_url($file_uri);
          $filename     = $file->getFilename();
          $filesize     = $file->getSize();
        } else {
          $file_path    = ''; 
          $filename     = '';
          $filesize     = '';
        }
        /*$path_explode   = explode("s3:/",$file_uri);
        if(!empty($path_explode) && $path_explode[1] != ""){
          $file_path    = str_replace('s3:/','https://' . $domain, $file_uri);
        }else{
          $file_path    = str_replace('private:/','https://' . $domain, $file_uri);
        }*/
      } else {
        $file_path    = ''; 
        $filename     = '';
        $filesize     = '';
      }
      // Epilogue PDF.
      $field_epilogue_pdffile = $node->field_epilogue_pdffile->target_id;
      if($field_epilogue_pdffile) {
        $file1  = File::load($field_epilogue_pdffile);
        if($file1) {
          $file_uri1    = $file1->getFileUri();
          $file_path1   = file_create_url($file_uri1);
          $filename1    = $file1->getFilename();
          $filesize1    = $file1->getSize();
        } else {
          $file_path1   = ''; 
          $filename1    = '';
          $filesize1    = '';
        }
      } else {
        $file_path1   = ''; 
        $filename1    = '';
        $filesize1    = '';
      }
      // Epilogue PDF S3.
      $field_epilogue_pdf_s3 = $node->field_epilogue_pdf_s3->target_id;
      if($field_epilogue_pdf_s3) {
        $file2  = File::load($field_epilogue_pdf_s3);
        if($file2) {
          $file_uri2    = $file2->getFileUri();
          $file_path2   = file_create_url($file_uri2);
          $filename2    = $file2->getFilename();
          $filesize2    = $file2->getSize();
        } else {
          $file_path2   = ''; 
          $filename2    = '';
          $filesize2    = '';
        }
      } else {
        $file_path2   = ''; 
        $filename2    = '';
        $filesize2    = '';
      }
      $arrData = array(
        /*'field_epilogue_node_id'          => $node->id(),
        'field_epilogue_title'            => $node->getTitle(),
        'field_epilogue_image_fid'        => $field_epilogue_image,
        'field_epilogue_image_url'        => $file_path,
        'field_epilogue_image_width'      => $field_epilogue_image_width,
        'field_epilogue_image_height'     => $field_epilogue_image_height,
        'field_epilogue_notes'            => !empty($node->field_epilogue_notes->value)?$node->field_epilogue_notes->value:null,
        'field_epilogue_start_date'       => !empty($node->field_epilogue_start_date->value)?$node->field_epilogue_start_date->value:null,
        'field_epilogue_finish_date'      => !empty($node->field_epilogue_finish_date->value)?$node->field_epilogue_finish_date->value:null,
        'field_epilogue_pdffile_fid'      => $field_epilogue_pdffile,
        'field_epilogue_pdffile_url'      => $file_path1,
        'field_epilogue_pdf_s3_fid'       => $field_epilogue_pdf_s3,
        'field_epilogue_pdf_s3_url'       => $file_path2,
        'field_epilogue_image_link_uri'   => !empty($node->field_epilogue_image_link->uri)?$node->field_epilogue_image_link->uri:null,
        'field_epilogue_image_link_title' => !empty($node->field_epilogue_image_link->title)?$node->field_epilogue_image_link->title:null,
        */
        'title'     => $node->getTitle(),
        'epilogue'  => !empty($node->field_epilogue_image_link->uri)?$node->field_epilogue_image_link->uri:null,
        'width'     => $field_epilogue_image_width,
        'height'    => $field_epilogue_image_height,
        'image'     => $file_path
      );
    }
    return $arrData;
  }  

  /**
   * Function :: Get Total assigned page count in operator and supervisor by catalogue id.
   */
  public function GetCatalogueTotalPageAssignedCountByParams($catalogueID, $User_Type, $pageStatus) {
    if(!empty($User_Type) && !empty($catalogueID)) {
      try{
        // Select query.
        $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
        $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
        if(!empty($pageStatus)) {
          $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
        }
        $query->addExpression('COUNT(nfbfcpc.entity_id)', 'query_count');
        $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueID);
        $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $User_Type); // Designer & QC.
        if(!empty($pageStatus)) {
          $query->condition('nfbfcps.field_bf_catau_page_status_value', $pageStatus);
        }
        $query->orderBy('nfbfcpn.field_bf_catau_page_number_value', 'ASC');
        $query->groupBy('nfbfcpc.entity_id');
        $RowCount = $query->countQuery()->execute()->fetchField();
        return $RowCount;
      } catch (Exception $e) {
        $errorState = 'Function::GetCatalogueTotalPageAssignedCountByParams';
        $errorstatus = 'error'; 
        $errorMessage = json_decode($e->getMessage());
        \Drupal::logger('WFT-API-32')->notice('@errorState ||  %errorstatus ||  %errorMessage],', [
          '@errorState' => $errorState, '%errorstatus' => $errorstatus, '%errorMessage' => $errorMessage
        ]);
        return NULL;
      }
    } else {
      return NULL;
    }
  }

  /**
   * Function :: Get catalogue page assigned user name list by catalogue id and user type (operator and supervisor).
   */
  public function GetCataloguePageAssignedNameByParams($catalogueID, $User_Type) {
    if(!empty($User_Type) && !empty($catalogueID)) {
      try{
        // Select Query.
        $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
        $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
        $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
        $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
        $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfbfcpu.field_bf_catau_page_userid_target_id');
        $query->addField('nfbfcpc', 'entity_id', 'entity_id');
        $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
        $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catalogue_page_number');
        $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'catalogue_page_userid');
        $query->addField('nfbfcaur', 'field_bf_catau_assigng_user_role_value', 'catalogue_assiging_user_role');
        $query->addField('ufd', 'name', 'username');
        $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueID);
        $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $User_Type); // Designer.
        $query->orderBy('nfbfcpn.field_bf_catau_page_number_value', 'ASC');
        $query->allowRowCount = TRUE;
        $result = $query->execute()->fetchAll();
        if(!empty($result)) {
          foreach($result as $res) {
            $username = $this->GetAssignedUserName($res->username);
            if(!empty($username)) {
              $assigned_username[]= array($username => $res->username);
              //$assigned_username[$username] = $res->username;
              //$assigned_username['full_username']   = $res->username;
            }
          }
        }
        if(isset($assigned_username)) {
          //$assignedUsername = $assigned_username;
          $assignedUsername =  array_map("unserialize", array_unique(array_map("serialize", $assigned_username)));
          //$assignedUsername = array_unique($assigned_username);
        } else {
          $assignedUsername = array();
        }
        \Drupal::logger('WFT-API-32-assigne-list')->notice('@catalogueID ||  %User_Type ||  %assignedUsername],', [
          '@catalogueID' => $catalogueID, '%User_Type' => $User_Type, '%assignedUsername' => json_encode($assignedUsername)
        ]);
        return $assignedUsername;
      } catch (Exception $e) {
        $errorState = 'Function::GetCataloguePageAssignedNameByParams';
        $errorStatus = 'error'; 
        $errorMessage = json_decode($e->getMessage());
        \Drupal::logger('WFT-API-32')->notice('@errorState ||  %errorstatus ||  %errorMessage],', [
          '@errorState' => $errorState, '%errorstatus' => $errorstatus, '%errorMessage' => $errorMessage
        ]);
        return NULL;
      }
    } else {
      return false;
    }
  }

  /**
   * Function :: Get catalogue status by catalogue id.
   */
  public function GetCatalogueDetailsByParams($catalogueID) {
    if($catalogueID) {
      $catalogueNode = Node::load($catalogueID);
      if($catalogueNode) {
        return $catalogueNode;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  /**
  * Function :: Get briefing form assets communication data's by bf id and bf asset id.
  */
  public function GetBFAssetsCommunicationByParam($BFID, $BFAssetsID) {
    // Query to get briefing form assets communication data's by bf id and bf asset id.
    $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfcaid');
    $query->leftjoin('node__field_bf_com_briefingform_id', 'nfbfcbfid', 'nfbfcbfid.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_reported_uid', 'nfbfcomaruid', 'nfbfcomaruid.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_new_fid', 'nfbfcomanfid', 'nfbfcomanfid.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_comments', 'nfbfcomac', 'nfbfcomac.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_error_pages', 'nfbfcomaep', 'nfbfcomaep.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_fid', 'nfbfcomafid', 'nfbfcomafid.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_form_type', 'nfbfcomaft', 'nfbfcomaft.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_status', 'nfbfcomas', 'nfbfcomas.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_total_pages', 'nfbfcomatp', 'nfbfcomatp.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_type_id', 'nfbfcomatid', 'nfbfcomatid.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_com_new_assets_details', 'nfbfcomnad', 'nfbfcomnad.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_briefing_form_assets_type', 'nfbfat', 'nfbfat.entity_id = nfbfcomatid.field_bf_com_assets_type_id_target_id');
    $query->addField('nfbfcaid', 'entity_id', 'entity_id');
    $query->addField('nfbfcaid', 'field_bf_com_assets_id_target_id', 'field_bf_com_assets_id');
    $query->addField('nfbfcbfid', 'field_bf_com_briefingform_id_target_id', 'field_bf_com_briefingform_id');
    $query->addField('nfbfcomaruid', 'field_bf_com_assets_reported_uid_value', 'field_bf_com_assets_reported_uid');
    $query->addField('nfbfcomanfid', 'field_bf_com_assets_new_fid_value', 'field_bf_com_assets_new_fid');
    $query->addField('nfbfcomac', 'field_bf_com_assets_comments_value', 'field_bf_com_assets_comments');
    $query->addField('nfbfcomaep', 'field_bf_com_assets_error_pages_value', 'field_bf_com_assets_error_pages');
    $query->addField('nfbfcomafid', 'field_bf_com_assets_fid_value', 'field_bf_com_assets_fid');
    $query->addField('nfbfcomaft', 'field_bf_com_assets_form_type_value', 'field_bf_com_assets_form_type');
    $query->addField('nfbfcomas', 'field_bf_com_assets_status_value', 'field_bf_com_assets_status');
    $query->addField('nfbfcomatp', 'field_bf_com_assets_total_pages_value', 'field_bf_com_assets_total_pages');
    $query->addField('nfbfcomatid', 'field_bf_com_assets_type_id_target_id', 'field_bf_com_assets_type_id');
    $query->addField('nfbfcomnad', 'field_bf_com_new_assets_details_value', 'field_bf_com_new_assets_details');
    $query->addField('nfbfat', 'field_briefing_form_assets_type_value', 'field_briefing_form_assets_type');    
    $query->condition('nfbfcaid.field_bf_com_assets_id_target_id', $BFAssetsID);
    $query->condition('nfbfcbfid.field_bf_com_briefingform_id_target_id', $BFID);
    $query->orderBy('nfbfcaid.entity_id', 'DESC');
    $query->range(0, 1);
    $query->allowRowCount = TRUE;
    $GetBFCOMAssets = $query->execute()->fetchAssoc();
    if(!empty($GetBFCOMAssets)) {
      $GetAssetfile     = $this->GetFileDetails($GetBFCOMAssets['field_bf_com_assets_fid']);
      $GetNewAssetfile  = $this->GetFileDetails($GetBFCOMAssets['field_bf_com_assets_new_fid']);
      $arrData = array(
        'field_bf_com_assets_nid'           => isset($GetBFCOMAssets['entity_id']) && !empty($GetBFCOMAssets['entity_id'])?$GetBFCOMAssets['entity_id']:null,
        'field_bf_com_assets_id'            => isset($GetBFCOMAssets['field_bf_com_assets_id']) && !empty($GetBFCOMAssets['field_bf_com_assets_id'])?$GetBFCOMAssets['field_bf_com_assets_id']:null,
        'field_bf_com_briefingform_id'      => isset($GetBFCOMAssets['field_bf_com_briefingform_id']) && !empty($GetBFCOMAssets['field_bf_com_briefingform_id'])?$GetBFCOMAssets['field_bf_com_briefingform_id']:null,
        'field_bf_com_assets_reported_uid'  => isset($GetBFCOMAssets['field_bf_com_assets_reported_uid']) && !empty($GetBFCOMAssets['field_bf_com_assets_reported_uid'])?$GetBFCOMAssets['field_bf_com_assets_reported_uid']:null,
        'field_bf_com_assets_new_fid'       => isset($GetBFCOMAssets['field_bf_com_assets_new_fid']) && !empty($GetBFCOMAssets['field_bf_com_assets_new_fid'])?$GetBFCOMAssets['field_bf_com_assets_new_fid']:null,
        'field_bf_com_assets_new_filename'  => isset($GetNewAssetfile['filename']) && !empty($GetNewAssetfile['filename'])?$GetNewAssetfile['filename']:null,
        'field_bf_com_assets_new_file_uri'  => isset($GetNewAssetfile['file_uri']) && !empty($GetNewAssetfile['file_uri'])?$GetNewAssetfile['file_uri']:null,
        'field_bf_com_assets_new_filesize'  => isset($GetNewAssetfile['filesize']) && !empty($GetNewAssetfile['filesize'])?$GetNewAssetfile['filesize']:null,
        'field_bf_com_assets_comments'      => isset($GetBFCOMAssets['field_bf_com_assets_comments']) && !empty($GetBFCOMAssets['field_bf_com_assets_comments'])?$GetBFCOMAssets['field_bf_com_assets_comments']:null,
        'field_bf_com_assets_error_pages'   => isset($GetBFCOMAssets['field_bf_com_assets_error_pages']) && !empty($GetBFCOMAssets['field_bf_com_assets_error_pages'])?$GetBFCOMAssets['field_bf_com_assets_error_pages']:null,
        'field_bf_com_assets_fid'           => isset($GetBFCOMAssets['field_bf_com_assets_fid']) && !empty($GetBFCOMAssets['field_bf_com_assets_fid'])?$GetBFCOMAssets['field_bf_com_assets_fid']:null,
        'field_bf_com_assets_filename'      => isset($GetAssetfile['filename']) && !empty($GetAssetfile['filename'])?$GetAssetfile['filename']:null,
        'field_bf_com_assets_file_uri'      => isset($GetAssetfile['file_uri']) && !empty($GetAssetfile['file_uri'])?$GetAssetfile['file_uri']:null,
        'field_bf_com_assets_filesize'      => isset($GetAssetfile['filesize']) && !empty($GetAssetfile['filesize'])?$GetAssetfile['filesize']:null,
        'field_bf_com_assets_form_type'     => isset($GetBFCOMAssets['field_bf_com_assets_form_type']) && !empty($GetBFCOMAssets['field_bf_com_assets_form_type'])?$GetBFCOMAssets['field_bf_com_assets_form_type']:null,
        'field_bf_com_assets_status'        => isset($GetBFCOMAssets['field_bf_com_assets_status']) && !empty($GetBFCOMAssets['field_bf_com_assets_status'])?$GetBFCOMAssets['field_bf_com_assets_status']:null,
        'field_bf_com_assets_total_pages'   => isset($GetBFCOMAssets['field_bf_com_assets_total_pages']) && !empty($GetBFCOMAssets['field_bf_com_assets_total_pages'])?$GetBFCOMAssets['field_bf_com_assets_total_pages']:null,
        'field_bf_com_assets_type_id'       => isset($GetBFCOMAssets['field_bf_com_assets_type_id']) && !empty($GetBFCOMAssets['field_bf_com_assets_type_id'])?$GetBFCOMAssets['field_bf_com_assets_type_id']:null,
        'field_bf_com_new_assets_details'   => isset($GetBFCOMAssets['field_bf_com_new_assets_details']) && !empty($GetBFCOMAssets['field_bf_com_new_assets_details'])?$GetBFCOMAssets['field_bf_com_new_assets_details']:null,
        'field_briefing_form_assets_type'   => isset($GetBFCOMAssets['field_briefing_form_assets_type']) && !empty($GetBFCOMAssets['field_briefing_form_assets_type'])?$GetBFCOMAssets['field_briefing_form_assets_type']:null,
      );
    } else {
      $arrData = array();
    }
    return $arrData;
  }

  public function GetFileDetails($fid) {

    // S3 Bucket settings.
    $config   = \Drupal::config('s3fs.settings');
    $s3config = $config->get();
    $domain   = UrlHelper::filterBadProtocol($s3config['domain']);
    $file_path        = ''; 
    $filename         = '';
    $filesize         = '';
    if(!empty($fid)) {
      $file 	        = File::load($fid);
      if($file) {
        $file_uri 	    = $file->getFileUri();
        $filename       = $file->getFilename();
        $filesize       = $file->getSize();
        $path_explode   = explode("s3:/",$file_uri); 
        if($path_explode[1] != ""){
          $file_path    = str_replace('s3:/','https://' . $domain, $file_uri);
        }else{
          $file_path    = str_replace('private:/','https://' . $domain, $file_uri);
        }
      }
    }
    $arrData = array(
      'file_uri' => $file_path,
      'filename' => $filename,
      'filesize' => $filesize
    );
    return $arrData;
  }

  public function GetBFAssetsAssignDetailsByparam($briefingFormID, $catalogueID, $BFAssetTotalPages, $userType) {
    // Assigned user name.
    //$assigned_username  = '';
    // Assigned page count.
    $assigned_pages     = '';
    // Completed page count.
    $completed_pages    = '';
    // Select Query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bf_catau_page_date', 'nfbfcpd', 'nfbfcpd.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcpn', 'nfbfcpn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_userid', 'nfbfcpu', 'nfbfcpu.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfbfcpu.field_bf_catau_page_userid_target_id');
    $query->addField('nfbfcpc', 'entity_id', 'entity_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'catalogue_id');
    $query->addField('nfbfcpd', 'field_bf_catau_page_date_value', 'catalogue_page_date');
    $query->addField('nfbfcpn', 'field_bf_catau_page_number_value', 'catalogue_page_number');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'catalogue_page_status');
    $query->addField('nfbfcpu', 'field_bf_catau_page_userid_target_id', 'catalogue_page_userid');
    $query->addField('nfbfcaur', 'field_bf_catau_assigng_user_role_value', 'catalogue_assiging_user_role');
    $query->addField('ufd', 'name', 'username');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $catalogueID);
    $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', 'operator'); // Designer.
    $query->orderBy('nfbfcpn.field_bf_catau_page_number_value', 'ASC');
    $query->allowRowCount = TRUE;
    $result = $query->execute()->fetchAll();
    if(!empty($result)){
      // i variable for count assign pages.
      $i=0;
      // k variable for count completed pages
      $k=0;$x=0;
      foreach($result as $res) {
        if($res->catalogue_page_number) {
          $i++;
          if($res->catalogue_page_status=='catalogue_completed') {
            $k++;
          }
        }
        $username = $this->GetAssignedUserName($res->username);
        if(!empty($username)){
          //$assigned_username[$username]  = $res->username;
          $assigned_username[]= array($username => $res->username);
          //$assigned_username['full_username']   = $res->username;
        }
      }
      $assigned_pages = $i;
      $completed_pages = $k;
    }
    if(isset($assigned_username)) {
      //$assignedUsername = implode(", ", $assigned_username['short_username']);
      $assignedUsername =  array_map("unserialize", array_unique(array_map("serialize", $assigned_username)));
    } else {
      $assignedUsername = array();
    }
     $arrData = array(
       'assigned_pages'     => $assigned_pages,
       'completed_pages'    => $completed_pages,
       'assigned_username'  => $assignedUsername
     );
    return $arrData;
  }

  public function GetAssigningUserByparam($BFID, $catalogueID) {
    $query = \Drupal::database()->select('node__field_bf_catasur_briefingform_id', 'nfbcau_bfid');
    $query->leftjoin('node__field_bf_catasur_catalogue_id', 'nfbcau_catid', 'nfbcau_catid.entity_id = nfbcau_bfid.entity_id');
    $query->leftjoin('node__field_bf_catasur_loggedin_userid', 'nfbcau_luid', 'nfbcau_luid.entity_id = nfbcau_bfid.entity_id');
    $query->leftjoin('node__field_bf_catasur_due_date', 'nfbcau_dd', 'nfbcau_dd.entity_id = nfbcau_bfid.entity_id');
    $query->leftjoin('node__field_bf_catasur_client_id', 'nfbcau_clid', 'nfbcau_clid.entity_id = nfbcau_bfid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assigninguserid', 'nfbcau_auid', 'nfbcau_auid.entity_id = nfbcau_bfid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assigning_notes', 'nfbcau_an', 'nfbcau_an.entity_id = nfbcau_bfid.entity_id');
    $query->leftjoin('node__field_bf_catasur_pageno_range', 'nfbcau_pr', 'nfbcau_pr.entity_id = nfbcau_bfid.entity_id');
    $query->leftjoin('node_field_data', 'nfd','nfd.nid = nfbcau_bfid.entity_id');
    $query->addField('nfbcau_bfid', 'field_bf_catasur_briefingform_id_target_id', 'field_bf_catasur_briefingform_id');
    $query->addField('nfbcau_catid', 'field_bf_catasur_catalogue_id_target_id', 'field_bf_catasur_catalogue_id');
    $query->addField('nfbcau_luid', 'field_bf_catasur_loggedin_userid_target_id', 'field_bf_catasur_loggedin_userid');
    $query->addField('nfbcau_dd', 'field_bf_catasur_due_date_value', 'field_bf_catasur_due_date');
    $query->addField('nfbcau_clid', 'field_bf_catasur_client_id_value', 'field_bf_catasur_client_id');
    $query->addField('nfbcau_auid', 'field_bf_catasur_assigninguserid_target_id', 'field_bf_catasur_assigninguserid');
    $query->addField('nfbcau_an', 'field_bf_catasur_assigning_notes_value', 'field_bf_catasur_assigning_notes');
    $query->addField('nfbcau_pr', 'field_bf_catasur_pageno_range_value', 'field_bf_catasur_pageno_range');
    $query->addField('nfd', 'title', 'title');
    $query->condition('nfbcau_bfid.field_bf_catasur_briefingform_id_target_id', $BFID);
    $query->condition('nfbcau_catid.field_bf_catasur_catalogue_id_target_id', $catalogueID);
    $query->allowRowCount = TRUE;
    $result = $query->execute()->fetchAssoc();
    if(!empty($result)) {
      $loggedin_userid = $result['field_bf_catasur_loggedin_userid'];
      //$loguser_acct = $this->GetUserDetailByUID($loggedin_userid);
      $loguser_acct = \Drupal\user\Entity\User::load($loggedin_userid);
      $loguser_acct_name = $loguser_acct->getUsername();
      $assigning_userid = $result['field_bf_catasur_assigninguserid'];
      //$assigninguser_acct = $this->GetUserDetailByUID($assigning_userid);
      $assigninguser_acct = \Drupal\user\Entity\User::load($assigning_userid);
      $assigninguser_acct_name = $assigninguser_acct->getUsername();
      $arrData = array(
        'field_bf_catasur_briefingform_id'    => $result['field_bf_catasur_briefingform_id'],
        'field_bf_catasur_catalogue_id'       => $result['field_bf_catasur_catalogue_id'],
        'field_bf_catasur_pageno_range'       => $result['field_bf_catasur_pageno_range'],
        'field_bf_catasur_assigning_notes'    => $result['field_bf_catasur_assigning_notes'],
        'field_bf_catasur_due_date'           => $result['field_bf_catasur_due_date'],
        'field_bf_catasur_loggedin_userid'    => $result['field_bf_catasur_loggedin_userid'],
        'field_bf_catasur_loggedin_username'  => $loguser_acct_name,
        'field_bf_catasur_assigninguserid'    => $result['field_bf_catasur_assigninguserid'],
        'field_bf_catasur_assigning_username'  => $assigninguser_acct_name,
        'field_bf_catasur_client_id'          => $result['field_bf_catasur_client_id']
      );
    } else {
      $arrData = array();
    }
    return $arrData;
  }

  public function GetUserDetailByUID($uid) {
    $user_acct = User::load($loggedin_userid);
    return $user_acct;
  }

  /**
  * Function :: #33 API for updating the briefing form id to catalogue content type and catalogue id to assets using briefing form id and asset id.
  */
  public function PatchBFBriefingFormIdCatContentCatalogueIdAssetsContent($jsondata) {

    $userID         = isset($jsondata['field_user_id']) && !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
    $briefingformID = isset($jsondata['field_briefingform_id']) && !empty($jsondata['field_briefingform_id'])?$jsondata['field_briefingform_id']:null;
    $catalogueID    = isset($jsondata['field_catalogue_id']) && !empty($jsondata['field_catalogue_id'])?$jsondata['field_catalogue_id']:null;
    $assetNID       = isset($jsondata['field_assets_nid']) && !empty($jsondata['field_assets_nid'])?$jsondata['field_assets_nid']:null;
    $arrResponse['cat_response']    = null;
    $arrResponse['asset_response']  = null;
    // Update briefing form id to catalogue content type.
    if($catalogueID !=null && $briefingformID!=null) {
      $catNode = Node::load($catalogueID);
      $pagecount = $catNode->field_catalogue_pagecount->value;
      $catNode->set('field_briefing_form_reference_id',$briefingformID);
      $updCatNode = $catNode->save();
      if($updCatNode) {
        //$BFNode = Node::load($briefingformID);
        //$BFNode->set('field_briefing_form_reference_id',$briefingformID);
        //$updBFNode = $BFNode->save();
        $arrResponse['cat_response']  = 'success';
      } else {
        $arrResponse['cat_response']  = 'failure';
      }
    }
    // Update catalogue id to briefing form assets content type.
    if($assetNID !=null && $catalogueID!=null) {
      $BFAssetNode = Node::load($assetNID);
      $BFAssetNode->set('field_bf_asset_catalogue_id',$catalogueID);
      $updBFAssetNode = $BFAssetNode->save();
      if($updBFAssetNode) {
        $catNode = Node::load($catalogueID);
        $pagecount = $catNode->field_catalogue_pagecount->value;
        // Get asset communication node id.
        $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfaid');
        $query->addField('nfbfaid', 'entity_id', 'node_id');
        $query->condition('nfbfaid.field_bf_com_assets_id_target_id', $assetNID);
        $query->orderBy('nfbfaid.entity_id', 'DESC');
        $query->range(0, 1);
        $results = $query->execute()->fetchAll();
        if(!empty($results)) {
          foreach($results as $res) {
            $assetComNodeId = $res->node_id;
          }
          if(!empty($assetComNodeId)){
            // update catalogue total page count to assets communication.
            $AssetComNode = Node::load($assetComNodeId);
            $AssetComNode->set('field_bf_com_assets_total_pages',$pagecount);
            $updBFAssetComNode = $AssetComNode->save();
          }
        }
        $arrResponse['asset_response']  = 'success';
      } else {
        $arrResponse['asset_response']  = 'failure';
      }
    }
    // Checking the update response.
    if($arrResponse['cat_response']=='success' && $arrResponse['asset_response']=='') {
      $result     = ['status' => 'success', 'status_message' => 'Briefing form id updated in catalogue successfully.'];
      $node_type  = 'catalogue';
    } else if($arrResponse['cat_response']=='failure' && $arrResponse['asset_response']=='') {
      $result     = ['status' => 'error', 'status_message' => 'Briefing form id not updated in catalogue successfully. Please try after some times.'];
      $node_type  = 'catalogue';
    } else if($arrResponse['asset_response']=='success' && $arrResponse['cat_response']=='') {
      $result     = ['status' => 'success', 'status_message' => 'Catalogue id updated in briefing form assets successfully.'];
      $node_type  = 'briefingform_assets';
    } else if($arrResponse['asset_response']=='failure' && $arrResponse['cat_response']=='') {
      $result     = ['status' => 'error', 'status_message' => 'Catalogue id not updated in briefing form assets successfully. Please try after some times.'];
      $node_type  = 'briefingform_assets';
    } else {
      $result     = ['status' => 'error', 'status_message' => 'Your request details not updated successfully. Please check the request details and try.'];
      $node_type  = 'catalogue / briefingform_assets';
    }
    $responseData = $jsondata;
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'PATCH', $node_type, $responseData, $userID, $result);
    return $result;
  }

  public function GetCatalogueDetByBFID($BriefingFormID) {
    $query1 = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfrd');
    $query1->leftjoin('node__field_catalogue_pagecount', 'nfcpc', 'nfcpc.entity_id = nfbfrd.entity_id');
    $query1->leftjoin('node_field_data', 'nfd','nfd.nid = nfbfrd.entity_id');
    $query1->addField('nfbfrd', 'entity_id', 'field_catalogue_id');
    $query1->addField('nfbfrd', 'field_briefing_form_reference_id_target_id', 'field_briefringform_id');
    $query1->addField('nfcpc', 'field_catalogue_pagecount_value', 'field_catalogue_pagecount');
    $query1->addField('nfd', 'title', 'field_catalogue_name');
    $query1->condition('nfbfrd.field_briefing_form_reference_id_target_id', $BriefingFormID);
    $query1->orderBy('nfbfrd.entity_id', 'ASC');
    $query1->allowRowCount = TRUE;
    $getCatalogue = $query1->execute()->fetchAll();
    if(!empty($getCatalogue)){
      foreach($getCatalogue as $res) {
        $GetCatArrData[] = array(
          'catalogue_id'          => $res->field_catalogue_id,
          'catalogue_name'        => $res->field_catalogue_name,
          'catalogue_page_count'  => $res->field_catalogue_pagecount,
        );
      }
    } else {
      $GetCatArrData = array();
    }
    return $GetCatArrData;
  }

  /**
  * Function :: 31 API for updating the BF - catalogue completion date and production due date using briefing form id and catalogue id.
  */
  public function PatchBFCompletionDateProductionDueDate($jsondata) {

    $userID            = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
    $briefingformID    = !empty($jsondata['field_briefingform_id'])?$jsondata['field_briefingform_id']:null;
    $completionDate    = !empty($jsondata['field_bf_completion_date'])?$jsondata['field_bf_completion_date']:null;
    $productionDueDate = !empty($jsondata['field_bf_production_due_date'])?$jsondata['field_bf_production_due_date']:null;
    $QADate            = !empty($jsondata['field_bf_qa_date'])?$jsondata['field_bf_qa_date']:null;
    // Load briefing form by node id.
    $node = Node::load($briefingformID);
    // Briefing form completion date.
    if($completionDate!=null) {
      $completionDates = date('Y-m-d\TH:i:s', strtotime($completionDate));
      //$completion_Date = $completionDates.'T00:00:00';
      $node->set('field_bf_completion_date', $completionDates);
    }
    // Briefing form production due date.
    if($productionDueDate!=null) {
      $productionDueDates = date('Y-m-d\TH:i:s', strtotime($productionDueDate));
      //$production_DueDate = $productionDueDates.'T00:00:00';
      $node->set('field_bf_production_due_date', $productionDueDates);
    }
    // Briefing form QA date.
    if($QADate!=null) {
      $QADates = date('Y-m-d\TH:i:s', strtotime($QADate));
      //$qa_Date = $QADates.'T00:00:00';
      $node->set('field_bf_qa_date', $QADates);
    }
    $update = $node->save();
    if($update) {
      $GetCatalogue = $this->GetCatalogueDetByBFID($briefingformID);
      if(!empty($GetCatalogue)) {
        foreach($GetCatalogue as $res) {
          $catId = $res['catalogue_id'];
          if($catId) {
            // Load catalogue by node id.
            $CatNode = Node::load($catId);
            $CatNode->set('field_catalogue_completion_date', $completionDates);
            $CatNode->set('field_catalogue_prod_due_date', $productionDueDates);
            $CatUpdate = $CatNode->save();
          }
        }
      }
      $response = ['status' => 'success', 'status_message' => 'Briefing form catalogue completion date and production due date details updated successfully.'];
    } else {
      $response = ['status' => 'error', 'status_message' => 'Briefing form catalogue completion date and production due date details not updated successfully. Please try after some times.'];
    }
    $node_type    = 'briefingform';
    $responseData = $jsondata;
    //$user         = User::load(\Drupal::currentUser()->id());
    //$userID       = $user->get('uid')->value;
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistorys( $method = 'PATCH', $node_type, $responseData, $userID, $response);
    return $response;
  }

  /**
   * Get Last briefing form communication assets by assets id. 
   */
  public function GetLastBFAssetsCommunicationByAssetID($assetNID) {

    $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfcaid');
    $query->addField('nfbfcaid', 'entity_id', 'field_bf_com_node_id');
    $query->addField('nfbfcaid', 'field_bf_com_assets_id_target_id', 'field_bf_com_assets_id');
    $query->condition('nfbfcaid.field_bf_com_assets_id_target_id', $assetNID);
    $query->orderBy('nfbfcaid.entity_id', 'DESC');
    $query->range(0, 1);
    $results = $query->execute()->fetchAssoc();
    if($results) {
      return $results['field_bf_com_node_id'];
    } else {
      return false;
    }
  }

  /**
   * Check Briefing form all assets pdf is success or not.
   */
  public function CheckBFAllAssetsISSuccess($briefingFormId, $briefingFormAssetId) {
    // Select query for briefing form assets communication.
    $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfcaid');
    $query->leftjoin('node__field_bf_com_briefingform_id', 'nfbfcbfid', 'nfbfcbfid.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_asset_status', 'nfbfs', 'nfbfs.entity_id = nfbfcaid.entity_id');
    $query->addField('nfbfcaid', 'entity_id', 'field_bf_com_node_id');
    $query->addField('nfbfcaid', 'field_bf_com_assets_id_target_id', 'field_bf_asset_id');
    $query->addField('nfbfcbfid', 'field_bf_com_briefingform_id_target_id', 'field_asset_briefingform_id');
    //$query->condition('nfbfcaid.field_bf_com_assets_id_target_id', $briefingFormAssetId);
    $query->condition('nfbfcbfid.field_bf_com_briefingform_id_target_id', $briefingFormId);
    $query->condition('nfbfs.field_bf_asset_status_value', 'error', '=');
    $query->orderBy('nfbfcaid.entity_id', 'DESC');
    $results = $query->execute()->fetchAll();
    if(count($results)==0){
      // Send mail to Team leader.
      /**********************************************************/
      /******* Sending Mail using CURL Function - Start *********/
      /**********************************************************/
      header("Content-Type: text/json;");
      $host = \Drupal::request()->getSchemeAndHttpHost();
      // Curl function.
      $url = $host.'/briefingform/bfcatalogueeditpostmail';
      $GetBriefingForm  = $this->GetBriefingFormByNodeId($briefingFormId);
      $bf_client_id     = (isset($GetBriefingForm->field_briefing_form_client_id->target_id) && !empty($GetBriefingForm->field_briefing_form_client_id->target_id))?$GetBriefingForm->field_briefing_form_client_id->target_id:null;
      $assetsNode       = Node::load($briefingFormAssetId);
      $data = array(
          "briefingform_id"   => $briefingFormId,
          "catalogue_id"      => $assetsNode->field_bf_asset_catalogue_id->target_id,
          "field_client_id"   => $bf_client_id
      );
      $data_string = json_encode($data);
      $header = array("Content-Type: application/json");
      $curl   = curl_init();
      curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_HTTPHEADER => $header,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_POST => true,
          CURLOPT_POSTFIELDS => $data_string
      ));
      $response = curl_exec($curl);
      curl_close($curl);
      /**********************************************************/
      /******** Sending Mail using CURL Function - End **********/
      /**********************************************************/
    }
  }

  /**
   * Update briefing form assets communication status
   */
  public function UpdateBFAssetsCommunicationStatusByParam($briefingFormId, $briefingFormAssetId, $jsondata) {
    //$assets_error_pages = '1';
    // Select query for briefing form assets communication.
    $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfcaid');
    $query->leftjoin('node__field_bf_com_briefingform_id', 'nfbfcbfid', 'nfbfcbfid.entity_id = nfbfcaid.entity_id');
    $query->leftjoin('node__field_bf_asset_status', 'nfbfs', 'nfbfs.entity_id = nfbfcaid.entity_id');
    $query->addField('nfbfcaid', 'entity_id', 'field_bf_com_node_id');
    $query->addField('nfbfcaid', 'field_bf_com_assets_id_target_id', 'field_bf_asset_id');
    $query->addField('nfbfcbfid', 'field_bf_com_briefingform_id_target_id', 'field_asset_briefingform_id');
    $query->condition('nfbfcaid.field_bf_com_assets_id_target_id', $briefingFormAssetId);
    $query->condition('nfbfcbfid.field_bf_com_briefingform_id_target_id', $briefingFormId);
    $query->orderBy('nfbfcaid.entity_id', 'DESC');
    $query->range(0, 1);
    $results = $query->execute()->fetchAssoc();
    if($results['field_bf_com_node_id']) {
      $GetBriefingForm = $this->GetBriefingFormByNodeId($briefingFormId);
      $userID          = (isset($GetBriefingForm->field_briefing_form_author->target_id) && !empty($GetBriefingForm->field_briefing_form_author->target_id))?$GetBriefingForm->field_briefing_form_author->target_id:null;
      $bf_client_id    = (isset($GetBriefingForm->field_briefing_form_client_id->target_id) && !empty($GetBriefingForm->field_briefing_form_client_id->target_id))?$GetBriefingForm->field_briefing_form_client_id->target_id:null;
      $assetsComNode   = Node::load($results['field_bf_com_node_id']);
      $assetsNodeTitle = $assetsComNode->getTitle();
      $node = Node::create(array(
        'type'                              => 'bf_assets_communication',
        'title'                             => $assetsNodeTitle,
        'field_bf_com_assets_form_type'     => $assetsComNode->field_bf_com_assets_form_type->value,
        'field_bf_com_assets_fid'           => $assetsComNode->field_bf_com_assets_fid->value,
        'field_bf_com_assets_type_id'       => $assetsComNode->field_bf_com_assets_type_id->target_id,
        'field_bf_com_assets_comments'      => $assetsComNode->field_bf_com_assets_comments->value,
        'field_bf_com_briefingform_id'      => $briefingFormId,
        'field_bf_com_assets_id'            => $briefingFormAssetId,
        'field_bf_com_assets_total_pages'   => $assetsComNode->field_bf_com_assets_total_pages->value,
        'field_bf_com_assets_error_pages'   => null,
        'field_bf_com_assets_status'        => $assetsComNode->field_bf_com_assets_status->value,
        'field_bf_com_assets_error_date'    => date('Y-m-d\TH:i:s'),
        'field_bf_com_assets_reported_uid'  => null,
        'field_bf_com_assets_new_fid'       => null,
        'field_bf_com_new_assets_details'   => null,
        'uid'                               => $userID,
      ));
      $saveNode = $node->save();
      if($saveNode) {
        $briefingFormCatalogueStatus        = $jsondata['briefingFormCatalogueStatus'];
        $briefingFormCatalogueStatusMessage = $jsondata['briefingFormCatalogueStatusMessage'];
        /**********************************************************/
        /******* Sending Mail using CURL Function - Start *********/
        /**********************************************************/
        header("Content-Type: text/json;");
        $host = \Drupal::request()->getSchemeAndHttpHost();
        // Curl function.
        $url = $host.'/briefingform/api/bfpost-mail';
        $arrayAssets[] = array(
            'field_assets_id'          => $briefingFormAssetId,
            'field_assets_error_notes' => $briefingFormCatalogueStatusMessage
        );
        $data = array(
            "field_client_id"       => $bf_client_id,
            "field_mail_type"       => "2",
            "field_briefingform_id" => $briefingFormId,
            "field_assets"          => array($briefingFormAssetId)
        );
        $data_string = json_encode($data);
        $header = array("Content-Type: application/json");
        $curl   = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data_string
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        /**********************************************************/
        /******** Sending Mail using CURL Function - End **********/
        /**********************************************************/
      }
    }
  }

  /**
   * Briefing form - save all type of transaction history.
   */
  public function BFTransactionHistorys($method, $type, $responseData, $InsUserId, $result) {
    $encodeData = json_encode($responseData);
    if($method=='POST') {
      $createdBy    = $InsUserId;
      $createdDate  = date('Y-m-d H:i:s');
      $updatedBy    = null;
      $updatedDate  = null;
    } else {
      $createdBy    = null;
      $createdDate  = null;
      $updatedBy    = $InsUserId;
      $updatedDate  = date('Y-m-d H:i:s');
    }
    $status         = $result['status'];
    $status_message = $result['status_message'];
    
    $fieldArray = array(
      'bf_th_method' 		 		=> $method,
      'bf_th_type_name' 		=> $type,
      'bf_th_content' 	    => $encodeData,
      'bf_th_created_by' 	  => $createdBy,
      'bf_th_created_date'  => $createdDate,
      'bf_th_updated_by' 	  => $updatedBy,
      'bf_th_updated_date'  => $updatedDate,
      'bf_th_status_msg' 	  => $status_message,
     'bf_th_status'	      => $status
    );
    try{
      // Database connection.
      $db = \Drupal::database();
      $insertQry = $db->insert('briefingform_transaction_history')->fields($fieldArray)->execute();
      if($insertQry) {
        return true;
      } else {
        return false;
      }
    } catch (Exception $e) {
      return $e;
    }
  }

  /**
   * Get User id from bf asset id.
   */
  public function GetBFUserIdFromAssetNID($assetNID) {
    if($assetNID) {
      $AssetNode = Node::load($assetNID);
      if($AssetNode) {
        $BFNode = ode::load($AssetNode->field_asset_briefingform_id->target_id);
        if($BFNode) {
          return $BFNode->field_briefing_form_author->target_id;
        } else {
          return null;
        }
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  /**
   * Function :: Update assets created user id to catalogue, catalogue page, preface page, epilogue page.
   */
  public function UpdateCatalogueRelatedRecordsUserIds($CatalogueId, $uid) {
    \Drupal::logger('update-uid-01')->notice('@CatalogueId || %uid],', [
      '@CatalogueId' => $CatalogueId,
      '%uid' => $uid,
    ]);
    if(!empty($CatalogueId) && !empty($uid)) {
      $catalogueNode = Node::load($CatalogueId);
      // Preface node id.
      if(!empty($catalogueNode->field_catalogue_preface->target_id)){
        // Update owner id to preface node.
        $prefaceNode = Node::load($catalogueNode->field_catalogue_preface->target_id);
        $prefaceNode->set('uid', $uid);
        $UpdatePrefaceNode = $prefaceNode->save();
      }
      // Epilogue node id.
      if(!empty($catalogueNode->field_catalogue_epilogue->target_id)){
        // Update owner id to preface node.
        $epilogueNode = Node::load($catalogueNode->field_catalogue_epilogue->target_id);
        $epilogueNode->set('uid', $uid);
        $UpdateEpilogueNode = $epilogueNode->save();
      }
      // Update owner id (uid) in catalogue page using catalogue reference id.
      $query = \Drupal::database()->select('node__field_catalogue_reference', 'A');
      $query->fields('A', ['entity_id','field_catalogue_reference_target_id']);
      $query->condition('A.field_catalogue_reference_target_id', $CatalogueId);
      $query->orderBy('A.entity_id', 'ASC');
      $results = $query->execute()->fetchAll();
      if($results) {
        foreach($results as $res) {
          // Update owner id to catalogue page node.
          $cataloguePageNode = Node::load($res->entity_id);
          $cataloguePageNode->set('uid', $uid);
          $UpdateCataloguePageNode = $cataloguePageNode->save();
          $arrData[] = array('entity_id' => $res->entity_id, 'catpage_node_update' => $UpdateCataloguePageNode);
        }
        \Drupal::logger('update-uid-02')->notice('@arrData || %arrData],', [
          '@arrData' => json_encode($arrData)
        ]);
      }
    }
    return true;
  }

  /**
   * Function :: Update client mapping preface and epilogue by params.
   */
  public function updateClientMappingPrefaceAndEpilogueByParams($briefingFormCatalogueId,$BFCatalogueSection, $uid, $BFClientId) {
    # Get language code.
    $GetlanguageCode = \Drupal::languageManager()->getCurrentLanguage()->getId();
    # Get language name.
    $GetlanguageName =  \Drupal::languageManager()->getCurrentLanguage()->getName();
    $user = User::load($uid);
    $CatalogueNode = Node::load($briefingFormCatalogueId);
    $epilogueId    = $CatalogueNode->field_catalogue_epilogue->target_id;
    $prefaceId     = $CatalogueNode->field_catalogue_preface->target_id;
    $requestArray = array(
      'catalogue_id' =>$briefingFormCatalogueId, 
      'catalogue_section' => $BFCatalogueSection, 
      'user_id' => $uid, 
      'bfclient_id' => $BFClientId,
      'epilogueId' => $epilogueId,
      'prefaceId' => $prefaceId
    );
    \Drupal::logger('Update-preface-epilogue-01')->notice('@requestArray],', [
      '@requestArray' => json_encode($requestArray, true)
    ]);
    if(!empty($BFCatalogueSection) && $BFCatalogueSection == 'preface_epilogue') {

      // Insert preface data in group content table.
      $prefaceInsertQry1 = \Drupal::database()->insert('group_content')
        ->fields([
          'type'      => 'client-group_node-preface',
          'uuid'      => $this->GenerateUUIDValues(),
          'langcode'  => $GetlanguageCode,
        ])->execute();
      $lastprefaceInsertId = $prefaceInsertQry1;
      // Insert preface data in group content field date table.
      $PrefaceNode = $this->GetNodeDetailBynid($prefaceId);
      $prefaceInsertQry2 = \Drupal::database()->insert('group_content_field_data')
        ->fields([
          'id'        => $lastprefaceInsertId,
          'type'      => 'client-group_node-preface',
          'langcode'  => $GetlanguageCode,
          'gid'       => $BFClientId,
          'entity_id' => $prefaceId,
          'label'     => $PrefaceNode->getTitle(),
          'uid'       => $uid,
          'created'   => strtotime(date('Y-m-d\TH:i:s')),
          'changed'   => strtotime(date('Y-m-d\TH:i:s')),
          'default_langcode' => '1',
        ])->execute();

      // Insert epilogue data in group content table.
      $epilogueInsertQry1 = \Drupal::database()->insert('group_content')
        ->fields([
          'type'      => 'client-group_node-epilogue',
          'uuid'      => $this->GenerateUUIDValues(),
          'langcode'  => $GetlanguageCode,
        ])->execute();
      $lastpilogueInsertId1 = $epilogueInsertQry1;
      // Insert epilogue data in group content field date table.
      $EpilogueNode = $this->GetNodeDetailBynid($epilogueId);
      $epilogueInsertQry2 = \Drupal::database()->insert('group_content_field_data')
        ->fields([
          'id'        => $lastpilogueInsertId1,
          'type'      => 'client-group_node-epilogue',
          'langcode'  => $GetlanguageCode,
          'gid'       => $BFClientId,
          'entity_id' => $epilogueId,
          'label'     => $EpilogueNode->getTitle(),
          'uid'       => $uid,
          'created'   => strtotime(date('Y-m-d\TH:i:s')),
          'changed'   => strtotime(date('Y-m-d\TH:i:s')),
          'default_langcode' => '1',
        ])->execute();
      $responseArray = array(
        'preface_group_content' => $prefaceInsertQry1,
        'preface_group_content_field_data' => $prefaceInsertQry2,
        'epilogue_group_content' => $epilogueInsertQry1,
        'epilogue_group_content_field_data' => $epilogueInsertQry2,
      );
      \Drupal::logger('Update-preface-epilogue-02')->notice('@responseArray],', [
        '@responseArray' => json_encode($responseArray, true)
      ]);

    } else if(!empty($BFCatalogueSection) && ($BFCatalogueSection == 'preface_only')) {

      // Insert preface data in group content table.
      $prefaceInsertQry1 = \Drupal::database()->insert('group_content')
        ->fields([
          'type'      => 'client-group_node-preface',
          'uuid'      => $this->GenerateUUIDValues(),
          'langcode'  => $GetlanguageCode,
        ])->execute();
      $lastprefaceInsertId = $prefaceInsertQry1;
      // Insert preface data in group content field date table.
      $PrefaceNode = $this->GetNodeDetailBynid($prefaceId);
      $prefaceInsertQry2 = \Drupal::database()->insert('group_content_field_data')
        ->fields([
          'id'        => $tlastprefaceInsertId,
          'type'      => 'client-group_node-preface',
          'langcode'  => $GetlanguageCode,
          'gid'       => $BFClientId,
          'entity_id' => $prefaceId,
          'label'     => $PrefaceNode->getTitle(),
          'uid'       => $uid,
          'created'   => strtotime(date('Y-m-d\TH:i:s')),
          'changed'   => strtotime(date('Y-m-d\TH:i:s')),
          'default_langcode' => '1',
        ])->execute();
        $responseArray = array(
          'preface_group_content' => $prefaceInsertQry1,
          'preface_group_content_field_data' => $prefaceInsertQry2,
        );
        \Drupal::logger('Update-preface-epilogue-02')->notice('@responseArray],', [
          '@responseArray' => json_encode($responseArray, true)
        ]);

    } else if(!empty($BFCatalogueSection) && ($BFCatalogueSection == 'epilogue_only')) {

      // Insert epilogue data in group content table.
      $epilogueInsertQry1 = \Drupal::database()->insert('group_content')
        ->fields([
          'type'      => 'client-group_node-epilogue',
          'uuid'      => $this->GenerateUUIDValues(),
          'langcode'  => $GetlanguageCode,
        ])->execute();
      $lastpilogueInsertId1 = $epilogueInsertQry1;
      // Insert epilogue data in group content field date table.
      $EpilogueNode = $this->GetNodeDetailBynid($epilogueId);
      $epilogueInsertQry2 = \Drupal::database()->insert('group_content_field_data')
        ->fields([
          'id'        => $lastpilogueInsertId1,
          'type'      => 'client-group_node-epilogue',
          'langcode'  => $GetlanguageCode,
          'gid'       => $BFClientId,
          'entity_id' => $epilogueId,
          'label'     => $EpilogueNode->getTitle(),
          'uid'       => $uid,
          'created'   => strtotime(date('Y-m-d\TH:i:s')),
          'changed'   => strtotime(date('Y-m-d\TH:i:s')),
          'default_langcode' => '1',
        ])->execute();
        $responseArray = array(
          'epilogue_group_content' => $epilogueInsertQry1,
          'epilogue_group_content_field_data' => $epilogueInsertQry2,
        );
        \Drupal::logger('Update-preface-epilogue-02')->notice('@responseArray],', [
          '@responseArray' => json_encode($responseArray, true)
        ]);
    }
    return true;
  }

  // Function :: Generate UUID values dynamically.
  public function GenerateUUIDValues() {
    $uuid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x', random_int(0, 0xffff), random_int(0, 0xffff), random_int(0, 0xffff), random_int(0, 0x0fff) | 0x4000, random_int(0, 0x3fff) | 0x8000, random_int(0, 0xffff), random_int(0, 0xffff), random_int(0, 0xffff));
    return $uuid;
  }
  // Function :: Get node details by nid.
  public function GetNodeDetailBynid($nid) {
    if($nid){
      $Node = \Drupal\node\Entity\Node::load($nid);
      return $Node;
    } else {
      return false;
    }
  }
}
?>