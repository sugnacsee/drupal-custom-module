<?php
namespace Drupal\bf_portal\Utility;

use Drupal\Component\Utility\UrlHelper;
use Drupal\file\Entity\File;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Drupal\paragraphs\Entity\Paragraph;
use Aws\S3\S3Client;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Database\Database;
use Drupal\Core\Cache\Cache;
use Drupal\workflow\Entity\WorkflowConfigTransition;
use Drupal\workflow\Entity\WorkflowState;
use Drupal\workflow\Entity\Workflow;
use Drupal  \workflow\Entity\WorkflowManager;
use Drupal\workflow\Entity\WorkflowTransition;
use Drupal\Core\Datetime\Entity\DateFormat;
use Drupal\bf_portal\Utility\BFTransactionHistoryUtilityTrait;

trait BFCloneCatalogueUtilityTrait
{
  use BFTransactionHistoryUtilityTrait;

  /**
  * Function :: POST clone catalogue and region details.
  */
  public function BFCloneCatalogueAndRegionDetails($jsondata) {

    $userID             = $jsondata['field_bf_user_id'];
    $sourceid           = $jsondata['field_bf_source_catalogue_id'];
    $destinationidArray = $jsondata['field_bf_destination_catalogue_id'];
    $node_type          = 'briefingorm_clone_catalogue_region';
    // Get a list of all fields in the region content type.
    $fields = \Drupal::service('entity_field.manager')->getFieldDefinitions('node', 'region');
    // Check that the source catalogue has some clip regions defined.
    $query = \Drupal::entityQuery('node')
              ->condition('status', 1)
              ->condition('type', 'region')
              ->condition('field_catalogue_reference.target_id', trim($sourceid));
    $nids = $query->execute();
    if (count($nids) == 0) {
      $returnResponse = ['status' => 'error', 'status_message' => 'Source catalogue does not have any clip regions.'];
      return $returnResponse;
    }
    // Check that the destination catalogue has no clip regions defined.
    $query = \Drupal::entityQuery('node')
              ->condition('status', 1)
              ->condition('type', 'region')
              ->condition('field_catalogue_reference.target_id', $destinationidArray, 'IN');
    $nids = $query->execute();
    if (count($nids) > 0) {
      $returnResponse = ['status' => 'error', 'status_message' => 'Destination catalogue have the regions in it, please remove the existing regions to perform the clone action.'];
      return $returnResponse;
      //$form_state->setErrorByName('destination', t('Destination catalogue already has clip regions'));
    }
    if(!empty($userID) && !empty($sourceid) && !empty($destinationidArray)) {
      foreach($destinationidArray as $destinationId) {
        if($sourceid == $destinationId) {
          $returnResponse = ['status' => 'error', 'status_message' => 'Destination catalogue cannot be same as source catalogue.'];
          return $returnResponse;
        }
        $query = \Drupal::entityQuery('node')
          ->condition('status', 1)
          ->condition('type', 'region')
          ->condition('field_catalogue_reference.target_id', trim($sourceid));
        $nids = $query->execute();
       // $regions = entity_load_multiple('node', $nids);
        $regions = \Drupal::entityTypeManager()
        ->getStorage('node')
        ->loadMultiple($nids);

        $source_catalogue_exist = 'select field_catalogue_additional_field_target_id from {node__field_catalogue_additional_field} where entity_id =:cid';
        $source_catalogue_exist_args = array(
            ':cid' => trim($sourceid),
        );
        $source_paragraph_id = \Drupal::database()->query($source_catalogue_exist, $source_catalogue_exist_args)->fetchAll();
        if($source_paragraph_id){
          $new_catalogue_node = Node::load(trim($destinationId));
          foreach ( $source_paragraph_id as $para_id ) {
            $paragraph = Paragraph::load($para_id->field_catalogue_additional_field_target_id);
            $new_cat_paragraph = Paragraph::create([
              'type' => 'catalogue_additional_fields',
              //'field_additional_label' => $paragraph->field_additional_label->getValue(),
              'field_catalogue_additional_label' => $paragraph->field_catalogue_additional_label->getValue(),
              'field_additional_sorting_count' => $paragraph->field_additional_sorting_count->getValue(),
            ]);
            $new_cat_paragraph->save();
            $new_catalogue_node->field_catalogue_additional_field->appendItem($new_cat_paragraph);
            $new_catalogue_node->save();
          }
        }
        foreach ($regions as $region) {
          // Create a new node entity.
          $data = [
              'type' => 'region',
              'title' => $region->title->value,
              'region_id' => $region->nid->value,
          ];
          //  $region_id = $data[region_id];
          $new_region = Node::create($data);
          // Copy all the field values from old to new region.
          foreach ($fields as $field_name => $field_data) {
            // Select only the custom fields.
            $class = get_class($field_data);
            // print_r($region->{$field_name});ex
            if ($class == 'Drupal\field\Entity\FieldConfig') {
              /*if($field_name != 'field_product_image_url'){
                $source_link = $region->{$field_name}->getValue();
                $replace_des_link = str_replace($source_homeUrl_value,$destination_homeUrl_value,$source_link[0]['uri']);
                $replace_uri = array("uri" => $replace_des_link,'title' =>$source_link[0]['title'],'options'=>$source_link[0]['options']);
                $replace_result = array_replace($source_link[0],$replace_uri);
              }else{*/
                $replace_result = $region->{$field_name}->getValue();
              /*}*/
              // Process each type of field.
              switch ($field_data->get('field_type')) {
                case 'entity_reference':
                    $new_region->{$field_name}->target_id = $region->{$field_name}->target_id;
                    break;
                case 'link':
                    $new_region->{$field_name} =  $replace_result;
                    break;
                case 'text_formatted':
                    $new_region->{$field_name}->value = $region->{$field_name}->value;
                    $new_region->{$field_name}->format = $region->{$field_name}->format;
                    $new_region->{$field_name}->processed = $region->{$field_name}->processed;
                    break;
                default:
                    $new_region->{$field_name}->value = $region->{$field_name}->value;
              }
            }
          }
          //    Change the catalogue reference to point to destination.
          $new_region->field_catalogue_reference->target_id = trim($destinationId);
          $new_region->field_region_notes->value .= ' ' . t('Cloned from catalogue %src on %date', [
            '%src' => $sourceid,
            '%date' => date('Y-m-d H:i'),
          ]);
          $new_region->field_region_notes->format = 'basic_html';
          // Save the new region node.
          $new_region->save();
          /* For clone additional fields and multiple pricing start*/
          $new_region_id = $new_region->id();
          $source_region_id = $region->nid->value;
          $node = Node::load($source_region_id);
          // Additional field clone start
          if($source_paragraph_id){
            $paragraph_det = $node->field_product_additional_fields->getValue();
            if($paragraph_det) {
              $i = 1;
              $des_catalogue_node = Node::load(trim($destinationId));
              $des_cata_add = $des_catalogue_node->field_catalogue_additional_field->getValue();
              $j = 1;
              $source_reg_label = array();
              $des_cat_labelid = array();
              foreach ( $des_cata_add as $element ) {
                $des_cat_labelid[$j] = $element['target_id'];
                  $j++;
                }
              foreach ($paragraph_det as $element) {
                if($i<=count($des_cat_labelid)) {
                  $new_node = Node::load($new_region_id);
                  //  print_r($element['target_id']);
                  $p = Paragraph::load($element['target_id']);
                  //print_r($p->field_additional_label_value[0]->value);exit;
                  if (!empty($p->field_additional_label_value[0]->value)) {
                    $source_reg_label[$i] = $p->field_additional_label_value[0]->value;
                  } else {
                    $source_reg_label[$i] = "";
                  }
                }
                $i++;
              }
              $merge_res = array_combine($des_cat_labelid,$source_reg_label);
              foreach($merge_res as $key => $value){
                $paragraph = Paragraph::create([
                    'type' => 'product_additional_fields',
                    //'field_additional_label' => $p->field_additional_label->getValue(),
                    'field_additional_label_value' => $value,
                    'field_catalogue_additional_id' => $key,
                ]);
                $paragraph->save();
                $new_node->field_product_additional_fields->appendItem($paragraph);
                 $new_node->save();
               }    
              }
            } else {
              $paragraph_det = $node->field_product_additional_fields->getValue();
              if($paragraph_det) {
                $new_node = Node::load($new_region_id);
                foreach ($paragraph_det as $element) {
                  $p = Paragraph::load($element['target_id']);
                  $paragraph = Paragraph::create([
                    'type' => 'product_additional_fields',
                    'field_additional_label' => $p->field_additional_label->getValue(),
                    'field_additional_label_value' => $p->field_additional_label_value->getValue(),
                ]);
                $paragraph->save();
                $new_node->field_product_additional_fields->appendItem($paragraph);
                $new_node->save();
              }
            }
          }
        }
        \Drupal::logger('redpepper')->notice('Cloned @count regions from catalogue %src to %dest', [
          '@count' => count($regions),
          '%src' => $sourceid,
          '%dest' => $destinationId,
        ]);
      }
      $returnResponse = ['status' => 'success', 'status_message' => 'clone catalogue and region details are added successfully.'];
      // Add briefing form transaction history.
      $BFTransactionHistory = $this->BFTransactionHistory( $method = 'POST', $node_type, $jsondata, $userID, $returnResponse);
      return $returnResponse;
    } else {
      $returnResponse = ['status' => 'error', 'status_message' => 'clone catalogue and region details are not valid. Please check the details.'];
      // Add briefing form transaction history.
      $BFTransactionHistory = $this->BFTransactionHistory( $method = 'POST', $node_type, $jsondata, $userID, $returnResponse);
      return $returnResponse;
    }
  }

  /**
  * Function :: Validate clone catalogue and region details.
  */
  /*public function validateCloneCatalogueAndRegionDetail($jsondata) {

  }*/

  /**
  * Function :: Get source catalogue page number by param catalogue id.
  */
  /*public function GetSourceCataloguePageNumber($sourceid) {

    $pageNumber = array();
    // Get All pages against the source catalogue.
    try{
      $sourcePageQry = \Drupal::database()->select('node__field_catalogue_reference', 'nfcr');
      $sourcePageQry->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfcr.entity_id');
      $sourcePageQry->leftjoin('node__field_catalogue_page', 'nfcp', 'nfcp.entity_id = nfcr.entity_id');
      $sourcePageQry->addField('nfcr', 'entity_id', 'nodeId');
      $sourcePageQry->addField('nfcr', 'field_catalogue_reference_target_id', 'catalogueId');
      $sourcePageQry->addField('nfd', 'type', 'nodeType');
      $sourcePageQry->addField('nfd', 'title', 'nodeTitle');
      $sourcePageQry->addField('nfd', 'uid', 'userId');
      $sourcePageQry->addField('nfcp', 'field_catalogue_page_value', 'field_catalogue_page');
      $sourcePageQry->condition('nfd.type', 'catapage');
      $sourcePageQry->condition('nfcr.field_catalogue_reference_target_id', $sourceid);
      $sourceQryResults = $sourcePageQry->execute()->fetchAll();
      if(!empty($sourceQryResults)) {
        $i=0;
        foreach($sourceQryResults as $res) {
          $pageNumber[$i] = $res->field_catalogue_page;
          $i++;
        }
      } else {
        return $pageNumber;
      }
    } catch(\Exception $e){
        return $pageNumber;
    }
  }*/
}
?>